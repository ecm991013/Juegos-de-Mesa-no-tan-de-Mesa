# Juegos de mesa no tan de mesa

Plataforma con tres juegos web independientes: BioDefensa, Rummikub Online Club y Dominó Club.

## Despliegue
Sube el ZIP `Juegos_de_mesa_no_tan_de_mesa.zip` junto con `render.yaml` a GitHub. Render extrae el ZIP durante el build, instala las dependencias raíz e inicia el portal con `npm start`.

## Última actualización · 1.8.5
- La tarjeta de Dominó utiliza la portada `domino-cover-v3.png` (2400 × 1000).
- La imagen se escala con anchura completa y altura proporcional; el marco completo queda visible y no se recorta.
- El enlace de la imagen cambia de versión para que el navegador no reutilice el recurso anterior.
- HTML, CSS, JavaScript y SVG usan `Cache-Control: no-cache`; además, las hojas CSS y scripts utilizan URLs versionadas.
- BioDefensa y Rummikub conservan sus reglas y archivos.


## Dominó Club 1.6.0
- Previsualización en vivo del acabado de fichas y color del paño.
- Las fichas de la mano no se resaltan ni deshabilitan individualmente según su jugada; el jugador decide y el servidor valida.
- Recorrido serpenteante: las filas alternan derecha e izquierda y se conectan con curvas visuales.


### Dominó Club 1.7.0

La cadena se distribuye en varias filas conectadas, no en una sola línea horizontal. Cada fila alterna su sentido: avanza a la derecha, gira al siguiente tramo y vuelve a la izquierda. El número de fichas por fila se calcula según el ancho del tablero y se vuelve a calcular al cambiar el tamaño de pantalla. Al arrastrar una ficha, el extremo de destino se decide por proximidad al primer o último elemento visible de la cadena.


## Dominó Club 1.8.2 — mano y recorrido
- La ficha de apertura queda centrada respecto al área útil visible de la mesa, descontando el padding superior e inferior del escenario.
- La cadena crece desde la ficha inicial hacia los extremos izquierdo y derecho.
- El usuario puede ordenar manualmente su mano arrastrando fichas sobre otras.
- Al soltar una ficha por debajo o por encima del extremo, puede indicar que el próximo tramo doble hacia abajo o arriba; también puede escogerlo con los controles de dirección.
- Las fichas dobles y normales conservan dimensiones idénticas en horizontal y vertical, también en móvil.
- Se amplían las pruebas de arrastre, orden manual, apertura centrada y giros en ambos lados.


## Versión 1.8.2 — distribución del tablero de Dominó
- Se ajustó el centro vertical de la ficha inicial para calcularse dentro del área de contenido de `chainStage`, descontando el padding real del escenario. Esto evita que la ficha quede visualmente desplazada hacia abajo.
- Se mantuvo el punto de apertura centrado y las ramas izquierda/derecha.
- La mano admite reordenación libre por arrastre entre fichas.
- El usuario puede marcar el siguiente giro de una rama soltando por encima/debajo del extremo o usando los controles «Seguir recto», «Doblar arriba» y «Doblar abajo».
- Se añadieron pruebas de giro en la rama izquierda y de dimensiones físicas uniformes para fichas dobles y normales.


## Revisión 1.8.2 — Dominó
- Corregido el cálculo de `centerY`: antes utilizaba la altura completa del escenario aunque la cadena se renderiza dentro de su caja de contenido, debajo del padding. Ahora el centro se calcula con `clientHeight - paddingTop - paddingBottom` usando los estilos computados y fallback móvil/escritorio.
- Confirmado que `openingTileId` mantiene la ficha inicial anclada al centro y que los brazos se distribuyen hacia ambos lados.
- Se ampliaron pruebas de puntero para soltar en cada extremo, activar giro hacia abajo y reordenar la mano.
- Se añadieron pruebas para giros hacia abajo en el brazo izquierdo y dimensiones idénticas para fichas normales/dobles.
- Suite completa: 91 pruebas aprobadas; verificación de sintaxis de servidores, clientes y módulo de layout superada.
- No se modificaron las reglas de BioDefensa ni Rummikub.


## Dominó Club 1.8.3 — revisión de avatares y rivales
- Se corrigió la programación duplicada del temporizador de IA al crear una partida: cada turno de IA ahora se agenda una sola vez.
- Los ocho retratos del selector usan identificadores neutros (`avatar-01` a `avatar-08`), se muestran en una cuadrícula uniforme y ya no tienen nombres debajo.
- Los rivales IA ahora tienen nombres ficticios propios: Don Jacinto, La Chispa, El Zurdo, Doña Mula, Capitán Doble, La Centella, Tito Seis y La Estratega.
- La selección de rivales evita repetir el retrato elegido por el jugador y evita duplicar retratos entre IA; en la modalidad local también asigna retratos distintos.
- Se corrigió la puntuación por cierre bloqueado en parejas: el equipo ganador recibe la diferencia entre los puntos restantes del equipo rival y los suyos.
- Nueva cobertura de pruebas para roster, avatares, programación de IA y puntuación por parejas.
- BioDefensa y Rummikub permanecen sin cambios en sus reglas ni en sus archivos.


## Revisión funcional 1.8.4 — Dominó Club

**Hallazgos corregidos**
- `createStartedRoom` agendaba el mismo turno IA dos veces consecutivas. Se dejó una única llamada a `scheduleAI(room)`.
- En el cierre por bloqueo en modo parejas, el marcador concedía los puntos rivales sin descontar los puntos restantes del equipo ganador. Ahora se puntúa la diferencia entre ambos equipos, nunca inferior a cero.
- Los nombres de los archivos de retrato se usaban como identificadores de selección. Se migró a ocho IDs neutrales y un roster de nombres separado para la IA.
- La selección de oponentes ahora excluye el retrato humano y elige retratos únicos para los rivales. El modo local también usa imágenes sin repetir.
- Las preferencias antiguas de avatar se traducen a sus nuevos IDs para no perder la selección guardada en el navegador.

**Verificación**
- `npm run check`: correcto.
- `npm test`: 100 pruebas aprobadas, 0 fallidas.
- Ocho recursos WebP: válidos, 384 × 384.
- HTML del selector: ocho botones con imagen, sin texto/nombre debajo.
- El roster de IA contiene ocho nombres distintos.

**Limitación de entorno**
No se ejecutó el servidor web real en esta sesión porque las dependencias `express` y `socket.io` no están instaladas en el contenedor. El proyecto las declara en `package.json`; Render debe instalarlas durante `npm install`. Las pruebas cubren reglas, cliente simulado, interfaz, roster y rutas de recursos, pero no sustituyen una partida online real desplegada.


## Dominó Club 1.8.5 — corrección de la cadena invisible

- **Causa raíz:** `Domino_Online/public/index.html` solicita `/domino/layout.js`, pero Express solo publica archivos que están dentro de `Domino_Online/public`. El módulo `layout.js` existía únicamente en la raíz del juego. Mientras la cadena estaba vacía, el cliente podía mostrar la mano; al recibir la primera ficha y tratar de dibujar una cadena no vacía, `window.DominoLayout` no existía y el render se interrumpía. Esto explica la mesa vacía de la captura.
- Se añadió `Domino_Online/public/layout.js`, copia exacta del módulo fuente `Domino_Online/layout.js`, para que Express lo pueda servir mediante la misma ruta solicitada por el HTML.
- Se versionaron las referencias de `layout.js`, `client.js` y `styles.css` a `1.8.5` para evitar mezclar recursos de versiones anteriores.
- El test del cliente ahora ejecuta el `layout.js` público real en el DOM simulado en vez de inyectar únicamente el módulo Node. Se añadió una regresión que entrega un `gameState` con tres fichas y comprueba que el HTML del tablero contiene todas las fichas, la apertura y los conectores.
- Se añadió una verificación de que el archivo público existe y coincide byte por byte con el módulo fuente.
- Verificación: `npm run check` correcto; `npm test` con 102 pruebas aprobadas, 0 fallidas.
- BioDefensa y Rummikub no se modificaron.
