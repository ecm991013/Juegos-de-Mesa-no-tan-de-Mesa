# Revisión técnica – Juegos de mesa no tan de mesa 1.3.0

## Dominó Club 1.0.0

- Se incorporó como servicio independiente en `/domino/`, escuchando internamente en el puerto 3103.
- Se habilitó el reenvío HTTP y WebSocket de Socket.IO desde el proxy principal.
- Reglas doble-seis en módulo aislado `Domino_Online/rules.js`: creación del set de 28 fichas, reparto de siete, elección de salida, jugadas válidas, orientación en ambos extremos, robo, pase, cierre por bloqueo y puntuación.
- Modos contra IA, local de misma pantalla y sala privada online con código.
- Rivales IA con nombres y retratos propios; tres niveles de estrategia.
- Cuatro jugadores admiten juego individual o por parejas en posiciones opuestas.
- Personalización local de ocho acabados de fichas y cinco colores de mesa.
- Ocho retratos WebP exclusivos de Dominó Club, sin reutilizar los avatares de los otros juegos.
- La validación de fichas y turnos se ejecuta en el servidor.

## Pruebas de Dominó

- 10 pruebas nuevas: set doble-seis, reparto, salida, conexión y orientación, robo, pase, bloqueo, equipos, selección de IA y siguiente ronda.
- Sintaxis comprobada para `Domino_Online/server.js`, `rules.js` y `public/client.js`.

## Plataforma

- Se añadió el servicio `/domino` y puerto interno 3103 en `server.js`.
- Se actualizó el proxy de upgrades WebSocket para Rummikub y Dominó.
- El catálogo principal muestra tres juegos y añade filtro de clásicos.
- Se actualizó el comando `npm run check` para incluir los tres archivos JavaScript de Dominó.

## Limitaciones de verificación

- Las pruebas automatizadas de las reglas de Dominó y las comprobaciones de sintaxis pasan.
- No fue posible probar Socket.IO con dos navegadores reales ni desplegar en Render desde este entorno porque las dependencias no están instaladas localmente; Render las instala desde el `package.json` raíz durante la compilación.
- Las salas online se guardan en memoria y no sobreviven a reinicios del proceso.
- En modo local, el dispositivo se comparte entre participantes; se muestra la mano del jugador al que corresponde el turno.

## Juegos existentes

BioDefensa y Rummikub se conservan como carpetas y servicios independientes. No se modificaron sus reglas en esta integración.
