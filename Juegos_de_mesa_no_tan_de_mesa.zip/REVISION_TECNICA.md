# Revisión técnica · Versión 1.5.1

## Dominó
- Corregida la portada de la tarjeta de catálogo: se retiró el título grande superpuesto, que podía salirse del marco según la anchura disponible.
- El nombre completo del juego queda en el bloque de información, debajo de la ilustración. En la imagen solo queda una etiqueta compacta «DOMINÓ DOBLE-SEIS · 28 FICHAS».
- Imagen panorámica conservada completa mediante `object-fit: contain`, relación 12:5 en pantallas grandes y ajuste específico en móviles.
- Ajustados tamaños de párrafo, chips, CTA y espaciado para mantener legibilidad.
- La IA espera 3,6–4,4 s (Fácil), 4,2–5,0 s (Normal) y 4,8–5,6 s (Difícil).
- El servidor publica `aiThinking` y `aiThinkingDelay`; el cliente muestra «está pensando…» con animación discreta.
- Añadidas pruebas unitarias para el temporizador de IA y pruebas de interfaz para la tarjeta del catálogo.

## Comprobaciones
- `node --test`: 74 pruebas aprobadas.
- `npm run check`: sintaxis de los servidores y clientes verificada.
- La prueba de integración online real contra Render no se realiza desde este entorno.
