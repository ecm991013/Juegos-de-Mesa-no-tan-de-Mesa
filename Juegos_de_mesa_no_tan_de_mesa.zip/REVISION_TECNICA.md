# Revisión técnica inicial

## BioDefensa 0.15.4

**Resultado automatizado:** 24/24 pruebas aprobadas con `node --test`.

Las pruebas existentes cubren creación y unión de salas, partidas contra IA, eventos de acciones, estrategia de IA, mazo, persistencia, reconexión, blindaje, Matasanos, extracción, intercambio, cambio de cuerpo, medicinas por color e indicadores visuales.

**Integración:** las peticiones API y los recursos estáticos se prefijan con `/biodefensa` para alojar el juego bajo la ruta común sin alterar sus reglas.

## Rummikub Online Club 1.3.1

**Comprobaciones:** `node --check` aprobado para el servidor, cliente y módulo de reglas. Se separaron las reglas puras en `rules.js` y se añadieron siete pruebas automatizadas de mazo, escaleras, grupos, comodines y puntuación.

Se revisaron las reglas y el flujo de turnos. La lógica del servidor controla la pertenencia de las fichas, combinaciones válidas, apertura de 30 puntos, modificaciones de mesa y uso del comodín. Se conservó esa autoridad del servidor.

**Limpieza aplicada:** se eliminó una comprobación duplicada de conexión en el cliente. Se trasladaron recursos estáticos y Socket.IO a la ruta `/rummikub` para la integración.

**Limitación de pruebas:** el ZIP original no incluía pruebas automatizadas para Rummikub. Ahora se añadieron siete pruebas unitarias independientes de las dependencias del servidor. La instalación de `express` y `socket.io` agotó el tiempo disponible en este entorno, por lo que no se pudo ejecutar una partida online de extremo a extremo aquí. Render/local debe instalar las dependencias declaradas en `Rummikub_Online/package.json`.

## Plataforma común

- Catálogo responsive con buscador y filtros.
- Cada juego conserva su servidor y sus carpetas.
- Proxy HTTP para ambos juegos y reenvío WebSocket de Socket.IO para Rummikub.
- Endpoint `/health` para la comprobación del servicio.
- Preparada para incorporar nuevos juegos mediante una ruta adicional y una tarjeta de catálogo.
