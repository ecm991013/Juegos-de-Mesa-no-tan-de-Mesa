# Revisión técnica · Versión 1.5.2

## Incidencia corregida
La captura del usuario continuaba mostrando el arte previo con el texto «DOMIN…». En el ZIP fuente, la ilustración SVG más reciente no tenía texto, pero el servidor entregaba archivos `.svg` con `Cache-Control: public, max-age=86400`; como la URL no había cambiado, el navegador podía conservar el recurso anterior durante 24 horas.

## Corrección aplicada
- Se creó `public/images/domino-cover-v2.svg`, con ilustración 1200×500 sin elementos de texto.
- `public/index.html` apunta a `/images/domino-cover-v2.svg`, invalidando la URL cacheada anteriormente.
- `public/styles.css` fuerza proporción 12:5 en todos los tamaños y muestra el SVG nuevo a escala de portada.
- `server.js` sirve `.html` y `.svg` con `Cache-Control: no-cache`.
- Se eliminó el SVG anterior para evitar referencias ambiguas.

## Verificación
- Pruebas automatizadas del proyecto.
- Sintaxis de servidores, reglas y clientes.
- Renderizado del SVG a PNG: 1200×500.
- Verificación de que la nueva ilustración no contiene texto.
