# Revisión técnica – Juegos de mesa no tan de mesa 1.0.2

## Rummikub Online Club 1.4.0

- Las escaleras se validan de 3 a 13 fichas consecutivas del mismo color.
- Los conjuntos se mantienen entre 3 y 4 fichas del mismo número y colores distintos; no se elimina esa restricción porque es parte de las reglas de Rummikub.
- La validación se comparte entre servidor y cliente mediante `Rummikub_Online/rules.js` y una validación espejo del contador de apertura.
- La IA también puede extender escaleras existentes hasta el máximo natural de 13 fichas.
- Efectos sonoros sintetizados con Web Audio, con control de silencio y preferencia guardada localmente. Si el navegador no ofrece Web Audio, la partida sigue funcionando sin sonido.
- Cinco nuevos acabados visuales: Océano, Cristal, Bosque, Cobre y Atardecer.
- Ajustes de tamaños mínimos de tipografía y controles, especialmente en pantallas pequeñas.

## Pruebas

- 6 pruebas nuevas de reglas de combinación: escaleras largas, límite 1–13, exceso del límite, conjuntos, secuencias con huecos y comodín en escalera larga.
- 3 pruebas existentes de puntuación de apertura.
- Comprobación sintáctica de `server.js`, `rules.js` y `public/client.js`.

## Alcance y limitaciones de verificación

Las pruebas automatizadas de reglas y sintaxis pasan. No se ha ejecutado una partida multijugador real en Render durante esta revisión; la confirmación de sonidos depende de que el navegador permita activar Web Audio después de la primera interacción del usuario.

BioDefensa y su código no se han modificado en esta actualización.


## Parqués Club 1.0.0
- Se añadieron pruebas unitarias para tableros 4/6, salida con 5, consumo de dados, movimientos secuenciales, capturas, casillas seguras, barreras, llegada exacta, pares, penalización opcional y estrategia de IA.
- El servidor valida turnos y movimientos; el navegador solamente presenta opciones comunicadas por el servidor.
- Salas online en memoria; no hay persistencia tras reinicio.
- No se ha podido ejecutar una partida real con navegador y sockets en este entorno porque las dependencias npm no están instaladas aquí; la sintaxis, reglas puras y pruebas unitarias sí se pueden verificar localmente.


## Parqués Club 1.1.0 — revisión actual
- El recorrido se dibuja como circuito perimetral cuadrado con casillas en cuadrícula, casas de jugador, carriles de llegada y centro sectorizado según el número de puestos.
- Se eliminó la lógica `pathIsBlocked`; las acumulaciones no bloquean el recorrido. Una captura en casilla no segura devuelve a casa todas las fichas rivales que compartan el destino.
- `createGame` conserva colores de jugador válidos y únicos; el servidor sanea los nombres de avatar y asigna colores libres en salas de 4 o 6 participantes.
- Se añadió selección local de avatar y color para partidas IA y online.
- El estado `lastDice` conserva el último resultado aunque `finishTurn` limpie los dados activos. La interfaz anima el lanzamiento antes de pedir los valores oficiales al servidor.
- Pruebas de Parqués: 24/24 aprobadas. Suite completa de la plataforma: 57/57 aprobadas. `npm run check` pasó.
- Limitación de verificación: no se pudo completar una captura automatizada de navegador en este entorno; se verificaron sintaxis, reglas, HTML de integración y estado de dados mediante pruebas automatizadas. Se recomienda probar el selector y un lanzamiento desde Render tras el despliegue.
