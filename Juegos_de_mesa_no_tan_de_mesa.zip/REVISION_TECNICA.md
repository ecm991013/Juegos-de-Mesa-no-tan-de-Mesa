# Juegos de mesa no tan de mesa

Plataforma con tres juegos web independientes: BioDefensa, Rummikub Online Club y Dominó Club.

## Despliegue
Sube el ZIP `Juegos_de_mesa_no_tan_de_mesa.zip` junto con `render.yaml` a GitHub. Render extrae el ZIP durante el build, instala las dependencias raíz e inicia el portal con `npm start`.

## Última actualización · 1.8.2
- La tarjeta de Dominó utiliza la portada `domino-cover-v3.png` (2400 × 1000).
- La imagen se escala con anchura completa y altura proporcional; el marco completo queda visible y no se recorta.
- El enlace de la imagen cambia de versión para que el navegador no reutilice el recurso anterior.
- HTML, CSS, JavaScript y SVG usan `Cache-Control: no-cache`; además, las hojas CSS y scripts utilizan URLs versionadas.
- BioDefensa y Rummikub conservan sus reglas y archivos.


## Dominó Club 1.6.0
- Previsualización en vivo del acabado de fichas y color del paño.
- Las fichas de la mano no se resaltan ni deshabilitan individualmente según su jugada; el jugador decide y el servidor valida.
- Recorrido serpenteante: las filas alternan derecha e izquierda y se conectan con curvas visuales.


### Dominó Club 1.7.0

La cadena se distribuye en varias filas conectadas, no en una sola línea horizontal. Cada fila alterna su sentido: avanza a la derecha, gira al siguiente tramo y vuelve a la izquierda. El número de fichas por fila se calcula según el ancho del tablero y se vuelve a calcular al cambiar el tamaño de pantalla. Al arrastrar una ficha, el extremo de destino se decide por proximidad al primer o último elemento visible de la cadena.


## Dominó Club 1.8.2 — mano y recorrido
- La ficha de apertura queda centrada respecto al área útil visible de la mesa, descontando el padding superior e inferior del escenario.
- La cadena crece desde la ficha inicial hacia los extremos izquierdo y derecho.
- El usuario puede ordenar manualmente su mano arrastrando fichas sobre otras.
- Al soltar una ficha por debajo o por encima del extremo, puede indicar que el próximo tramo doble hacia abajo o arriba; también puede escogerlo con los controles de dirección.
- Las fichas dobles y normales conservan dimensiones idénticas en horizontal y vertical, también en móvil.
- Se amplían las pruebas de arrastre, orden manual, apertura centrada y giros en ambos lados.


## Versión 1.8.2 — distribución del tablero de Dominó
- Se ajustó el centro vertical de la ficha inicial para calcularse dentro del área de contenido de `chainStage`, descontando el padding real del escenario. Esto evita que la ficha quede visualmente desplazada hacia abajo.
- Se mantuvo el punto de apertura centrado y las ramas izquierda/derecha.
- La mano admite reordenación libre por arrastre entre fichas.
- El usuario puede marcar el siguiente giro de una rama soltando por encima/debajo del extremo o usando los controles «Seguir recto», «Doblar arriba» y «Doblar abajo».
- Se añadieron pruebas de giro en la rama izquierda y de dimensiones físicas uniformes para fichas dobles y normales.


## Revisión 1.8.2 — Dominó
- Corregido el cálculo de `centerY`: antes utilizaba la altura completa del escenario aunque la cadena se renderiza dentro de su caja de contenido, debajo del padding. Ahora el centro se calcula con `clientHeight - paddingTop - paddingBottom` usando los estilos computados y fallback móvil/escritorio.
- Confirmado que `openingTileId` mantiene la ficha inicial anclada al centro y que los brazos se distribuyen hacia ambos lados.
- Se ampliaron pruebas de puntero para soltar en cada extremo, activar giro hacia abajo y reordenar la mano.
- Se añadieron pruebas para giros hacia abajo en el brazo izquierdo y dimensiones idénticas para fichas normales/dobles.
- Suite completa: 91 pruebas aprobadas; verificación de sintaxis de servidores, clientes y módulo de layout superada.
- No se modificaron las reglas de BioDefensa ni Rummikub.
