# Revisión técnica · Versión 1.5.3

## Incidencia
La portada de Dominó se veía ampliada y cortada dentro de la tarjeta del catálogo. La tarjeta imponía una altura fija y la imagen usaba `object-fit: cover`, lo que permitía recortar el marco de la ilustración. Además, CSS y JavaScript del portal podían quedar almacenados en caché durante 24 horas.

## Correcciones
- La tarjeta `domino-art` ya no impone altura fija ni relación de aspecto; su altura se calcula a partir de la imagen.
- La portada se muestra como imagen de flujo normal con `width: 100%; height: auto`, sin `object-fit: cover` ni posicionamiento absoluto.
- Se creó `public/images/domino-cover-v3.png`, 2400 × 1000, con URL inédita para invalidar recursos antiguos.
- HTML, CSS, JavaScript y SVG usan `Cache-Control: no-cache`.
- Se versionaron las URL de CSS y JavaScript de portal y Dominó.

## Verificación
- Imagen PNG válida y dimensiones verificadas: 2400 × 1000.
- Sintaxis de servidores, reglas y clientes JavaScript comprobada.
- Suite automatizada completa: 75 pruebas aprobadas.
- No se modificaron las mecánicas de BioDefensa, Rummikub ni Dominó.
