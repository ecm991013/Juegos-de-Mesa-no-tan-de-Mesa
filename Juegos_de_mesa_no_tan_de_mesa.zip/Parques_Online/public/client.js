(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const socket = window.io ? io({ path: '/parques/socket.io', transports: ['websocket', 'polling'], reconnection: true }) : null;
  const COLORS = {
    coral: '#ee6f62', ocean: '#61a8ef', sun: '#f3cb63', jade: '#6bc18c', violet: '#a68be8', tangerine: '#ec9a5c'
  };
  const COLOR_LABELS = { coral: 'coral', ocean: 'azul', sun: 'amarillo', jade: 'verde', violet: 'violeta', tangerine: 'naranja' };
  const THEME_LABELS = { classic: 'Clásico', jungle: 'Esmeralda', caribbean: 'Caribe', royal: 'Real' };
  const DIFFICULTY_LABELS = { easy: 'Fácil', normal: 'Normal', hard: 'Difícil' };
  const AVATARS = Array.from({ length: 8 }, (_, index) => `person${index + 1}.webp`);
  const COLOR_OPTIONS = [
    { id: 'coral', label: 'Rojo coral', value: COLORS.coral },
    { id: 'ocean', label: 'Azul', value: COLORS.ocean },
    { id: 'sun', label: 'Amarillo', value: COLORS.sun },
    { id: 'jade', label: 'Verde', value: COLORS.jade },
    { id: 'violet', label: 'Violeta', value: COLORS.violet },
    { id: 'tangerine', label: 'Naranja', value: COLORS.tangerine }
  ];
  let selectedAvatar = 'person8.webp';
  let selectedColor = 'coral';
  let rollingDice = false;
  let diceAnimationTimer = null;
  let mode = 'ai';
  let seats = 4;
  let difficulty = 'normal';
  let theme = 'classic';
  let room = null;
  let selectedDieIndex = null;
  let toastTimer = null;
  let lastDiceSignature = '';

  function notify(message) {
    const toast = $('toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
  }

  function selectMode(value) {
    mode = value;
    document.querySelectorAll('.mode-button').forEach(button => {
      const active = button.dataset.mode === mode;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    $('difficultyBlock').hidden = mode !== 'ai';
    $('startAiButton').hidden = mode !== 'ai';
    $('onlineCreateBlock').hidden = mode !== 'online';
    $('setupFootnote');
  }

  function setSeats(value) {
    seats = Number(value) === 6 ? 6 : 4;
    document.querySelectorAll('.seat-button').forEach(button => {
      const active = Number(button.dataset.seats) === seats;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    renderPieceColorChoices();
  }

  function renderAvatarChoices() {
    $('avatarChoices').innerHTML = AVATARS.map((avatar, index) => `
      <button type="button" class="avatar-choice ${avatar === selectedAvatar ? 'active' : ''}" data-avatar-choice="${avatar}" aria-label="Avatar ${index + 1}" aria-pressed="${avatar === selectedAvatar}">
        <img src="/parques/assets/avatars/${avatar}" alt="Retrato ${index + 1}" loading="lazy">
        <span class="avatar-check">✓</span>
      </button>`).join('');
    $('avatarChoices').querySelectorAll('[data-avatar-choice]').forEach(button => button.addEventListener('click', () => {
      selectedAvatar = button.dataset.avatarChoice;
      renderAvatarChoices();
    }));
  }

  function renderPieceColorChoices() {
    const options = COLOR_OPTIONS.slice(0, seats);
    if (!options.some(option => option.id === selectedColor)) selectedColor = options[0].id;
    $('pieceColorChoices').innerHTML = options.map(option => `
      <button type="button" class="piece-color-choice ${option.id === selectedColor ? 'active' : ''}" data-piece-color="${option.id}" aria-label="${option.label}" aria-pressed="${option.id === selectedColor}">
        <i style="--swatch:${option.value}"></i><span>${option.label}</span><b>✓</b>
      </button>`).join('');
    $('pieceColorChoices').querySelectorAll('[data-piece-color]').forEach(button => button.addEventListener('click', () => {
      selectedColor = button.dataset.pieceColor;
      renderPieceColorChoices();
    }));
  }

  function setDifficulty(value) {
    difficulty = ['easy', 'normal', 'hard'].includes(value) ? value : 'normal';
    document.querySelectorAll('.difficulty-button').forEach(button => {
      const active = button.dataset.difficulty === difficulty;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
  }

  function setTheme(value) {
    theme = Object.prototype.hasOwnProperty.call(THEME_LABELS, value) ? value : 'classic';
    document.body.dataset.theme = theme;
    document.querySelectorAll('.theme-button').forEach(button => {
      const active = button.dataset.themeChoice === theme;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
  }

  function getPlayerName() {
    return ($('playerName').value || '').trim().slice(0, 18) || 'Jugador';
  }

  function showScreen(screen) {
    $('setupScreen').hidden = screen !== 'setup';
    $('waitingScreen').hidden = screen !== 'waiting';
    $('gameScreen').hidden = screen !== 'game';
  }

  function createAiGame() {
    if (!socket) return notify('No se pudo conectar con el servidor. Recarga la página.');
    socket.emit('createAiGame', {
      playerName: getPlayerName(), playerAvatar: selectedAvatar, playerColor: selectedColor,
      playerCount: seats, difficulty, theme,
      tripleDoublePenalty: $('tripleDouble').checked
    });
  }

  function createOnlineRoom() {
    if (!socket) return notify('No se pudo conectar con el servidor. Recarga la página.');
    socket.emit('createOnlineRoom', { playerName: getPlayerName(), playerAvatar: selectedAvatar, playerColor: selectedColor, playerCount: seats, theme });
  }

  function joinRoom(code) {
    const roomCode = String(code || $('joinCode').value).trim().toUpperCase();
    if (!roomCode) return notify('Escribe el código de la sala.');
    socket.emit('joinRoom', { code: roomCode, playerName: getPlayerName(), playerAvatar: selectedAvatar, playerColor: selectedColor });
  }

  function playerColor(player) { return COLORS[player.color] || '#d8c28d'; }
  function avatarUrl(player) { return `/parques/assets/avatars/${encodeURIComponent(player.avatar || 'person8.webp')}`; }
  function escapeXml(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[char]);
  }

  function perimeterPoint(index, length) {
    const perSide = length / 4;
    const side = Math.floor(index / perSide);
    const offset = index % perSide;
    const t = (offset + 0.5) / perSide;
    const min = 238, max = 762;
    if (side === 0) return { x: min + t * (max - min), y: min };
    if (side === 1) return { x: max, y: min + t * (max - min) };
    if (side === 2) return { x: max - t * (max - min), y: max };
    return { x: min, y: max - t * (max - min) };
  }

  function homeCenter(player, game) {
    const start = perimeterPoint(player.startIndex, game.trackLength);
    const dx = start.x - 500, dy = start.y - 500;
    return {
      x: Math.max(112, Math.min(888, 500 + dx * 1.42)),
      y: Math.max(112, Math.min(888, 500 + dy * 1.42))
    };
  }

  function pileOffset(index, count, radius = 9) {
    if (count <= 1) return { x: 0, y: 0 };
    const angle = (-Math.PI / 2) + (Math.PI * 2 * index / count);
    const adjustedRadius = count > 6 ? radius + 2 : radius;
    return { x: Math.cos(angle) * adjustedRadius, y: Math.sin(angle) * adjustedRadius };
  }

  function tokenPoint(player, token, game, pileIndex = 0) {
    if (token.finished) {
      const center = { x: 500, y: 500 };
      const start = perimeterPoint(player.startIndex, game.trackLength);
      const dx = center.x - start.x, dy = center.y - start.y;
      const distance = Math.max(1, Math.hypot(dx, dy));
      const base = { x: center.x - dx / distance * 42, y: center.y - dy / distance * 42 };
      const offset = pileOffset(pileIndex, 4, 10);
      return { x: base.x + offset.x, y: base.y + offset.y };
    }
    if (token.progress < 0) {
      const home = homeCenter(player, game);
      const offsets = [[-25, -25], [25, -25], [-25, 25], [25, 25]];
      return { x: home.x + offsets[pileIndex % 4][0], y: home.y + offsets[pileIndex % 4][1] };
    }
    if (token.progress >= game.trackLength) {
      const laneIndex = token.progress - game.trackLength;
      const t = (laneIndex + 1) / (game.homeLength + 1);
      const start = perimeterPoint(player.startIndex, game.trackLength);
      const point = { x: start.x + (500 - start.x) * t, y: start.y + (500 - start.y) * t };
      const dx = 500 - start.x, dy = 500 - start.y;
      const distance = Math.max(1, Math.hypot(dx, dy));
      const offset = pileOffset(pileIndex, 4, 8);
      return { x: point.x + (-dy / distance) * offset.x + (dx / distance) * offset.y, y: point.y + (dx / distance) * offset.x + (dy / distance) * offset.y };
    }
    const trackIndex = (player.startIndex + token.progress) % game.trackLength;
    return perimeterPoint(trackIndex, game.trackLength);
  }

  function boardSvg(game) {
    const activePlayer = game.players[game.turnIndex];
    const moves = game.legalMoves || [];
    const activeMoves = activePlayer?.id === socket?.id ? moves : [];
    const legalTokenIds = new Set(activeMoves.filter(move => selectedDieIndex === null || move.dieIndex === selectedDieIndex).map(move => move.tokenId));
    const trackSize = game.trackLength === 72 ? 23 : 26;
    const cells = [];
    const houses = [];
    const lanes = [];
    const startPlayers = new Map(game.players.map(player => [player.startIndex, player]));

    // Cuatro esquinas/cuadrantes de casa, como el tablero tradicional de Parqués.
    for (const player of game.players) {
      const center = homeCenter(player, game);
      const color = playerColor(player);
      const boxSize = game.playerCount === 6 ? 142 : 164;
      const x = center.x - boxSize / 2, y = center.y - boxSize / 2;
      houses.push(`<g class="parques-home"><rect x="${x}" y="${y}" width="${boxSize}" height="${boxSize}" rx="17" fill="${color}" fill-opacity=".19" stroke="${color}" stroke-width="4"/><rect x="${x+9}" y="${y+9}" width="${boxSize-18}" height="${boxSize-18}" rx="12" fill="#102c25" fill-opacity=".83" stroke="#f1dfb6" stroke-opacity=".38" stroke-width="2"/><text x="${center.x}" y="${y+25}" text-anchor="middle" font-size="12" font-weight="800" letter-spacing="1.5" fill="#f3e8ce">${escapeXml(player.name.slice(0,12).toUpperCase())}</text><text x="${center.x}" y="${y+boxSize-12}" text-anchor="middle" font-size="8" font-weight="700" letter-spacing="2" fill="${color}">CASA</text></g>`);
      const start = perimeterPoint(player.startIndex, game.trackLength);
      for (let j = 0; j < game.homeLength; j++) {
        const t = (j + 1) / (game.homeLength + 1);
        const point = { x: start.x + (500 - start.x) * t, y: start.y + (500 - start.y) * t };
        lanes.push(`<rect x="${point.x-13}" y="${point.y-13}" width="26" height="26" rx="5" fill="${color}" stroke="#fff0c8" stroke-width="2"/><rect x="${point.x-7}" y="${point.y-7}" width="14" height="14" rx="3" fill="#fff" fill-opacity=".14"/>`);
      }
    }

    // Circuito perimetral de casillas cuadradas y alineadas, en lugar del aro de círculos.
    for (let i = 0; i < game.trackLength; i++) {
      const point = perimeterPoint(i, game.trackLength);
      const startPlayer = startPlayers.get(i);
      const safe = game.safeSquares.includes(i);
      const fill = startPlayer ? playerColor(startPlayer) : safe ? '#e6c982' : '#f0eadb';
      const stroke = startPlayer ? '#fff0cb' : safe ? '#8f6c31' : '#a9a18e';
      const radius = game.trackLength === 72 ? 5 : 6;
      cells.push(`<g class="track-cell"><rect x="${point.x-trackSize/2}" y="${point.y-trackSize/2}" width="${trackSize}" height="${trackSize}" rx="${radius}" fill="#071b16" opacity=".35" transform="translate(0 3)"/><rect x="${point.x-trackSize/2}" y="${point.y-trackSize/2}" width="${trackSize}" height="${trackSize}" rx="${radius}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>${safe ? `<path d="M${point.x} ${point.y-6} l2 4 4 2 -4 2 -2 4 -2 -4 -4 -2 4 -2Z" fill="${startPlayer ? '#fff1d0' : '#9a7439'}"/>` : ''}</g>`);
    }

    // Colocar cualquier cantidad de fichas sobre la misma casilla sin ocultarlas por completo.
    const stackGroups = new Map();
    for (const player of game.players) {
      for (const token of player.tokens) {
        if (token.progress < 0) continue;
        let key;
        if (token.finished) key = `finished:${player.id}`;
        else if (token.progress >= game.trackLength) key = `lane:${player.id}:${token.progress}`;
        else key = `track:${(player.startIndex + token.progress) % game.trackLength}`;
        if (!stackGroups.has(key)) stackGroups.set(key, []);
        stackGroups.get(key).push({ player, token });
      }
    }
    const stackPositions = new Map();
    for (const group of stackGroups.values()) group.forEach((record, index) => stackPositions.set(record.token.id, { index, count: group.length }));

    const tokens = [];
    for (const player of game.players) {
      player.tokens.forEach((token, index) => {
        const stack = stackPositions.get(token.id);
        let point;
        if (token.progress < 0) point = tokenPoint(player, token, game, index);
        else if (stack) {
          const base = tokenPoint(player, token, game, 0);
          const offset = pileOffset(stack.index, stack.count, stack.count > 4 ? 9 : 7);
          point = { x: base.x + offset.x, y: base.y + offset.y };
        } else point = tokenPoint(player, token, game, 0);
        const isMovable = player.id === socket?.id && player.id === activePlayer?.id && legalTokenIds.has(token.id);
        const color = playerColor(player);
        const count = stack?.count || 1;
        const size = count > 5 ? 8 : count > 2 ? 10 : 12;
        tokens.push(`<g class="board-token ${isMovable ? 'movable' : ''}" data-token-id="${escapeXml(token.id)}" role="button" tabindex="${isMovable ? '0' : '-1'}" aria-label="Ficha ${index + 1} de ${escapeXml(player.name)}${isMovable ? ', disponible para mover' : ''}" style="--token-color:${color}"><circle class="token-shadow" cx="${point.x}" cy="${point.y+3}" r="${size+1}"/><circle class="token-outer" cx="${point.x}" cy="${point.y}" r="${size}" fill="${color}" stroke="#fff4db" stroke-width="1.8"/><circle cx="${point.x-size*.3}" cy="${point.y-size*.34}" r="${Math.max(1.8,size*.19)}" fill="#fff" opacity=".72"/><text x="${point.x}" y="${point.y+size*.31}" text-anchor="middle" font-size="${size*.78}" font-weight="900" fill="#172c22">${index+1}</text></g>`);
      });
    }

    const centerWedges = game.players.map((player, index) => {
      const a1 = -Math.PI / 2 + index * Math.PI * 2 / game.players.length;
      const a2 = -Math.PI / 2 + (index + 1) * Math.PI * 2 / game.players.length;
      const p1 = { x: 500 + Math.cos(a1) * 88, y: 500 + Math.sin(a1) * 88 };
      const p2 = { x: 500 + Math.cos(a2) * 88, y: 500 + Math.sin(a2) * 88 };
      return `<path d="M500 500 L${p1.x} ${p1.y} A88 88 0 0 1 ${p2.x} ${p2.y} Z" fill="${playerColor(player)}" fill-opacity=".84" stroke="#f5e5bf" stroke-opacity=".76" stroke-width="1.5"/>`;
    }).join('');
    const center = `<rect x="385" y="385" width="230" height="230" rx="18" fill="#f0eadb" stroke="#6f5131" stroke-width="8"/><rect x="400" y="400" width="200" height="200" rx="12" fill="#123c2d" stroke="#dfc27f" stroke-width="3"/><circle cx="500" cy="500" r="90" fill="#183e2e" stroke="#e3c785" stroke-width="3"/>${centerWedges}<circle cx="500" cy="500" r="34" fill="#f2dfb1" stroke="#7f6036" stroke-width="4"/><text x="500" y="507" text-anchor="middle" font-size="23" font-family="Georgia,serif" font-weight="900" fill="#21412e">P</text><text x="500" y="563" text-anchor="middle" font-size="10" font-weight="900" letter-spacing="3" fill="#f7e9c5">PARQUÉS</text>`;

    return `<defs>
      <linearGradient id="feltGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--felt)"/><stop offset="1" stop-color="var(--felt2)"/></linearGradient>
      <linearGradient id="woodGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ba9160"/><stop offset=".5" stop-color="#704a2e"/><stop offset="1" stop-color="#3d281d"/></linearGradient>
      <pattern id="feltTexture" width="18" height="18" patternUnits="userSpaceOnUse"><path d="M0 9H18M9 0V18" stroke="#fff" stroke-opacity=".025" stroke-width="1"/></pattern>
      <filter id="tokenDrop" x="-50%" y="-50%" width="200%" height="200%"><feDropShadow dx="0" dy="3" stdDeviation="2" flood-color="#000" flood-opacity=".4"/></filter>
    </defs>
    <rect width="1000" height="1000" rx="34" fill="url(#woodGrad)"/>
    <rect x="35" y="35" width="930" height="930" rx="29" fill="url(#feltGrad)" stroke="#e0c68e" stroke-width="15"/>
    <rect x="50" y="50" width="900" height="900" rx="22" fill="url(#feltTexture)" stroke="#f5e7c7" stroke-opacity=".32" stroke-width="2"/>
    <rect x="220" y="220" width="560" height="560" rx="8" fill="none" stroke="#f4e7c9" stroke-opacity=".2" stroke-width="3"/>
    ${houses.join('')}${cells.join('')}${lanes.join('')}${center}${tokens.join('')}`;
  }

  function renderWaiting() {
    if (!room) return;
    $('roomCode').textContent = room.code;
    $('waitingCount').textContent = `${room.players.length} / ${room.capacity} jugadores`;
    $('waitingProgress').style.width = `${room.players.length / room.capacity * 100}%`;
    $('waitingPlayers').innerHTML = Array.from({ length: room.capacity }, (_, index) => {
      const player = room.players[index];
      if (!player) return `<div class="waiting-player empty"><img src="/parques/assets/avatars/person8.webp" alt=""><div><strong>Puesto libre</strong><small>Esperando jugador…</small></div></div>`;
      return `<div class="waiting-player" style="--player-color:${playerColor(player)}"><img src="${avatarUrl(player)}" alt=""><div><strong>${escapeHtml(player.name)}</strong><small>${COLOR_LABELS[player.color] || 'Equipo'} · ${player.id === room.hostId ? 'Anfitrión' : 'Conectado'}</small></div></div>`;
    }).join('');
    const isHost = room.hostId === socket?.id;
    const full = room.players.length === room.capacity;
    $('startOnlineButton').hidden = !isHost;
    $('startOnlineButton').disabled = !full;
    $('startOnlineButton').textContent = full ? 'Iniciar partida' : `Esperando ${room.capacity - room.players.length} jugador(es)…`;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  }

  function renderPlayers(game) {
    const active = game.players[game.turnIndex];
    $('playerStrip').innerHTML = game.players.map(player => {
      const finished = player.tokens.filter(token => token.finished).length;
      const home = player.tokens.filter(token => token.progress < 0).length;
      const detail = player.isAI ? `${DIFFICULTY_LABELS[player.difficulty] || 'IA'} · ${finished}/4 en meta` : `${finished}/4 en meta · ${home} en casa`;
      return `<div class="player-card ${active?.id === player.id ? 'active' : ''}" style="--player-color:${playerColor(player)}"><img src="${avatarUrl(player)}" alt=""><div style="min-width:0"><strong>${escapeHtml(player.name)}${player.id === socket?.id ? ' (tú)' : ''}</strong><small>${detail}</small></div><i class="player-dot"></i></div>`;
    }).join('');
  }

  function diePipsMarkup(value) {
    const pips = {
      1: [4], 2: [0, 8], 3: [0, 4, 8],
      4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8], 6: [0, 2, 3, 5, 6, 8]
    }[value] || [];
    return Array.from({ length: 9 }, (_, i) => pips.includes(i)
      ? `<i class="pip" style="grid-row:${Math.floor(i / 3) + 1};grid-column:${(i % 3) + 1}"></i>`
      : '<span></span>').join('');
  }

  function createDie(value, index, game, historical = false, rolling = false) {
    const remaining = !historical && game.remainingDice.includes(index);
    const hasMove = (game.legalMoves || []).some(move => move.dieIndex === index);
    const canUse = !historical && remaining && hasMove && game.players[game.turnIndex]?.id === socket?.id;
    const selected = selectedDieIndex === index && canUse;
    const displayState = historical ? 'historical' : remaining ? '' : 'used';
    return `<button class="die ${displayState} ${remaining && !hasMove ? 'unusable' : ''} ${selected ? 'selected' : ''} ${rolling ? 'rolling' : ''}" data-die-index="${index}" ${canUse ? '' : 'disabled'} aria-label="Dado ${index + 1}: ${value}">${diePipsMarkup(value)}<span class="die-value">${value}</span></button>`;
  }

  function showRollingDice() {
    const values = [1 + Math.floor(Math.random() * 6), 1 + Math.floor(Math.random() * 6)];
    $('diceArea').innerHTML = values.map((value, index) => createDie(value, index, { remainingDice: [], legalMoves: [], players: [], turnIndex: -1 }, true, true)).join('');
    $('diceSummary').textContent = 'Los dados están rodando…';
  }

  function animateAndRollDice() {
    if (rollingDice || !socket || !room?.game) return;
    rollingDice = true;
    $('rollButton').disabled = true;
    $('rollButton').textContent = '🎲 Lanzando…';
    $('diceHint').textContent = 'Agitando los dados';
    $('diceArea').classList.add('dice-rolling');
    let frames = 0;
    showRollingDice();
    diceAnimationTimer = setInterval(() => {
      showRollingDice();
      frames += 1;
      if (frames >= 9) {
        clearInterval(diceAnimationTimer);
        diceAnimationTimer = null;
        rollingDice = false;
        $('diceArea').classList.remove('dice-rolling');
        $('rollButton').textContent = 'Dados lanzados';
        socket.emit('rollDice');
      }
    }, 105);
  }

  function renderMoves(game) {
    const legal = game.legalMoves || [];
    const activePlayer = game.players[game.turnIndex];
    const isMyTurn = activePlayer?.id === socket?.id;
    const choices = legal.filter(move => selectedDieIndex === null || move.dieIndex === selectedDieIndex);
    $('movesCount').textContent = isMyTurn ? `${choices.length} opción(es)` : 'Espera';
    if (!isMyTurn) {
      $('movesHelp').textContent = `${activePlayer?.name || 'Otro jugador'} está realizando su turno.`;
      $('movesList').innerHTML = '';
      return;
    }
    if (game.phase === 'roll') {
      $('movesHelp').textContent = 'Lanza los dos dados. Un 5 permite sacar una ficha de casa.';
      $('movesList').innerHTML = '';
      return;
    }
    if (!legal.length) {
      $('movesHelp').textContent = 'No tienes movimientos posibles. El turno pasará automáticamente.';
      $('movesList').innerHTML = '';
      return;
    }
    $('movesHelp').textContent = 'Elige un dado y después la ficha que quieres mover.';
    $('movesList').innerHTML = choices.map(move => {
      const tokenIndex = activePlayer.tokens.findIndex(token => token.id === move.tokenId);
      const label = move.launch ? 'Sacar ficha de casa' : move.finish ? 'Entrar a la meta' : `Mover ficha ${tokenIndex + 1}`;
      const detail = move.captureIds.length ? 'Captura una ficha rival' : `Avanza ${move.dieValue} casillas`;
      return `<button class="move-option" data-move-token="${escapeHtml(move.tokenId)}" data-move-die="${move.dieIndex}"><span class="move-die">${move.dieValue}</span><span><strong>${label}</strong><small>${detail}</small></span><span class="move-arrow">›</span></button>`;
    }).join('');
  }

  function renderGame() {
    if (!room?.game) return;
    const game = room.game;
    document.body.dataset.theme = room.theme || theme;
    const active = game.players[game.turnIndex];
    const myTurn = active?.id === socket?.id;
    const legalDice = new Set((game.legalMoves || []).map(move => move.dieIndex));
    if (selectedDieIndex !== null && (!game.remainingDice.includes(selectedDieIndex) || (legalDice.size && !legalDice.has(selectedDieIndex)))) selectedDieIndex = null;
    if (selectedDieIndex === null && game.remainingDice.length) selectedDieIndex = game.remainingDice.find(index => legalDice.has(index)) ?? game.remainingDice[0];
    $('gameRoomCode').textContent = room.mode === 'online' ? `SALA ${room.code}` : `${game.playerCount} PUESTOS · IA`;
    $('boardCaption').textContent = `${game.playerCount} PUESTOS · ${THEME_LABELS[room.theme] || 'Clásico'}`.toUpperCase();
    $('turnAvatar').src = active ? avatarUrl(active) : '/parques/assets/avatars/person8.webp';
    $('turnName').textContent = active?.name || 'Jugador';
    $('turnStatus').textContent = myTurn ? 'Es tu turno' : active?.isAI ? `${DIFFICULTY_LABELS[active.difficulty] || 'IA'} · pensando…` : 'Turno del rival';
    $('lastAction').textContent = game.lastAction || 'La partida está en curso.';
    $('boardSvg').innerHTML = boardSvg(game);
    renderPlayers(game);
    const shownDice = game.dice.length ? game.dice : (game.lastDice || []);
    const historicalDice = !game.dice.length && shownDice.length > 0;
    const signature = shownDice.join('-');
    if (signature && signature !== lastDiceSignature) {
      lastDiceSignature = signature;
      $('diceArea').classList.add('dice-updated');
    }
    if (!rollingDice) {
      $('diceArea').innerHTML = shownDice.length
        ? shownDice.map((value, index) => createDie(value, index, game, historicalDice)).join('')
        : '<div class="die die-empty">?</div><div class="die die-empty">?</div>';
    }
    const lastRoller = game.players.find(player => player.id === game.lastRoller);
    $('diceSummary').textContent = game.dice.length
      ? `Resultado: ${game.dice[0]} + ${game.dice[1]} = ${game.dice[0] + game.dice[1]}`
      : shownDice.length
        ? `Último tiro${lastRoller ? ` de ${lastRoller.name}` : ''}: ${shownDice[0]} + ${shownDice[1]} = ${shownDice[0] + shownDice[1]}`
        : 'Aún no has lanzado los dados';
    const canRoll = myTurn && game.phase === 'roll' && game.status === 'playing' && !rollingDice;
    $('rollButton').disabled = !canRoll;
    $('rollButton').textContent = rollingDice ? '🎲 Lanzando…' : canRoll ? '⚄ Lanzar dados' : myTurn ? 'Dados lanzados' : 'Esperando turno';
    $('diceHint').textContent = game.phase === 'roll' ? (myTurn ? 'Tu lanzamiento' : 'Turno del rival') : `${game.remainingDice.length} dado(s) pendiente(s)`;
    renderMoves(game);
    $('boardSvg').querySelectorAll('[data-token-id]').forEach(group => {
      group.addEventListener('click', () => {
        const tokenId = group.dataset.tokenId;
        const legal = (game.legalMoves || []).filter(move => move.tokenId === tokenId && (selectedDieIndex === null || move.dieIndex === selectedDieIndex));
        if (legal.length === 1) socket.emit('moveToken', { tokenId, dieIndex: legal[0].dieIndex });
        else if (legal.length > 1) notify('Elige primero qué dado quieres utilizar.');
        else if (myTurn && game.phase === 'move') notify('Esa ficha no puede moverse con el dado seleccionado.');
      });
      group.addEventListener('keydown', event => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); group.click(); }
      });
    });
    document.querySelectorAll('[data-die-index]').forEach(button => button.addEventListener('click', () => {
      selectedDieIndex = Number(button.dataset.dieIndex);
      renderGame();
    }));
    document.querySelectorAll('[data-move-token]').forEach(button => button.addEventListener('click', () => {
      socket.emit('moveToken', { tokenId: button.dataset.moveToken, dieIndex: Number(button.dataset.moveDie) });
    }));
    if (game.status === 'finished') {
      $('rollButton').disabled = true;
      $('rollButton').textContent = `${active?.name || 'Un jugador'} ganó`;
      $('movesHelp').textContent = 'La partida terminó. Puedes salir y crear otra mesa.';
    }
  }

  function handleRoomState(nextRoom) {
    room = nextRoom;
    selectedDieIndex = null;
    if (room.status === 'waiting') {
      showScreen('waiting');
      renderWaiting();
    } else {
      showScreen('game');
      renderGame();
    }
  }

  function resetToSetup() {
    if (diceAnimationTimer) clearInterval(diceAnimationTimer);
    diceAnimationTimer = null;
    rollingDice = false;
    if (room) socket.emit('leaveRoom');
    room = null;
    selectedDieIndex = null;
    lastDiceSignature = '';
    showScreen('setup');
  }

  document.querySelectorAll('.mode-button').forEach(button => button.addEventListener('click', () => selectMode(button.dataset.mode)));
  document.querySelectorAll('.seat-button').forEach(button => button.addEventListener('click', () => setSeats(button.dataset.seats)));
  document.querySelectorAll('.difficulty-button').forEach(button => button.addEventListener('click', () => setDifficulty(button.dataset.difficulty)));
  document.querySelectorAll('.theme-button').forEach(button => button.addEventListener('click', () => setTheme(button.dataset.themeChoice)));
  $('startAiButton').addEventListener('click', createAiGame);
  $('createRoomButton').addEventListener('click', createOnlineRoom);
  $('joinRoomButton').addEventListener('click', () => joinRoom());
  $('joinCode').addEventListener('input', event => { event.target.value = event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 5); });
  $('joinCode').addEventListener('keydown', event => { if (event.key === 'Enter') joinRoom(); });
  $('refreshRoomsButton').addEventListener('click', () => socket.emit('listOpenRooms'));
  $('startOnlineButton').addEventListener('click', () => socket.emit('startOnlineGame'));
  $('rollButton').addEventListener('click', animateAndRollDice);
  $('leaveWaitingButton').addEventListener('click', resetToSetup);
  $('leaveGameButton').addEventListener('click', resetToSetup);
  $('roomCodeButton').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(room?.code || ''); notify('Código copiado. Envíalo a tus amigos.'); }
    catch { notify(`Código de sala: ${room?.code || ''}`); }
  });

  if (socket) {
    socket.on('connect', () => { $('openRooms').innerHTML = '<p class="muted">Conectado. Pulsa actualizar para buscar partidas.</p>'; });
    socket.on('connect_error', () => notify('No se pudo conectar al servidor de Parqués.'));
    socket.on('roomCreated', data => { $('joinCode').value = data.code; notify(`Sala ${data.code} creada. Comparte el código.`); });
    socket.on('roomState', handleRoomState);
    socket.on('colorAssigned', data => {
      if (data?.color && Object.prototype.hasOwnProperty.call(COLORS, data.color)) {
        selectedColor = data.color;
        renderPieceColorChoices();
        notify(`Ese color ya estaba ocupado. Te asignamos ${COLOR_LABELS[selectedColor]}.`);
      }
    });
    socket.on('actionError', data => notify(data?.message || 'No se pudo realizar esa acción.'));
    socket.on('openRooms', rooms => {
      $('openRooms').innerHTML = rooms.length ? rooms.map(item => `<div class="open-room-item"><div><strong>${escapeHtml(item.host)} · ${item.code}</strong><small>${item.count}/${item.capacity} jugadores · ${THEME_LABELS[item.theme] || 'Clásico'}</small></div><button type="button" data-join-room="${item.code}">Unirme</button></div>`).join('') : '<p class="muted">No hay salas esperando jugadores. Crea una y comparte tu código.</p>';
      $('openRooms').querySelectorAll('[data-join-room]').forEach(button => button.addEventListener('click', () => joinRoom(button.dataset.joinRoom)));
    });
  } else {
    notify('No se cargó el módulo multijugador. Revisa la conexión.');
  }

  renderAvatarChoices();
  selectMode('ai');
  setSeats(4);
  setDifficulty('normal');
  setTheme('classic');
})();
