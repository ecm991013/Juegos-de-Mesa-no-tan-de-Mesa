(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const socket = window.io ? io({ path: '/parques/socket.io', transports: ['websocket', 'polling'], reconnection: true }) : null;
  const COLORS = {
    coral: '#ee6f62', ocean: '#61a8ef', sun: '#f3cb63', jade: '#6bc18c', violet: '#a68be8', tangerine: '#ec9a5c'
  };
  const COLOR_LABELS = { coral: 'coral', ocean: 'azul', sun: 'amarillo', jade: 'verde', violet: 'violeta', tangerine: 'naranja' };
  const THEME_LABELS = { classic: 'Clásico', jungle: 'Esmeralda', caribbean: 'Caribe', royal: 'Real' };
  const DIFFICULTY_LABELS = { easy: 'Fácil', normal: 'Normal', hard: 'Difícil' };
  let mode = 'ai';
  let seats = 4;
  let difficulty = 'normal';
  let theme = 'classic';
  let room = null;
  let selectedDieIndex = null;
  let toastTimer = null;
  let lastDiceSignature = '';

  function notify(message) {
    const toast = $('toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
  }

  function selectMode(value) {
    mode = value;
    document.querySelectorAll('.mode-button').forEach(button => {
      const active = button.dataset.mode === mode;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    $('difficultyBlock').hidden = mode !== 'ai';
    $('startAiButton').hidden = mode !== 'ai';
    $('onlineCreateBlock').hidden = mode !== 'online';
    $('setupFootnote');
  }

  function setSeats(value) {
    seats = Number(value) === 6 ? 6 : 4;
    document.querySelectorAll('.seat-button').forEach(button => {
      const active = Number(button.dataset.seats) === seats;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
  }

  function setDifficulty(value) {
    difficulty = ['easy', 'normal', 'hard'].includes(value) ? value : 'normal';
    document.querySelectorAll('.difficulty-button').forEach(button => {
      const active = button.dataset.difficulty === difficulty;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
  }

  function setTheme(value) {
    theme = Object.prototype.hasOwnProperty.call(THEME_LABELS, value) ? value : 'classic';
    document.body.dataset.theme = theme;
    document.querySelectorAll('.theme-button').forEach(button => {
      const active = button.dataset.themeChoice === theme;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
  }

  function getPlayerName() {
    return ($('playerName').value || '').trim().slice(0, 18) || 'Jugador';
  }

  function showScreen(screen) {
    $('setupScreen').hidden = screen !== 'setup';
    $('waitingScreen').hidden = screen !== 'waiting';
    $('gameScreen').hidden = screen !== 'game';
  }

  function createAiGame() {
    if (!socket) return notify('No se pudo conectar con el servidor. Recarga la página.');
    socket.emit('createAiGame', {
      playerName: getPlayerName(), playerCount: seats, difficulty, theme,
      tripleDoublePenalty: $('tripleDouble').checked
    });
  }

  function createOnlineRoom() {
    if (!socket) return notify('No se pudo conectar con el servidor. Recarga la página.');
    socket.emit('createOnlineRoom', { playerName: getPlayerName(), playerCount: seats, theme });
  }

  function joinRoom(code) {
    const roomCode = String(code || $('joinCode').value).trim().toUpperCase();
    if (!roomCode) return notify('Escribe el código de la sala.');
    socket.emit('joinRoom', { code: roomCode, playerName: getPlayerName() });
  }

  function playerColor(player) { return COLORS[player.color] || '#d8c28d'; }
  function avatarUrl(player) { return `/parques/assets/avatars/${encodeURIComponent(player.avatar || 'person8.webp')}`; }
  function escapeXml(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[char]);
  }

  function perimeterPoint(index, length) {
    const perSide = length / 4;
    const side = Math.floor(index / perSide);
    const offset = index % perSide;
    const step = 660 / perSide;
    const along = 170 + (offset + 0.5) * step;
    if (side === 0) return { x: along, y: 170 };
    if (side === 1) return { x: 830, y: along };
    if (side === 2) return { x: 830 - (offset + 0.5) * step, y: 830 };
    return { x: 170, y: 830 - (offset + 0.5) * step };
  }

  function tokenPoint(player, token, game, pileIndex = 0) {
    const center = { x: 500, y: 500 };
    if (token.finished) {
      const angle = (player.startIndex / game.trackLength) * Math.PI * 2 - Math.PI / 2;
      const radius = 65 + (pileIndex % 2) * 12;
      return { x: center.x + Math.cos(angle) * radius, y: center.y + Math.sin(angle) * radius };
    }
    if (token.progress < 0) {
      const start = perimeterPoint(player.startIndex, game.trackLength);
      const dx = start.x - center.x, dy = start.y - center.y;
      const distance = Math.max(1, Math.hypot(dx, dy));
      const base = { x: start.x + dx / distance * 51, y: start.y + dy / distance * 51 };
      const offsets = [[-13, -13], [13, -13], [-13, 13], [13, 13]];
      return { x: base.x + offsets[pileIndex % 4][0], y: base.y + offsets[pileIndex % 4][1] };
    }
    if (token.progress >= game.trackLength) {
      const laneIndex = token.progress - game.trackLength;
      const t = (laneIndex + 1) / (game.homeLength + 1);
      const start = perimeterPoint(player.startIndex, game.trackLength);
      const point = { x: start.x + (center.x - start.x) * t, y: start.y + (center.y - start.y) * t };
      const angle = Math.atan2(center.y - start.y, center.x - start.x) + Math.PI / 2;
      return { x: point.x + Math.cos(angle) * (pileIndex % 2 ? 7 : -7), y: point.y + Math.sin(angle) * (pileIndex % 2 ? 7 : -7) };
    }
    const trackIndex = (player.startIndex + token.progress) % game.trackLength;
    const point = perimeterPoint(trackIndex, game.trackLength);
    const angle = (trackIndex / game.trackLength) * Math.PI * 2;
    return { x: point.x + Math.cos(angle) * (pileIndex % 2 ? 7 : -7), y: point.y + Math.sin(angle) * (pileIndex % 2 ? 7 : -7) };
  }

  function boardSvg(game) {
    const width = 1000;
    const activePlayer = game.players[game.turnIndex];
    const moves = game.legalMoves || [];
    const activeMoves = activePlayer?.id === socket?.id ? moves : [];
    const legalTokenIds = new Set(activeMoves.filter(move => selectedDieIndex === null || move.dieIndex === selectedDieIndex).map(move => move.tokenId));
    const cellRadius = game.trackLength === 72 ? 13 : 15;
    const startIndices = new Set(game.players.map(player => player.startIndex));
    let cells = '';
    const homeLanes = [];
    const homeBases = [];
    for (let i = 0; i < game.trackLength; i++) {
      const point = perimeterPoint(i, game.trackLength);
      const safe = game.safeSquares.includes(i);
      const startPlayer = game.players.find(player => player.startIndex === i);
      const fill = startPlayer ? playerColor(startPlayer) : safe ? '#f1d79b' : '#e6dfc8';
      const stroke = startPlayer ? '#fff0c4' : safe ? '#9a783f' : '#9f9a88';
      cells += `<g><circle cx="${point.x}" cy="${point.y}" r="${cellRadius + 4}" fill="#10291f" opacity=".48"/><circle cx="${point.x}" cy="${point.y}" r="${cellRadius}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>${safe ? `<circle cx="${point.x}" cy="${point.y}" r="${cellRadius - 5}" fill="none" stroke="#8d6e3d" stroke-width="1" opacity=".75"/>` : ''}${startPlayer ? `<circle cx="${point.x}" cy="${point.y}" r="4" fill="#fff5d7"/>` : ''}</g>`;
    }
    for (const player of game.players) {
      const start = perimeterPoint(player.startIndex, game.trackLength);
      const color = playerColor(player);
      const dx = start.x - 500, dy = start.y - 500;
      const dist = Math.max(1, Math.hypot(dx, dy));
      const base = { x: start.x + dx / dist * 51, y: start.y + dy / dist * 51 };
      homeBases.push(`<circle cx="${base.x}" cy="${base.y}" r="43" fill="${color}" opacity=".14" stroke="${color}" stroke-width="3"/><circle cx="${base.x}" cy="${base.y}" r="34" fill="#142d23" stroke="${color}" stroke-width="2" stroke-dasharray="4 4"/>`);
      const lanePoints = [];
      for (let j = 0; j < game.homeLength; j++) {
        const t = (j + 1) / (game.homeLength + 1);
        const p = { x: start.x + (500 - start.x) * t, y: start.y + (500 - start.y) * t };
        lanePoints.push(p);
        homeLanes.push(`<circle cx="${p.x}" cy="${p.y}" r="${cellRadius - 1}" fill="${color}" fill-opacity=".78" stroke="#f5e8c7" stroke-width="1.5"/><circle cx="${p.x}" cy="${p.y}" r="4" fill="#fff" opacity=".28"/>`);
      }
    }
    const tokens = [];
    for (const player of game.players) {
      const allPositions = [];
      player.tokens.forEach((token, index) => {
        let pileIndex = 0;
        if (token.progress >= 0 && !token.finished) {
          const sameCell = player.tokens.filter(other => other.id !== token.id && other.progress === token.progress && !other.finished);
          pileIndex = sameCell.length ? index % 2 : 0;
        }
        const point = tokenPoint(player, token, game, token.progress < 0 ? index : pileIndex);
        const isMovable = player.id === socket?.id && player.id === activePlayer?.id && legalTokenIds.has(token.id);
        const color = playerColor(player);
        tokens.push(`<g class="board-token ${isMovable ? 'movable' : ''}" data-token-id="${escapeXml(token.id)}" role="button" tabindex="${isMovable ? '0' : '-1'}" aria-label="Ficha ${index + 1} de ${escapeXml(player.name)}${isMovable ? ', disponible para mover' : ''}" style="--token-color:${color}"><circle class="token-shadow" cx="${point.x}" cy="${point.y + 4}" r="16"/><circle class="token-outer" cx="${point.x}" cy="${point.y}" r="15" fill="${color}"/><circle cx="${point.x}" cy="${point.y}" r="9" fill="none" stroke="#fff" stroke-opacity=".75" stroke-width="1.5"/><circle cx="${point.x - 4}" cy="${point.y - 5}" r="3" fill="#fff" opacity=".65"/><text x="${point.x}" y="${point.y + 4}" text-anchor="middle" font-size="9" font-weight="900" fill="#24362d">${index + 1}</text></g>`);
      });
    }
    const centerDecor = `<rect x="365" y="365" width="270" height="270" rx="42" fill="#09281e" stroke="#d5b777" stroke-width="5"/><rect x="379" y="379" width="242" height="242" rx="33" fill="none" stroke="#e9d8ad" stroke-opacity=".36" stroke-width="2"/><path d="M500 395 L604 500 L500 605 L396 500Z" fill="#1a4e36" stroke="#cfad6b" stroke-width="2"/><circle cx="500" cy="500" r="53" fill="#e7d2a0" stroke="#8c6c39" stroke-width="5"/><text x="500" y="510" text-anchor="middle" font-size="36" font-family="Georgia,serif" font-weight="900" fill="#27412f">P</text><text x="500" y="568" text-anchor="middle" font-size="12" font-family="Arial,sans-serif" font-weight="800" letter-spacing="4" fill="#e9d7a9">PARQUÉS</text>`;
    return `<defs><linearGradient id="feltGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--felt)"/><stop offset="1" stop-color="var(--felt2)"/></linearGradient><linearGradient id="woodGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#9a7548"/><stop offset=".5" stop-color="#64432c"/><stop offset="1" stop-color="#38251c"/></linearGradient><filter id="tokenDrop" x="-50%" y="-50%" width="200%" height="200%"><feDropShadow dx="0" dy="3" stdDeviation="2" flood-color="#000" flood-opacity=".4"/></filter></defs><rect x="0" y="0" width="1000" height="1000" rx="45" fill="url(#woodGrad)"/><rect x="40" y="40" width="920" height="920" rx="46" fill="url(#feltGrad)" stroke="#d2b374" stroke-width="13"/><rect x="61" y="61" width="878" height="878" rx="34" fill="none" stroke="#f1dfb6" stroke-opacity=".25" stroke-width="2"/><rect x="145" y="145" width="710" height="710" rx="25" fill="none" stroke="#f3e6c8" stroke-opacity=".18" stroke-width="2"/>${homeBases.join('')}${homeLanes.join('')}${cells}${centerDecor}${tokens.join('')}`;
  }

  function renderWaiting() {
    if (!room) return;
    $('roomCode').textContent = room.code;
    $('waitingCount').textContent = `${room.players.length} / ${room.capacity} jugadores`;
    $('waitingProgress').style.width = `${room.players.length / room.capacity * 100}%`;
    $('waitingPlayers').innerHTML = Array.from({ length: room.capacity }, (_, index) => {
      const player = room.players[index];
      if (!player) return `<div class="waiting-player empty"><img src="/parques/assets/avatars/person8.webp" alt=""><div><strong>Puesto libre</strong><small>Esperando jugador…</small></div></div>`;
      return `<div class="waiting-player"><img src="${avatarUrl(player)}" alt=""><div><strong>${escapeHtml(player.name)}</strong><small>${player.id === room.hostId ? 'Anfitrión' : 'Conectado'}</small></div></div>`;
    }).join('');
    const isHost = room.hostId === socket?.id;
    const full = room.players.length === room.capacity;
    $('startOnlineButton').hidden = !isHost;
    $('startOnlineButton').disabled = !full;
    $('startOnlineButton').textContent = full ? 'Iniciar partida' : `Esperando ${room.capacity - room.players.length} jugador(es)…`;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  }

  function renderPlayers(game) {
    const active = game.players[game.turnIndex];
    $('playerStrip').innerHTML = game.players.map(player => {
      const finished = player.tokens.filter(token => token.finished).length;
      const home = player.tokens.filter(token => token.progress < 0).length;
      const detail = player.isAI ? `${DIFFICULTY_LABELS[player.difficulty] || 'IA'} · ${finished}/4 en meta` : `${finished}/4 en meta · ${home} en casa`;
      return `<div class="player-card ${active?.id === player.id ? 'active' : ''}" style="--player-color:${playerColor(player)}"><img src="${avatarUrl(player)}" alt=""><div style="min-width:0"><strong>${escapeHtml(player.name)}${player.id === socket?.id ? ' (tú)' : ''}</strong><small>${detail}</small></div><i class="player-dot"></i></div>`;
    }).join('');
  }

  function createDie(value, index, game) {
    const remaining = game.remainingDice.includes(index);
    const hasMove = (game.legalMoves || []).some(move => move.dieIndex === index);
    const canUse = remaining && hasMove && game.players[game.turnIndex]?.id === socket?.id;
    const selected = selectedDieIndex === index && canUse;
    const pips = {
      1: [4], 2: [0, 8], 3: [0, 4, 8],
      4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8], 6: [0, 2, 3, 5, 6, 8]
    }[value] || [];
    return `<button class="die ${remaining ? '' : 'used'} ${remaining && !hasMove ? 'unusable' : ''} ${selected ? 'selected' : ''}" data-die-index="${index}" ${canUse ? '' : 'disabled'} aria-label="Dado ${index + 1}: ${value}">${Array.from({ length: 9 }, (_, i) => pips.includes(i) ? `<i class="pip" style="grid-row:${Math.floor(i / 3) + 1};grid-column:${(i % 3) + 1}"></i>` : '<span></span>').join('')}</button>`;
  }

  function renderMoves(game) {
    const legal = game.legalMoves || [];
    const activePlayer = game.players[game.turnIndex];
    const isMyTurn = activePlayer?.id === socket?.id;
    const choices = legal.filter(move => selectedDieIndex === null || move.dieIndex === selectedDieIndex);
    $('movesCount').textContent = isMyTurn ? `${choices.length} opción(es)` : 'Espera';
    if (!isMyTurn) {
      $('movesHelp').textContent = `${activePlayer?.name || 'Otro jugador'} está realizando su turno.`;
      $('movesList').innerHTML = '';
      return;
    }
    if (game.phase === 'roll') {
      $('movesHelp').textContent = 'Lanza los dos dados. Un 5 permite sacar una ficha de casa.';
      $('movesList').innerHTML = '';
      return;
    }
    if (!legal.length) {
      $('movesHelp').textContent = 'No tienes movimientos posibles. El turno pasará automáticamente.';
      $('movesList').innerHTML = '';
      return;
    }
    $('movesHelp').textContent = 'Elige un dado y después la ficha que quieres mover.';
    $('movesList').innerHTML = choices.map(move => {
      const tokenIndex = activePlayer.tokens.findIndex(token => token.id === move.tokenId);
      const label = move.launch ? 'Sacar ficha de casa' : move.finish ? 'Entrar a la meta' : `Mover ficha ${tokenIndex + 1}`;
      const detail = move.captureIds.length ? 'Captura una ficha rival' : `Avanza ${move.dieValue} casillas`;
      return `<button class="move-option" data-move-token="${escapeHtml(move.tokenId)}" data-move-die="${move.dieIndex}"><span class="move-die">${move.dieValue}</span><span><strong>${label}</strong><small>${detail}</small></span><span class="move-arrow">›</span></button>`;
    }).join('');
  }

  function renderGame() {
    if (!room?.game) return;
    const game = room.game;
    document.body.dataset.theme = room.theme || theme;
    const active = game.players[game.turnIndex];
    const myTurn = active?.id === socket?.id;
    const legalDice = new Set((game.legalMoves || []).map(move => move.dieIndex));
    if (selectedDieIndex !== null && (!game.remainingDice.includes(selectedDieIndex) || (legalDice.size && !legalDice.has(selectedDieIndex)))) selectedDieIndex = null;
    if (selectedDieIndex === null && game.remainingDice.length) selectedDieIndex = game.remainingDice.find(index => legalDice.has(index)) ?? game.remainingDice[0];
    $('gameRoomCode').textContent = room.mode === 'online' ? `SALA ${room.code}` : `${game.playerCount} PUESTOS · IA`;
    $('boardCaption').textContent = `${game.playerCount} PUESTOS · ${THEME_LABELS[room.theme] || 'Clásico'}`.toUpperCase();
    $('turnAvatar').src = active ? avatarUrl(active) : '/parques/assets/avatars/person8.webp';
    $('turnName').textContent = active?.name || 'Jugador';
    $('turnStatus').textContent = myTurn ? 'Es tu turno' : active?.isAI ? `${DIFFICULTY_LABELS[active.difficulty] || 'IA'} · pensando…` : 'Turno del rival';
    $('lastAction').textContent = game.lastAction || 'La partida está en curso.';
    $('boardSvg').innerHTML = boardSvg(game);
    renderPlayers(game);
    const signature = game.dice.join('-');
    if (signature && signature !== lastDiceSignature) {
      lastDiceSignature = signature;
      $('diceArea').classList.add('dice-updated');
    }
    $('diceArea').innerHTML = game.dice.length ? game.dice.map((value, index) => createDie(value, index, game)).join('') : '<div class="die die-empty">?</div><div class="die die-empty">?</div>';
    const canRoll = myTurn && game.phase === 'roll' && game.status === 'playing';
    $('rollButton').disabled = !canRoll;
    $('rollButton').textContent = canRoll ? '⚄ Lanzar dados' : myTurn ? 'Dados lanzados' : 'Esperando turno';
    $('diceHint').textContent = game.phase === 'roll' ? (myTurn ? 'Tu lanzamiento' : 'Turno del rival') : `${game.remainingDice.length} dado(s) pendiente(s)`;
    renderMoves(game);
    $('boardSvg').querySelectorAll('[data-token-id]').forEach(group => {
      group.addEventListener('click', () => {
        const tokenId = group.dataset.tokenId;
        const legal = (game.legalMoves || []).filter(move => move.tokenId === tokenId && (selectedDieIndex === null || move.dieIndex === selectedDieIndex));
        if (legal.length === 1) socket.emit('moveToken', { tokenId, dieIndex: legal[0].dieIndex });
        else if (legal.length > 1) notify('Elige primero qué dado quieres utilizar.');
        else if (myTurn && game.phase === 'move') notify('Esa ficha no puede moverse con el dado seleccionado.');
      });
      group.addEventListener('keydown', event => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); group.click(); }
      });
    });
    document.querySelectorAll('[data-die-index]').forEach(button => button.addEventListener('click', () => {
      selectedDieIndex = Number(button.dataset.dieIndex);
      renderGame();
    }));
    document.querySelectorAll('[data-move-token]').forEach(button => button.addEventListener('click', () => {
      socket.emit('moveToken', { tokenId: button.dataset.moveToken, dieIndex: Number(button.dataset.moveDie) });
    }));
    if (game.status === 'finished') {
      $('rollButton').disabled = true;
      $('rollButton').textContent = `${active?.name || 'Un jugador'} ganó`;
      $('movesHelp').textContent = 'La partida terminó. Puedes salir y crear otra mesa.';
    }
  }

  function handleRoomState(nextRoom) {
    room = nextRoom;
    selectedDieIndex = null;
    if (room.status === 'waiting') {
      showScreen('waiting');
      renderWaiting();
    } else {
      showScreen('game');
      renderGame();
    }
  }

  function resetToSetup() {
    if (room) socket.emit('leaveRoom');
    room = null;
    selectedDieIndex = null;
    lastDiceSignature = '';
    showScreen('setup');
  }

  document.querySelectorAll('.mode-button').forEach(button => button.addEventListener('click', () => selectMode(button.dataset.mode)));
  document.querySelectorAll('.seat-button').forEach(button => button.addEventListener('click', () => setSeats(button.dataset.seats)));
  document.querySelectorAll('.difficulty-button').forEach(button => button.addEventListener('click', () => setDifficulty(button.dataset.difficulty)));
  document.querySelectorAll('.theme-button').forEach(button => button.addEventListener('click', () => setTheme(button.dataset.themeChoice)));
  $('startAiButton').addEventListener('click', createAiGame);
  $('createRoomButton').addEventListener('click', createOnlineRoom);
  $('joinRoomButton').addEventListener('click', () => joinRoom());
  $('joinCode').addEventListener('input', event => { event.target.value = event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 5); });
  $('joinCode').addEventListener('keydown', event => { if (event.key === 'Enter') joinRoom(); });
  $('refreshRoomsButton').addEventListener('click', () => socket.emit('listOpenRooms'));
  $('startOnlineButton').addEventListener('click', () => socket.emit('startOnlineGame'));
  $('rollButton').addEventListener('click', () => socket.emit('rollDice'));
  $('leaveWaitingButton').addEventListener('click', resetToSetup);
  $('leaveGameButton').addEventListener('click', resetToSetup);
  $('roomCodeButton').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(room?.code || ''); notify('Código copiado. Envíalo a tus amigos.'); }
    catch { notify(`Código de sala: ${room?.code || ''}`); }
  });

  if (socket) {
    socket.on('connect', () => { $('openRooms').innerHTML = '<p class="muted">Conectado. Pulsa actualizar para buscar partidas.</p>'; });
    socket.on('connect_error', () => notify('No se pudo conectar al servidor de Parqués.'));
    socket.on('roomCreated', data => { $('joinCode').value = data.code; notify(`Sala ${data.code} creada. Comparte el código.`); });
    socket.on('roomState', handleRoomState);
    socket.on('actionError', data => notify(data?.message || 'No se pudo realizar esa acción.'));
    socket.on('openRooms', rooms => {
      $('openRooms').innerHTML = rooms.length ? rooms.map(item => `<div class="open-room-item"><div><strong>${escapeHtml(item.host)} · ${item.code}</strong><small>${item.count}/${item.capacity} jugadores · ${THEME_LABELS[item.theme] || 'Clásico'}</small></div><button type="button" data-join-room="${item.code}">Unirme</button></div>`).join('') : '<p class="muted">No hay salas esperando jugadores. Crea una y comparte tu código.</p>';
      $('openRooms').querySelectorAll('[data-join-room]').forEach(button => button.addEventListener('click', () => joinRoom(button.dataset.joinRoom)));
    });
  } else {
    notify('No se cargó el módulo multijugador. Revisa la conexión.');
  }

  selectMode('ai');
  setSeats(4);
  setDifficulty('normal');
  setTheme('classic');
})();
