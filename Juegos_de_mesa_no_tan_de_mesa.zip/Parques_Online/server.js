'use strict';

const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
const express = require('express');
const { Server } = require('socket.io');
const {
  createGame, currentPlayer, getLegalMoves, applyMove, roll,
  chooseAiMove, endIfNoMoves
} = require('./rules');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true },
  transports: ['websocket', 'polling'],
  pingInterval: 25000,
  pingTimeout: 60000,
  connectionStateRecovery: { maxDisconnectionDuration: 120000, skipMiddlewares: true }
});
const PORT = Number(process.env.PORT || 3103);
const HOST = process.env.HOST || '127.0.0.1';
const rooms = new Map();
const socketRooms = new Map();
const AI_NAMES = [
  { name: 'Sofía', avatar: 'person1.webp' },
  { name: 'Mateo', avatar: 'person2.webp' },
  { name: 'Valentina', avatar: 'person3.webp' },
  { name: 'Tomás', avatar: 'person4.webp' },
  { name: 'Camila', avatar: 'person5.webp' },
  { name: 'Samuel', avatar: 'person6.webp' },
  { name: 'Lucía', avatar: 'person7.webp' },
  { name: 'Nicolás', avatar: 'person8.webp' }
];

app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1d' }));
app.get('/api/ping', (_req, res) => res.json({ ok: true, app: 'Parqués', rooms: rooms.size }));

function makeCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do {
    code = Array.from({ length: 5 }, () => alphabet[crypto.randomInt(alphabet.length)]).join('');
  } while (rooms.has(code));
  return code;
}

function safeName(value, fallback) {
  const name = String(value || '').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 18);
  return name || fallback;
}

function roomPublic(room) {
  return {
    code: room.code,
    mode: room.mode,
    status: room.status,
    capacity: room.capacity,
    theme: room.theme,
    hostId: room.hostId,
    players: room.players.map(player => ({
      id: player.id,
      name: player.name,
      color: player.color,
      avatar: player.avatar,
      isAI: !!player.isAI,
      difficulty: player.difficulty || null,
      connected: player.connected !== false
    })),
    game: room.game ? {
      ...room.game,
      legalMoves: getLegalMoves(room.game, currentPlayer(room.game)?.id),
      players: room.game.players.map(player => ({
        id: player.id, name: player.name, color: player.color, avatar: player.avatar,
        isAI: player.isAI, difficulty: player.difficulty, connected: player.connected,
        startIndex: player.startIndex, tokens: player.tokens.map(token => ({ ...token }))
      }))
    } : null
  };
}

function emitRoom(room) {
  io.to(room.code).emit('roomState', roomPublic(room));
}

function attachSocket(room, socket) {
  socket.join(room.code);
  socketRooms.set(socket.id, room.code);
}

function error(socket, message) {
  socket.emit('actionError', { message });
}

function playerForSocket(room, socket) {
  return room.players.find(player => player.id === socket.id && !player.isAI);
}

function advanceDisconnectedTurn(room) {
  if (!room.game || room.game.status !== 'playing') return;
  let skipped = 0;
  while (skipped < room.game.players.length) {
    const player = currentPlayer(room.game);
    if (!player || player.connected !== false) break;
    room.game.turnIndex = (room.game.turnIndex + 1) % room.game.players.length;
    room.game.turnNumber += 1;
    room.game.phase = 'roll';
    room.game.dice = [];
    room.game.remainingDice = [];
    room.game.doubleChain = 0;
    room.game.lastAction = `${player.name} se desconectó. Se salta su turno.`;
    skipped += 1;
  }
}

function createStartedRoom(socket, payload) {
  const playerCount = Number(payload.playerCount) === 6 ? 6 : 4;
  const difficulty = ['easy', 'normal', 'hard'].includes(payload.difficulty) ? payload.difficulty : 'normal';
  const human = {
    id: socket.id,
    name: safeName(payload.playerName, 'Tú'),
    avatar: 'person8.webp',
    isAI: false,
    connected: true
  };
  const players = [human];
  let aiIndex = 0;
  while (players.length < playerCount) {
    const ai = AI_NAMES[aiIndex % AI_NAMES.length];
    players.push({
      id: `ai-${crypto.randomUUID()}`,
      name: ai.name,
      avatar: ai.avatar,
      isAI: true,
      difficulty,
      connected: true
    });
    aiIndex += 1;
  }
  const room = {
    code: makeCode(), mode: 'ai', status: 'playing', capacity: playerCount,
    theme: ['classic', 'jungle', 'caribbean', 'royal'].includes(payload.theme) ? payload.theme : 'classic',
    hostId: socket.id, players, game: createGame(players, playerCount, { tripleDoublePenalty: !!payload.tripleDoublePenalty }),
    aiTimer: null, createdAt: Date.now()
  };
  rooms.set(room.code, room);
  attachSocket(room, socket);
  emitRoom(room);
  scheduleAi(room);
}

function scheduleAi(room) {
  if (room.aiTimer) clearTimeout(room.aiTimer);
  if (!room.game || room.game.status !== 'playing') return;
  const player = currentPlayer(room.game);
  if (!player?.isAI) return;
  room.aiTimer = setTimeout(() => {
    room.aiTimer = null;
    if (!room.game || room.game.status !== 'playing') return;
    const active = currentPlayer(room.game);
    if (!active?.isAI) return;
    if (room.game.phase === 'roll') {
      const values = [crypto.randomInt(1, 7), crypto.randomInt(1, 7)];
      roll(room.game, active.id, values);
      advanceDisconnectedTurn(room);
      emitRoom(room);
      if (room.game.status === 'playing' && currentPlayer(room.game)?.id === active.id && room.game.phase === 'move') scheduleAi(room);
      else scheduleAi(room);
      return;
    }
    const legal = getLegalMoves(room.game, active.id);
    if (!legal.length) {
      endIfNoMoves(room.game);
      advanceDisconnectedTurn(room);
      emitRoom(room);
      scheduleAi(room);
      return;
    }
    const selected = chooseAiMove(room.game, legal, active.difficulty || 'normal');
    if (selected) {
      const result = applyMove(room.game, active.id, selected.tokenId, selected.dieIndex);
      if (result.gameOver) room.status = 'finished';
    }
    advanceDisconnectedTurn(room);
    emitRoom(room);
    scheduleAi(room);
  }, 850 + crypto.randomInt(0, 650));
  room.aiTimer.unref?.();
}

io.on('connection', socket => {
  socket.emit('connected', { ok: true });

  socket.on('createAiGame', payload => {
    if (socketRooms.has(socket.id)) return error(socket, 'Ya estás dentro de una sala. Sal de ella antes de crear otra.');
    try { createStartedRoom(socket, payload || {}); }
    catch (err) { error(socket, err.message || 'No se pudo crear la partida.'); }
  });

  socket.on('createOnlineRoom', payload => {
    if (socketRooms.has(socket.id)) return error(socket, 'Ya estás dentro de una sala.');
    const capacity = Number(payload?.playerCount) === 6 ? 6 : 4;
    const player = {
      id: socket.id,
      name: safeName(payload?.playerName, 'Anfitrión'),
      avatar: 'person8.webp', isAI: false, connected: true
    };
    const room = {
      code: makeCode(), mode: 'online', status: 'waiting', capacity,
      theme: ['classic', 'jungle', 'caribbean', 'royal'].includes(payload?.theme) ? payload.theme : 'classic',
      hostId: socket.id, players: [player], game: null, aiTimer: null, createdAt: Date.now()
    };
    rooms.set(room.code, room);
    attachSocket(room, socket);
    socket.emit('roomCreated', { code: room.code });
    emitRoom(room);
    emitOpenRooms();
  });

  socket.on('listOpenRooms', () => emitOpenRooms(socket));

  socket.on('joinRoom', payload => {
    if (socketRooms.has(socket.id)) return error(socket, 'Ya estás dentro de una sala.');
    const code = String(payload?.code || '').trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return error(socket, 'No encontramos esa sala. Revisa el código.');
    if (room.mode !== 'online' || room.status !== 'waiting') return error(socket, 'Esa sala ya comenzó o no admite más jugadores.');
    if (room.players.length >= room.capacity) return error(socket, 'La sala está completa.');
    room.players.push({
      id: socket.id,
      name: safeName(payload?.playerName, `Jugador ${room.players.length + 1}`),
      avatar: `person${((room.players.length + 1) % 8) + 1}.webp`,
      isAI: false, connected: true
    });
    attachSocket(room, socket);
    emitRoom(room);
    emitOpenRooms();
  });

  socket.on('startOnlineGame', () => {
    const room = rooms.get(socketRooms.get(socket.id));
    if (!room || room.mode !== 'online') return error(socket, 'No estás en una sala online.');
    if (room.hostId !== socket.id) return error(socket, 'Solo el anfitrión puede iniciar la partida.');
    if (room.status !== 'waiting') return error(socket, 'La partida ya comenzó.');
    if (room.players.length !== room.capacity) return error(socket, `Faltan ${room.capacity - room.players.length} jugadores para completar el tablero.`);
    room.game = createGame(room.players, room.capacity);
    room.status = 'playing';
    emitRoom(room);
    emitOpenRooms();
  });

  socket.on('rollDice', () => {
    const room = rooms.get(socketRooms.get(socket.id));
    if (!room?.game) return error(socket, 'Primero crea o únete a una partida.');
    const player = playerForSocket(room, socket);
    if (!player) return error(socket, 'No encontramos tu puesto en esta sala.');
    const result = roll(room.game, player.id, [crypto.randomInt(1, 7), crypto.randomInt(1, 7)]);
    if (!result.ok) return error(socket, result.error);
    advanceDisconnectedTurn(room);
    emitRoom(room);
    scheduleAi(room);
  });

  socket.on('moveToken', payload => {
    const room = rooms.get(socketRooms.get(socket.id));
    if (!room?.game) return error(socket, 'No hay una partida en curso.');
    const player = playerForSocket(room, socket);
    if (!player) return error(socket, 'No encontramos tu puesto en esta sala.');
    const result = applyMove(room.game, player.id, String(payload?.tokenId || ''), Number(payload?.dieIndex));
    if (!result.ok) return error(socket, result.error);
    if (result.gameOver) room.status = 'finished';
    advanceDisconnectedTurn(room);
    emitRoom(room);
    scheduleAi(room);
  });

  socket.on('finishTurn', () => {
    const room = rooms.get(socketRooms.get(socket.id));
    if (!room?.game) return error(socket, 'No hay una partida en curso.');
    const player = playerForSocket(room, socket);
    if (!player || currentPlayer(room.game)?.id !== player.id) return error(socket, 'No es tu turno.');
    if (room.game.phase === 'move' && getLegalMoves(room.game, player.id).length) return error(socket, 'Todavía tienes movimientos posibles. Debes utilizar los dados.');
    endIfNoMoves(room.game);
    advanceDisconnectedTurn(room);
    emitRoom(room);
    scheduleAi(room);
  });

  socket.on('leaveRoom', () => leaveSocketRoom(socket, true));

  socket.on('disconnect', () => leaveSocketRoom(socket, false));
});

function emitOpenRooms(target = null) {
  const list = [...rooms.values()]
    .filter(room => room.mode === 'online' && room.status === 'waiting' && room.players.length < room.capacity)
    .sort((a, b) => a.createdAt - b.createdAt)
    .slice(0, 20)
    .map(room => ({ code: room.code, capacity: room.capacity, count: room.players.length, theme: room.theme, host: room.players[0]?.name || 'Anfitrión' }));
  if (target) target.emit('openRooms', list);
  else io.emit('openRooms', list);
}

function leaveSocketRoom(socket, explicit) {
  const code = socketRooms.get(socket.id);
  if (!code) return;
  socketRooms.delete(socket.id);
  const room = rooms.get(code);
  if (!room) return;
  socket.leave(code);
  const player = room.players.find(item => item.id === socket.id);
  if (!player) return;
  if (room.status === 'waiting') {
    room.players = room.players.filter(item => item.id !== socket.id);
    if (!room.players.length) rooms.delete(code);
    else {
      if (room.hostId === socket.id) room.hostId = room.players[0].id;
      emitRoom(room);
    }
  } else if (room.game) {
    player.connected = false;
    const gamePlayer = room.game.players.find(item => item.id === socket.id);
    if (gamePlayer) gamePlayer.connected = false;
    advanceDisconnectedTurn(room);
    if (explicit) room.game.lastAction = `${player.name} salió de la sala.`;
    const connectedHumans = room.players.some(item => !item.isAI && item.connected !== false);
    if (!connectedHumans) {
      if (room.aiTimer) clearTimeout(room.aiTimer);
      rooms.delete(code);
    } else {
      emitRoom(room);
      scheduleAi(room);
    }
  }
  emitOpenRooms();
}

server.listen(PORT, HOST, () => console.log(`Parqués listo en http://${HOST}:${PORT}`));

function shutdown() {
  for (const room of rooms.values()) if (room.aiTimer) clearTimeout(room.aiTimer);
  server.close();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
