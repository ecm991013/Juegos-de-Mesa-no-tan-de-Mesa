'use strict';

const COLORS_4 = ['coral', 'ocean', 'sun', 'jade'];
const COLORS_6 = ['coral', 'ocean', 'sun', 'jade', 'violet', 'tangerine'];
const TRACK_LENGTHS = { 4: 64, 6: 72 };
const HOME_LENGTH = 5;
const ENTRY_VALUE = 5;

function startIndexFor(playerIndex, playerCount, trackLength) {
  return Math.round(playerIndex * trackLength / playerCount) % trackLength;
}

function safeSquares(playerCount, trackLength) {
  const interval = trackLength / 8;
  const cells = new Set(Array.from({ length: 8 }, (_, i) => Math.round(i * interval) % trackLength));
  for (let i = 0; i < playerCount; i++) cells.add(startIndexFor(i, playerCount, trackLength));
  return [...cells];
}

function createGame(players, playerCount, settings = {}) {
  if (![4, 6].includes(playerCount)) throw new Error('El tablero debe tener 4 o 6 puestos.');
  if (!Array.isArray(players) || players.length !== playerCount) throw new Error('La partida debe tener todos sus puestos ocupados.');
  const trackLength = TRACK_LENGTHS[playerCount];
  const colors = playerCount === 4 ? COLORS_4 : COLORS_6;
  const normalizedPlayers = players.map((player, index) => ({
    id: String(player.id),
    name: String(player.name || `Jugador ${index + 1}`).slice(0, 20),
    color: colors[index],
    avatar: player.avatar || `person${(index % 8) + 1}.webp`,
    isAI: !!player.isAI,
    difficulty: player.difficulty || 'normal',
    connected: player.connected !== false,
    startIndex: startIndexFor(index, playerCount, trackLength),
    tokens: Array.from({ length: 4 }, (_, tokenIndex) => ({
      id: `${player.id}-f${tokenIndex + 1}`,
      progress: -1,
      finished: false
    }))
  }));
  return {
    playerCount,
    trackLength,
    homeLength: HOME_LENGTH,
    safeSquares: safeSquares(playerCount, trackLength),
    players: normalizedPlayers,
    turnIndex: 0,
    turnNumber: 1,
    phase: 'roll',
    dice: [],
    remainingDice: [],
    doubleChain: 0,
    tripleDoublePenalty: !!settings.tripleDoublePenalty,
    entryValue: ENTRY_VALUE,
    status: 'playing',
    winnerId: null,
    lastAction: 'La partida está lista. Lanza los dados.',
    lastRoller: null
  };
}

function currentPlayer(game) {
  return game.players[game.turnIndex] || null;
}

function trackIndexForProgress(player, progress, trackLength) {
  if (progress < 0 || progress >= trackLength) return null;
  return (player.startIndex + progress) % trackLength;
}

function tokenAtTrackIndex(game, index, excludeTokenId = null) {
  const found = [];
  for (const player of game.players) {
    for (const token of player.tokens) {
      if (token.id === excludeTokenId || token.finished) continue;
      const tokenIndex = trackIndexForProgress(player, token.progress, game.trackLength);
      if (tokenIndex === index) found.push({ player, token });
    }
  }
  return found;
}

function isSafe(game, index) {
  return game.safeSquares.includes(index);
}

function pathIsBlocked(game, player, token, targetProgress) {
  const first = Math.max(0, token.progress + 1);
  const last = Math.min(targetProgress, game.trackLength - 1);
  for (let progress = first; progress <= last; progress++) {
    const index = trackIndexForProgress(player, progress, game.trackLength);
    const occupants = tokenAtTrackIndex(game, index, token.id);
    const opponents = occupants.filter(item => item.player.id !== player.id);
    const allies = occupants.filter(item => item.player.id === player.id);
    if (opponents.length >= 2 || allies.length >= 2) return true;
  }
  return false;
}

function getLegalMoves(game, playerId = currentPlayer(game)?.id) {
  if (game.status !== 'playing' || game.phase !== 'move') return [];
  const player = game.players.find(item => item.id === playerId);
  if (!player || currentPlayer(game)?.id !== playerId) return [];
  const moves = [];
  for (const dieIndex of game.remainingDice) {
    const dieValue = game.dice[dieIndex];
    if (!Number.isInteger(dieValue)) continue;
    for (const token of player.tokens) {
      if (token.finished) continue;
      if (token.progress < 0) {
        if (dieValue === game.entryValue) {
          moves.push({ tokenId: token.id, dieIndex, dieValue, fromProgress: -1, toProgress: 0, launch: true, finish: false, captureIds: [] });
        }
        continue;
      }
      const toProgress = token.progress + dieValue;
      const finishAt = game.trackLength + game.homeLength;
      if (toProgress > finishAt) continue;
      if (pathIsBlocked(game, player, token, toProgress)) continue;
      const targetIndex = trackIndexForProgress(player, toProgress, game.trackLength);
      let captureIds = [];
      if (targetIndex !== null && !isSafe(game, targetIndex)) {
        const occupants = tokenAtTrackIndex(game, targetIndex, token.id);
        const opponents = occupants.filter(item => item.player.id !== player.id);
        if (opponents.length === 1) captureIds = [opponents[0].token.id];
        if (opponents.length >= 2) continue;
      }
      moves.push({
        tokenId: token.id, dieIndex, dieValue,
        fromProgress: token.progress, toProgress,
        launch: false, finish: toProgress === finishAt,
        captureIds
      });
    }
  }
  return moves;
}

function finishTurn(game) {
  const player = currentPlayer(game);
  if (!player || game.status !== 'playing') return;
  const wasDouble = game.dice.length === 2 && game.dice[0] === game.dice[1];
  if (wasDouble) {
    game.doubleChain += 1;
    if (game.tripleDoublePenalty && game.doubleChain >= 3) {
      const candidate = [...player.tokens]
        .filter(token => token.progress >= 0 && !token.finished)
        .sort((a, b) => b.progress - a.progress)[0];
      if (candidate) candidate.progress = -1;
      game.lastAction = candidate
        ? `${player.name} obtuvo tres pares seguidos y una ficha volvió a casa.`
        : `${player.name} obtuvo tres pares seguidos y perdió el turno.`;
      game.doubleChain = 0;
      game.turnIndex = (game.turnIndex + 1) % game.players.length;
      game.turnNumber += 1;
    } else {
      game.lastAction = `${player.name} sacó pares y conserva el turno.`;
    }
  } else {
    game.doubleChain = 0;
    game.turnIndex = (game.turnIndex + 1) % game.players.length;
    game.turnNumber += 1;
    game.lastAction = `Turno de ${currentPlayer(game).name}.`;
  }
  game.dice = [];
  game.remainingDice = [];
  game.phase = 'roll';
}

function applyMove(game, playerId, tokenId, dieIndex) {
  const legal = getLegalMoves(game, playerId);
  const move = legal.find(item => item.tokenId === tokenId && item.dieIndex === dieIndex);
  if (!move) return { ok: false, error: 'Ese movimiento no es válido con los dados disponibles.' };
  const player = game.players.find(item => item.id === playerId);
  const token = player.tokens.find(item => item.id === tokenId);
  token.progress = move.toProgress;
  for (const captureId of move.captureIds) {
    for (const opponent of game.players) {
      const captured = opponent.tokens.find(item => item.id === captureId);
      if (captured) captured.progress = -1;
    }
  }
  if (move.finish) token.finished = true;
  game.remainingDice = game.remainingDice.filter(index => index !== dieIndex);
  const captures = move.captureIds.length ? ` Capturaste ${move.captureIds.length} ficha(s).` : '';
  game.lastAction = move.launch
    ? `${player.name} sacó una ficha de casa.${captures}`
    : move.finish
      ? `${player.name} llegó a la meta con una ficha.${captures}`
      : `${player.name} movió una ficha ${move.dieValue} casillas.${captures}`;
  if (player.tokens.every(item => item.finished)) {
    game.status = 'finished';
    game.winnerId = player.id;
    game.phase = 'finished';
    game.lastAction = `${player.name} ganó la partida. ¡Felicitaciones!`;
    return { ok: true, move, gameOver: true };
  }
  if (game.remainingDice.length === 0 || getLegalMoves(game, playerId).length === 0) finishTurn(game);
  return { ok: true, move, gameOver: false };
}

function roll(game, playerId, values) {
  if (game.status !== 'playing') return { ok: false, error: 'La partida ya terminó.' };
  if (currentPlayer(game)?.id !== playerId) return { ok: false, error: 'No es tu turno.' };
  if (game.phase !== 'roll') return { ok: false, error: 'Primero utiliza los dados que ya lanzaste.' };
  if (!Array.isArray(values) || values.length !== 2 || values.some(value => !Number.isInteger(value) || value < 1 || value > 6)) {
    return { ok: false, error: 'Lanzamiento de dados inválido.' };
  }
  game.dice = [...values];
  game.remainingDice = [0, 1];
  game.phase = 'move';
  game.lastRoller = playerId;
  game.lastAction = `${currentPlayer(game).name} lanzó ${values[0]} y ${values[1]}.`;
  if (getLegalMoves(game, playerId).length === 0) finishTurn(game);
  return { ok: true };
}

function endIfNoMoves(game) {
  if (game.status !== 'playing' || game.phase !== 'move') return false;
  if (getLegalMoves(game, currentPlayer(game)?.id).length) return false;
  finishTurn(game);
  return true;
}

function chooseAiMove(game, moves, difficulty = 'normal', random = Math.random) {
  if (!moves.length) return null;
  if (difficulty === 'easy') return moves[Math.floor(random() * moves.length)];
  const player = currentPlayer(game);
  const scored = moves.map(move => {
    const token = player.tokens.find(item => item.id === move.tokenId);
    let score = 0;
    if (move.launch) score += difficulty === 'hard' ? 36 : 24;
    if (move.captureIds.length) score += difficulty === 'hard' ? 110 : 75;
    if (move.finish) score += 1000;
    if (!move.launch) score += (move.toProgress - move.fromProgress) * (difficulty === 'hard' ? 2.2 : 1.5);
    if (move.toProgress >= game.trackLength - 1) score += difficulty === 'hard' ? 28 : 12;
    if (token && token.progress >= 0 && isSafe(game, trackIndexForProgress(player, token.progress, game.trackLength))) score += 2;
    score += random() * (difficulty === 'hard' ? 2 : 12);
    return { move, score };
  }).sort((a, b) => b.score - a.score);
  return scored[0].move;
}

module.exports = {
  COLORS_4, COLORS_6, TRACK_LENGTHS, HOME_LENGTH, ENTRY_VALUE,
  startIndexFor, safeSquares, createGame, currentPlayer,
  trackIndexForProgress, isSafe, getLegalMoves, applyMove, roll,
  finishTurn, endIfNoMoves, chooseAiMove
};
