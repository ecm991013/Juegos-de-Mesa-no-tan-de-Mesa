'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {
  createGame, getLegalMoves, applyMove, roll, currentPlayer,
  trackIndexForProgress, safeSquares, chooseAiMove
} = require('../rules');

function players(count = 4) {
  return Array.from({ length: count }, (_, index) => ({ id: `p${index}`, name: `Jugador ${index + 1}` }));
}
function movingGame(values = [1, 2], count = 4) {
  const game = createGame(players(count), count);
  game.dice = [...values];
  game.remainingDice = values.map((_, index) => index);
  game.phase = 'move';
  return game;
}

test('crea tableros válidos de cuatro y seis puestos', () => {
  const four = createGame(players(4), 4);
  const six = createGame(players(6), 6);
  assert.equal(four.trackLength, 64);
  assert.equal(four.players.length, 4);
  assert.equal(six.trackLength, 72);
  assert.equal(six.players.length, 6);
  assert.equal(new Set(six.players.map(p => p.color)).size, 6);
});

test('cada tablero marca salidas y casillas seguras', () => {
  for (const count of [4, 6]) {
    const game = createGame(players(count), count);
    assert.equal(game.players.every(p => game.safeSquares.includes(p.startIndex)), true);
    assert.ok(safeSquares(count, game.trackLength).length >= count);
  }
});

test('solo un cinco permite sacar una ficha de casa', () => {
  const game = createGame(players(), 4);
  roll(game, 'p0', [4, 2]);
  assert.equal(getLegalMoves(game, 'p0').length, 0);
  const withFive = createGame(players(), 4);
  roll(withFive, 'p0', [5, 2]);
  const legal = getLegalMoves(withFive, 'p0');
  assert.equal(legal.length, 4);
  assert.ok(legal.every(move => move.launch && move.dieValue === 5));
});

test('si solo un dado tiene movimientos, conserva disponible ese dado', () => {
  const game = createGame(players(), 4);
  roll(game, 'p0', [2, 5]);
  const legal = getLegalMoves(game, 'p0');
  assert.ok(legal.length > 0);
  assert.ok(legal.every(move => move.dieIndex === 1));
  assert.deepEqual(game.remainingDice, [0, 1]);
});

test('sacar una ficha con cinco consume el dado correspondiente', () => {
  const game = createGame(players(), 4);
  roll(game, 'p0', [5, 2]);
  const move = getLegalMoves(game, 'p0')[0];
  const result = applyMove(game, 'p0', move.tokenId, move.dieIndex);
  assert.equal(result.ok, true);
  assert.equal(game.players[0].tokens[0].progress, 0);
  assert.deepEqual(game.remainingDice, [1]);
  const followUp = getLegalMoves(game, 'p0').find(item => item.tokenId === 'p0-f1' && item.dieIndex === 1);
  assert.ok(followUp, 'el otro dado puede avanzar la ficha recién salida');
  applyMove(game, 'p0', followUp.tokenId, followUp.dieIndex);
  assert.equal(game.players[0].tokens[0].progress, 2);
  assert.equal(currentPlayer(game).id, 'p1');
});

test('permite mover una ficha por separado con ambos dados', () => {
  const game = movingGame([1, 2]);
  game.players[0].tokens[0].progress = 0;
  const first = getLegalMoves(game, 'p0').find(move => move.tokenId === 'p0-f1' && move.dieIndex === 0);
  assert.ok(first);
  assert.equal(applyMove(game, 'p0', first.tokenId, first.dieIndex).ok, true);
  const second = getLegalMoves(game, 'p0').find(move => move.tokenId === 'p0-f1' && move.dieIndex === 1);
  assert.ok(second);
  assert.equal(applyMove(game, 'p0', second.tokenId, second.dieIndex).ok, true);
  assert.equal(game.players[0].tokens[0].progress, 3);
  assert.equal(currentPlayer(game).id, 'p1');
});

test('captura una ficha rival al caer en casilla no segura', () => {
  const game = movingGame([2, 4]);
  game.players[0].tokens[0].progress = 8; // índice 8, destino índice 10
  game.players[1].tokens[0].progress = 58; // inicio 16 + 58 = 10
  const move = getLegalMoves(game, 'p0').find(item => item.tokenId === 'p0-f1' && item.dieIndex === 0);
  assert.ok(move);
  assert.deepEqual(move.captureIds, ['p1-f1']);
  applyMove(game, 'p0', 'p0-f1', 0);
  assert.equal(game.players[1].tokens[0].progress, -1);
});

test('no permite capturar ni ocupar una casilla segura con captura', () => {
  const game = movingGame([1, 4]);
  game.players[0].tokens[0].progress = 7; // llega al 8, seguro
  game.players[1].tokens[0].progress = 56; // jugador 1 cae también en índice 8
  const move = getLegalMoves(game, 'p0').find(item => item.tokenId === 'p0-f1' && item.dieIndex === 0);
  assert.ok(move);
  assert.deepEqual(move.captureIds, []);
});

test('permite pasar por varias fichas rivales sin crear una barrera', () => {
  const game = movingGame([4, 2]);
  game.players[0].tokens[0].progress = 8;
  // Dos fichas rivales ocupan la casilla 10; el jugador termina en la 12.
  for (const token of game.players[1].tokens) token.progress = 58;
  const move = getLegalMoves(game, 'p0').find(item => item.tokenId === 'p0-f1' && item.dieIndex === 0);
  assert.ok(move, 'la acumulación rival no bloquea el recorrido');
  assert.deepEqual(move.captureIds, []);
});

test('captura todas las fichas rivales acumuladas al caer en una casilla insegura', () => {
  const game = movingGame([3, 4]);
  game.players[0].tokens[0].progress = 8;
  for (const token of game.players[1].tokens) token.progress = 59;
  const move = getLegalMoves(game, 'p0').find(item => item.tokenId === 'p0-f1' && item.dieIndex === 0);
  assert.ok(move);
  assert.deepEqual(move.captureIds.sort(), ['p1-f1', 'p1-f2', 'p1-f3', 'p1-f4']);
  applyMove(game, 'p0', move.tokenId, move.dieIndex);
  assert.ok(game.players[1].tokens.every(token => token.progress === -1));
});

test('permite que más de dos fichas propias compartan una casilla', () => {
  const game = movingGame([3, 4]);
  game.players[0].tokens[0].progress = 10;
  game.players[0].tokens[1].progress = 10;
  game.players[0].tokens[2].progress = 10;
  game.players[0].tokens[3].progress = 7;
  const move = getLegalMoves(game, 'p0').find(item => item.tokenId === 'p0-f4' && item.dieIndex === 0);
  assert.ok(move, 'la casilla admite acumulaciones de más de dos fichas');
  assert.deepEqual(move.captureIds, []);
  applyMove(game, 'p0', move.tokenId, move.dieIndex);
  assert.equal(game.players[0].tokens.filter(token => token.progress === 10).length, 4);
});

test('conserva el último resultado de dados aunque el turno pase sin movimientos', () => {
  const game = createGame(players(), 4);
  // Bloquea la salida: ambos dados son 1 y no permiten sacar fichas de casa.
  roll(game, 'p0', [1, 1]);
  assert.deepEqual(game.lastDice, [1, 1]);
  assert.equal(game.dice.length, 0);
  assert.equal(game.turnIndex, 0, 'el doble conserva el turno aunque no haya salida');
});

test('respeta el avatar y color elegidos cuando se crea el tablero', () => {
  const custom = players().map((player, index) => ({ ...player, color: ['jade', 'coral', 'sun', 'ocean'][index], avatar: 'person2.webp' }));
  const game = createGame(custom, 4);
  assert.deepEqual(game.players.map(player => player.color), ['jade', 'coral', 'sun', 'ocean']);
  assert.ok(game.players.every(player => player.avatar === 'person2.webp'));
});

test('exige número exacto para llegar a la meta', () => {
  const game = movingGame([4, 3]);
  game.players[0].tokens[0].progress = 65;
  const legal = getLegalMoves(game, 'p0');
  assert.ok(legal.some(move => move.tokenId === 'p0-f1' && move.dieValue === 4 && move.finish));
  assert.ok(!legal.some(move => move.tokenId === 'p0-f1' && move.dieValue === 5));
});

test('un doble concede otro lanzamiento al mismo jugador', () => {
  const game = movingGame([1, 1]);
  game.players[0].tokens[0].progress = 0;
  applyMove(game, 'p0', 'p0-f1', 0);
  applyMove(game, 'p0', 'p0-f1', 1);
  assert.equal(game.phase, 'roll');
  assert.equal(currentPlayer(game).id, 'p0');
  assert.equal(game.doubleChain, 1);
});

test('la regla opcional de tres dobles devuelve una ficha a casa', () => {
  const game = createGame(players(), 4, { tripleDoublePenalty: true });
  game.players[0].tokens[0].progress = 20;
  game.doubleChain = 2;
  game.dice = [2, 2];
  game.remainingDice = [0, 1];
  game.phase = 'move';
  // El paso de cierre sucede cuando se consumen todos los dados.
  const move = getLegalMoves(game, 'p0').find(item => item.tokenId === 'p0-f1' && item.dieIndex === 0);
  assert.ok(move);
  applyMove(game, 'p0', move.tokenId, 0);
  const next = getLegalMoves(game, 'p0').find(item => item.dieIndex === 1);
  if (next) applyMove(game, 'p0', next.tokenId, 1);
  assert.equal(game.doubleChain, 0);
  assert.equal(game.turnIndex, 1);
  assert.equal(game.players[0].tokens[0].progress, -1);
});

test('la IA difícil elige una captura si está disponible', () => {
  const game = movingGame([2, 3]);
  game.players[0].tokens[0].progress = 8;
  game.players[1].tokens[0].progress = 58;
  const legal = getLegalMoves(game, 'p0');
  const choice = chooseAiMove(game, legal, 'hard', () => 0.5);
  assert.equal(choice.captureIds.length, 1);
});
