'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../..');

test('el portal registra Parqués en el puerto interno reservado', () => {
  const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  assert.match(server, /'\/parques':\s*\{\s*port:\s*3103/);
  assert.match(server, /startChild\('Parqués',\s*SERVICES\['\/parques'\]\)/);
});

test('el proxy admite el WebSocket de Parqués bajo su prefijo público', () => {
  const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  assert.match(server, /\['\/rummikub',\s*'\/parques'\]/);
  assert.match(server, /route\.prefix\s*\+\s*'\/socket\.io'/);
});

test('el catálogo muestra Parqués y apunta al juego integrado', () => {
  const page = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');
  assert.match(page, /data-name="parques"/);
  assert.match(page, /href="\/parques\/"/);
});

test('los recursos de Parqués respetan el prefijo público del proxy', () => {
  const page = fs.readFileSync(path.join(__dirname, '../public/index.html'), 'utf8');
  assert.match(page, /href="\/parques\/styles\.css"/);
  assert.match(page, /src="\/parques\/client\.js"/);
  assert.match(page, /src="\/parques\/socket\.io\/socket\.io\.js"/);
  assert.match(page, /src="\/parques\/assets\/avatars\/person8\.webp"/);
});


test('la configuración permite elegir avatar y color de fichas propios', () => {
  const page = fs.readFileSync(path.join(__dirname, '../public/index.html'), 'utf8');
  const client = fs.readFileSync(path.join(__dirname, '../public/client.js'), 'utf8');
  const server = fs.readFileSync(path.join(__dirname, '../server.js'), 'utf8');
  assert.match(page, /id="avatarChoices"/);
  assert.match(page, /id="pieceColorChoices"/);
  assert.match(client, /playerAvatar: selectedAvatar/);
  assert.match(client, /playerColor: selectedColor/);
  assert.match(server, /avatar: safeAvatar\(payload\.playerAvatar\)/);
  assert.match(server, /color: humanColor/);
});

test('la interfaz conserva y muestra el último resultado de dados', () => {
  const rules = fs.readFileSync(path.join(__dirname, '../rules.js'), 'utf8');
  const client = fs.readFileSync(path.join(__dirname, '../public/client.js'), 'utf8');
  const page = fs.readFileSync(path.join(__dirname, '../public/index.html'), 'utf8');
  assert.match(rules, /lastDice: \[\]/);
  assert.match(rules, /game\.lastDice = \[\.\.\.values\]/);
  assert.match(client, /game\.lastDice \|\| \[\]/);
  assert.match(page, /id="diceSummary"/);
});


test('las salas online asignan un color libre cuando el elegido ya está ocupado', () => {
  const server = fs.readFileSync(path.join(__dirname, '../server.js'), 'utf8');
  const client = fs.readFileSync(path.join(__dirname, '../public/client.js'), 'utf8');
  assert.match(server, /availableColor\(room\.capacity, room\.players, payload\?\.playerColor\)/);
  assert.match(server, /socket\.emit\('colorAssigned', \{ color: assignedColor \}\)/);
  assert.match(client, /socket\.on\('colorAssigned'/);
});
