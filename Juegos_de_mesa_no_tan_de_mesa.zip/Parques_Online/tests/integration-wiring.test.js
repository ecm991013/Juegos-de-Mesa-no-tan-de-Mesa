'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../..');

test('el portal registra Parqués en el puerto interno reservado', () => {
  const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  assert.match(server, /'\/parques':\s*\{\s*port:\s*3103/);
  assert.match(server, /startChild\('Parqués',\s*SERVICES\['\/parques'\]\)/);
});

test('el proxy admite el WebSocket de Parqués bajo su prefijo público', () => {
  const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  assert.match(server, /\['\/rummikub',\s*'\/parques'\]/);
  assert.match(server, /route\.prefix\s*\+\s*'\/socket\.io'/);
});

test('el catálogo muestra Parqués y apunta al juego integrado', () => {
  const page = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');
  assert.match(page, /data-name="parques"/);
  assert.match(page, /href="\/parques\/"/);
});

test('los recursos de Parqués respetan el prefijo público del proxy', () => {
  const page = fs.readFileSync(path.join(__dirname, '../public/index.html'), 'utf8');
  assert.match(page, /href="\/parques\/styles\.css"/);
  assert.match(page, /src="\/parques\/client\.js"/);
  assert.match(page, /src="\/parques\/socket\.io\/socket\.io\.js"/);
  assert.match(page, /src="\/parques\/assets\/avatars\/person8\.webp"/);
});
