(() => {
  const cards = [...document.querySelectorAll('.game-card')];
  const filters = [...document.querySelectorAll('[data-filter]')];
  const search = document.getElementById('gameSearch');
  const empty = document.getElementById('emptySearch');
  let activeFilter = 'all';
  const countLabel = String(cards.length).padStart(2, '0');
  document.getElementById('availableCount').textContent = countLabel;
  document.getElementById('allCount').textContent = countLabel;

  function applyFilters() {
    const query = (search?.value || '').trim().toLocaleLowerCase('es');
    let visible = 0;
    for (const card of cards) {
      const nameMatch = (card.dataset.name || '').toLocaleLowerCase('es').includes(query);
      const categoryMatch = activeFilter === 'all' || (card.dataset.categories || '').split(/\s+/).includes(activeFilter);
      const show = nameMatch && categoryMatch;
      card.hidden = !show;
      if (show) visible++;
    }
    empty.hidden = visible !== 0;
  }

  filters.forEach(button => button.addEventListener('click', () => {
    activeFilter = button.dataset.filter || 'all';
    filters.forEach(item => {
      const selected = item === button;
      item.classList.toggle('active', selected);
      item.setAttribute('aria-pressed', String(selected));
    });
    applyFilters();
  }));
  search?.addEventListener('input', applyFilters);
})();
