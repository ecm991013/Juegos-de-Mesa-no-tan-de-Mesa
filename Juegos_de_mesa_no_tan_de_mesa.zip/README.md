# Juegos de mesa no tan de mesa

Portal web que reúne juegos HTML independientes en una sola plataforma.

## Juegos incluidos

- **BioDefensa 0.15.4** — cartas, estrategia, multijugador y rivales de IA.
- **Rummikub Online Club 1.4.1** — fichas, combinaciones, multijugador y rivales de IA.

Cada juego conserva su servidor, recursos y reglas. El proceso principal sirve el catálogo y enruta HTTP y WebSocket hacia los juegos.

## Estructura

```text
.
├── server.js
├── package.json
├── public/
├── virus_multijugador/
└── Rummikub_Online/
```

## GitHub y Render con el ZIP

Sube a la raíz del repositorio el archivo `Juegos_de_mesa_no_tan_de_mesa.zip` y el archivo `render.yaml`. Render ejecuta el `buildCommand` del Blueprint, extrae el ZIP e instala las dependencias declaradas en el `package.json` raíz. No descomprimas el ZIP antes de subirlo.

En Render crea el servicio usando **New → Blueprint** y selecciona el repositorio. Mantén `Root Directory` vacío. El servicio inicia los dos juegos secundarios desde el servidor principal.

## Despliegue manual alternativo

Si utilizas Web Service en lugar de Blueprint:

| Campo | Valor |
|---|---|
| Runtime | Node |
| Build Command | `unzip -o Juegos_de_mesa_no_tan_de_mesa.zip -d . && npm install --omit=dev --no-audit --no-fund` |
| Start Command | `npm start` |
| Health Check Path | `/health` |

## Ejecutar localmente

Requisitos: Node.js 20 o superior y conexión para instalar las dependencias la primera vez.

```bash
npm install --omit=dev
npm start
```

Rutas: `http://localhost:3000/`, `/biodefensa/`, `/rummikub/` y `/health`.

Comprobaciones: `npm run check` y `npm test`.

## Añadir futuros juegos

Cada juego nuevo se incorpora como carpeta independiente y se añade a `SERVICES` del servidor principal. Si utiliza Socket.IO, también se habilita su ruta WebSocket en el proxy. Después se agrega su tarjeta al catálogo y se incluyen las dependencias necesarias en el `package.json` raíz.
