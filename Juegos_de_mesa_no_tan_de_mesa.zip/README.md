# Juegos de mesa no tan de mesa

Portal web que reúne juegos HTML independientes en una sola plataforma.

## Juegos incluidos

- **BioDefensa 0.15.4** — juego de cartas, estrategia, multijugador y rivales de IA.
- **Rummikub Online Club 1.3.1** — juego de fichas, combinaciones, multijugador y rivales de IA.

Cada juego conserva su propio servidor y sus reglas. El servidor raíz sirve el catálogo y enruta las conexiones hacia cada juego.

## Estructura del repositorio

```text
.
├── server.js
├── package.json
├── render.yaml
├── public/                 # Portal principal
├── virus_multijugador/     # BioDefensa
└── Rummikub_Online/        # Rummikub
```

## Publicar en GitHub

1. Descarga y descomprime este ZIP en tu computador.
2. Entra a [GitHub](https://github.com/) e inicia sesión.
3. Pulsa **New repository** y crea uno llamado `juegos-de-mesa-no-tan-de-mesa`.
4. Recomendado: instala **GitHub Desktop** y elige **Add an Existing Repository** apuntando a la carpeta descomprimida. Si GitHub Desktop indica que no es un repositorio, selecciona **Create a Repository** en esa carpeta.
5. Confirma que la carpeta raíz que vas a publicar contiene directamente `server.js`, `package.json`, `render.yaml`, `public`, `virus_multijugador` y `Rummikub_Online`.
6. En GitHub Desktop escribe un resumen como `Primera versión del portal` y pulsa **Commit to main**.
7. Pulsa **Publish repository** y publícalo en GitHub. Si quieres que el repositorio sea público, desmarca la opción de repositorio privado; no es obligatorio para Render.

No subas carpetas `node_modules`, archivos `.env` ni credenciales. El archivo `.gitignore` ya excluye estos elementos y los datos locales de BioDefensa.

## Desplegar en Render mediante Blueprint (recomendado)

1. Abre [Render](https://render.com/) e inicia sesión.
2. Pulsa **New +** → **Blueprint**.
3. Conecta tu cuenta de GitHub si todavía no está conectada.
4. Selecciona el repositorio `juegos-de-mesa-no-tan-de-mesa`.
5. Render detectará `render.yaml`. Revisa el servicio y pulsa **Apply**.
6. Espera a que termine el despliegue. Render instalará las dependencias de Rummikub y ejecutará el servidor principal.
7. Abre la URL `.onrender.com` que Render asigne.

El Blueprint ya contiene estos valores:

- Runtime: Node.
- Build Command: `npm install --prefix Rummikub_Online --omit=dev --no-audit --no-fund`
- Start Command: `npm start`
- Health Check Path: `/health`

No crees dos servicios separados para los juegos: el portal inicia ambos servidores internos y los publica bajo sus rutas.

## Despliegue manual (alternativa)

Si prefieres crear un **Web Service** en Render en vez de usar Blueprint, selecciona el mismo repositorio y configura:

| Campo | Valor |
|---|---|
| Runtime | Node |
| Build Command | `npm install --prefix Rummikub_Online --omit=dev --no-audit --no-fund` |
| Start Command | `npm start` |
| Health Check Path | `/health` |

No configures un puerto fijo para el servicio público: Render proporciona `PORT` automáticamente. Los puertos internos 3101 y 3102 son utilizados únicamente entre procesos dentro del mismo servicio.

## Ejecutar localmente

Requisitos: Node.js 20 o superior.

Desde la carpeta raíz del proyecto:

```bash
npm install --prefix Rummikub_Online --omit=dev
npm start
```

Abre `http://localhost:3000`.

- Portal: `http://localhost:3000/`
- BioDefensa: `http://localhost:3000/biodefensa/`
- Rummikub: `http://localhost:3000/rummikub/`
- Estado: `http://localhost:3000/health`

## Comprobaciones

```bash
npm run check
npm test
```

No abras directamente los HTML de los juegos: ambos necesitan sus servidores para las partidas y la sincronización.

## Añadir futuros juegos

Cada juego nuevo se incorpora como una carpeta independiente con su propio servidor y recursos. Después se añade su ruta al objeto `SERVICES` de `server.js`, se configura el proxy HTTP/WebSocket que necesite, se agrega su tarjeta al catálogo y se actualiza `render.yaml` o el comando de instalación si requiere dependencias. Así se conservan separadas las reglas y el código de cada juego.

## Importante sobre almacenamiento y disponibilidad

El plan gratuito de Render puede suspender servicios inactivos y el sistema de archivos local no debe considerarse almacenamiento permanente. Las salas y partidas en memoria pueden perderse al reiniciar o suspender el servicio. Para conservar datos de forma fiable entre reinicios habrá que configurar una base de datos o almacenamiento persistente compatible.


## Actualización Rummikub
Se integró el ZIP más reciente proporcionado por el usuario. Ambos juegos incluyen un acceso visible «← Juegos» para volver al catálogo. Las rutas de recursos y Socket.IO de Rummikub están adaptadas al prefijo `/rummikub` del portal.


## Actualización de noviembre de 2026
- Se reemplazó Rummikub por el ZIP más reciente entregado por el usuario.
- Se añadió un botón «← Juegos» visible en la cabecera de BioDefensa y Rummikub.
- Se adaptaron las rutas de CSS, JavaScript, imágenes y Socket.IO de Rummikub al prefijo `/rummikub` del portal.
- El `render.yaml` extrae el ZIP completo antes de instalar las dependencias del portal.


## Actualización 1.0.1 – corrección de apertura de Rummikub
Se corrigió el cálculo de puntos de la primera apertura, especialmente cuando se utiliza un comodín. La compilación y las 27 pruebas automatizadas pasan con `npm run check` y `npm test`.


### Actualización 1.0.2
La versión incluye escaleras de 3 a 13 fichas, efectos sonoros configurables en Rummikub, cinco nuevos temas visuales y mejoras de legibilidad responsive. Los conjuntos del mismo número siguen limitados a 3 o 4 fichas de colores distintos, según las reglas estándar.
