# Juegos de mesa no tan de mesa

Plataforma con tres juegos web independientes: BioDefensa, Rummikub Online Club y Dominó Club.

## Despliegue
Sube el ZIP `Juegos_de_mesa_no_tan_de_mesa.zip` junto con `render.yaml` a GitHub. Render extrae el ZIP durante el build, instala las dependencias raíz e inicia el portal con `npm start`.

## Última actualización · 1.7.0
- La tarjeta de Dominó utiliza la portada `domino-cover-v3.png` (2400 × 1000).
- La imagen se escala con anchura completa y altura proporcional; el marco completo queda visible y no se recorta.
- El enlace de la imagen cambia de versión para que el navegador no reutilice el recurso anterior.
- HTML, CSS, JavaScript y SVG usan `Cache-Control: no-cache`; además, las hojas CSS y scripts utilizan URLs versionadas.
- BioDefensa y Rummikub conservan sus reglas y archivos.


## Dominó Club 1.6.0
- Previsualización en vivo del acabado de fichas y color del paño.
- Las fichas de la mano no se resaltan ni deshabilitan individualmente según su jugada; el jugador decide y el servidor valida.
- Recorrido serpenteante: las filas alternan derecha e izquierda y se conectan con curvas visuales.


### Dominó Club 1.7.0

La cadena se distribuye en varias filas conectadas, no en una sola línea horizontal. Cada fila alterna su sentido: avanza a la derecha, gira al siguiente tramo y vuelve a la izquierda. El número de fichas por fila se calcula según el ancho del tablero y se vuelve a calcular al cambiar el tamaño de pantalla. Al arrastrar una ficha, el extremo de destino se decide por proximidad al primer o último elemento visible de la cadena.
