# Juegos de mesa no tan de mesa

Portal que reúne juegos HTML independientes en una sola plataforma.

## Juegos incluidos

- **BioDefensa 0.15.4** — cartas, estrategia, multijugador y rivales de IA.
- **Rummikub Online Club 1.4.1** — fichas, combinaciones, multijugador y rivales de IA.
- **Dominó Club 1.0.0** — dominó doble-seis, IA, salas privadas online, modo local y fichas/mesas personalizables.

Cada juego conserva su servidor, recursos y reglas. El proceso principal sirve el catálogo y enruta HTTP y WebSocket hacia cada título.

## Estructura

```text
.
├── server.js
├── package.json
├── public/
├── virus_multijugador/
├── Rummikub_Online/
└── Domino_Online/
```

## GitHub y Render con el ZIP

Sube a la raíz del repositorio el archivo `Juegos_de_mesa_no_tan_de_mesa.zip` y el archivo `render.yaml`. Render ejecuta el `buildCommand` del Blueprint, extrae el ZIP e instala las dependencias declaradas en el `package.json` raíz. No descomprimas el ZIP antes de subirlo.

En Render crea el servicio usando **New → Blueprint** y selecciona el repositorio. Mantén `Root Directory` vacío. El servicio inicia los tres juegos secundarios desde el servidor principal.

## Despliegue manual alternativo

Si utilizas Web Service en lugar de Blueprint:

| Campo | Valor |
|---|---|
| Runtime | Node |
| Build Command | `unzip -o Juegos_de_mesa_no_tan_de_mesa.zip -d . && npm install --omit=dev --no-audit --no-fund` |
| Start Command | `npm start` |
| Health Check Path | `/health` |

## Ejecutar localmente

Requisitos: Node.js 20 o superior y conexión para instalar las dependencias la primera vez.

```bash
npm install --omit=dev
npm start
```

Rutas: `/`, `/biodefensa/`, `/rummikub/`, `/domino/` y `/health`.

Comprobaciones: `npm run check` y `npm test`.

## Dominó Club

- Variante doble-seis de 28 fichas, de 0–0 a 6–6.
- De 2 a 4 participantes; siete fichas por persona.
- Si está en la mano, abre la mula de seis. Si no se repartió, abre el doble más alto; si no hay dobles, la ficha de mayor suma.
- En modalidad **Robar**, si no hay jugada se roba hasta conseguir ficha jugable o agotar el pozo. En modalidad **Pasar**, se pasa sin robar.
- La ronda termina cuando alguien se queda sin fichas o todos pasan consecutivamente con el pozo vacío.
- En cuatro participantes se puede activar juego por parejas en puestos opuestos.
- Meta configurable de 50, 100, 150 o 200 puntos.
- Ocho avatares propios, ocho estilos de fichas y cinco colores de mesa.
- Contra IA con dificultad Fácil, Normal y Difícil; modo local de misma pantalla y salas online con código.

Las reglas de dominó varían por región y familia. Esta implementación concreta usa dominó doble-seis, reparto de siete fichas, robo/pase configurable y puntuación por suma de fichas restantes.

Las salas online y marcadores de Dominó viven en memoria del proceso; al reiniciar el servicio se pierden las salas activas. Para partidas de corta duración funciona sin un disco adicional; la persistencia de partidas pendientes requeriría almacenamiento externo.

## Añadir futuros juegos

Cada juego nuevo se incorpora como carpeta independiente y se añade a `SERVICES` del servidor principal. Si utiliza Socket.IO, también se habilita su ruta WebSocket en el proxy. Después se agrega su tarjeta al catálogo y se incluyen las dependencias necesarias en el `package.json` raíz.
