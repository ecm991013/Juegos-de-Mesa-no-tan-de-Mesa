# Juegos de mesa no tan de mesa

Plataforma con tres juegos web independientes: BioDefensa, Rummikub Online Club y Dominó Club.

## Despliegue
Sube el ZIP `Juegos_de_mesa_no_tan_de_mesa.zip` junto con `render.yaml` a GitHub. Render extrae el ZIP durante el build, instala las dependencias raíz e inicia el portal con `npm start`.

## Última actualización · 1.5.1
- Portada de Dominó sin texto recortable y con proporción adaptable.
- Revisión de tamaños y espaciados de la tarjeta de catálogo.
- Pausas de IA más largas, con indicador visible de pensamiento.
