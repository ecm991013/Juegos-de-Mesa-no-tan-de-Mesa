# Juegos de mesa no tan de mesa

Plataforma con tres juegos web independientes: BioDefensa, Rummikub Online Club y Dominó Club.

## Despliegue
Sube el ZIP `Juegos_de_mesa_no_tan_de_mesa.zip` junto con `render.yaml` a GitHub. Render extrae el ZIP durante el build, instala las dependencias raíz e inicia el portal con `npm start`.

## Última actualización · 1.5.2
- Se reemplazó la portada de Dominó por una ilustración vectorial sin texto incrustado y con URL nueva para invalidar cachés anteriores.
- Las respuestas HTML y SVG ahora usan `Cache-Control: no-cache`, evitando que un navegador conserve portadas antiguas durante 24 horas.
- La tarjeta mantiene una relación 12:5 consistente en escritorio y móvil.
