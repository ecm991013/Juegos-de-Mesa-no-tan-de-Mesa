# Juegos de mesa no tan de mesa

Plataforma con tres juegos web independientes: BioDefensa, Rummikub Online Club y Dominó Club.

## Despliegue
Sube el ZIP `Juegos_de_mesa_no_tan_de_mesa.zip` junto con `render.yaml` a GitHub. Render extrae el ZIP durante el build, instala las dependencias raíz e inicia el portal con `npm start`.

## Última actualización · 1.5.3
- La tarjeta de Dominó utiliza la portada `domino-cover-v3.png` (2400 × 1000).
- La imagen se escala con anchura completa y altura proporcional; el marco completo queda visible y no se recorta.
- El enlace de la imagen cambia de versión para que el navegador no reutilice el recurso anterior.
- HTML, CSS, JavaScript y SVG usan `Cache-Control: no-cache`; además, las hojas CSS y scripts utilizan URLs versionadas.
- BioDefensa y Rummikub conservan sus reglas y archivos.
