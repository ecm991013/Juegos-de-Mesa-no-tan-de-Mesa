# Juegos de mesa no tan de mesa

Plataforma con tres juegos web independientes: BioDefensa, Rummikub Online Club y Dominó Club.

## Despliegue
Sube el ZIP `Juegos_de_mesa_no_tan_de_mesa.zip` junto con `render.yaml` a GitHub. Render extrae el ZIP durante el build, instala las dependencias raíz e inicia el portal con `npm start`.

## Última actualización · 1.8.7
- El recorrido serpenteante conecta cada ficha mediante sus puertos reales; los giros dibujan codos continuos desde el extremo de la ficha anterior hasta el extremo de entrada de la siguiente.
- Al doblar hacia abajo/arriba, la ficha vertical queda en el codo y la fila siguiente regresa en sentido contrario, sin líneas que atraviesen los centros de las fichas.
- La ficha inicial continúa anclada al centro; las ramas izquierda y derecha se distribuyen desde ella.
- El cliente muestra la vista de partida antes de medir la mesa y utiliza el ancho real de la capa de fichas para alinear SVG y piezas en escritorio/móvil.
- Se suavizó la zona de detección del gesto arriba/abajo para que sea más fácil indicar el giro al arrastrar.
- BioDefensa y Rummikub no se modificaron.

## Actualización anterior · 1.8.5
- La tarjeta de Dominó utiliza la portada `domino-cover-v3.png` (2400 × 1000).
- La imagen se escala con anchura completa y altura proporcional; el marco completo queda visible y no se recorta.
- El enlace de la imagen cambia de versión para que el navegador no reutilice el recurso anterior.
- HTML, CSS, JavaScript y SVG usan `Cache-Control: no-cache`; además, las hojas CSS y scripts utilizan URLs versionadas.
- BioDefensa y Rummikub conservan sus reglas y archivos.


## Dominó Club 1.6.0
- Previsualización en vivo del acabado de fichas y color del paño.
- Las fichas de la mano no se resaltan ni deshabilitan individualmente según su jugada; el jugador decide y el servidor valida.
- Recorrido serpenteante: las filas alternan derecha e izquierda y se conectan con curvas visuales.


### Dominó Club 1.7.0

La cadena se distribuye en varias filas conectadas, no en una sola línea horizontal. Cada fila alterna su sentido: avanza a la derecha, gira al siguiente tramo y vuelve a la izquierda. El número de fichas por fila se calcula según el ancho del tablero y se vuelve a calcular al cambiar el tamaño de pantalla. Al arrastrar una ficha, el extremo de destino se decide por proximidad al primer o último elemento visible de la cadena.


## Dominó Club 1.8.2 — mano y recorrido
- La ficha de apertura queda centrada respecto al área útil visible de la mesa, descontando el padding superior e inferior del escenario.
- La cadena crece desde la ficha inicial hacia los extremos izquierdo y derecho.
- El usuario puede ordenar manualmente su mano arrastrando fichas sobre otras.
- Al soltar una ficha por debajo o por encima del extremo, puede indicar que el próximo tramo doble hacia abajo o arriba; también puede escogerlo con los controles de dirección.
- Las fichas dobles y normales conservan dimensiones idénticas en horizontal y vertical, también en móvil.
- Se amplían las pruebas de arrastre, orden manual, apertura centrada y giros en ambos lados.


## Dominó Club 1.8.3 — revisión de avatares y rivales
- Se corrigió la programación duplicada del temporizador de IA al crear una partida: cada turno de IA ahora se agenda una sola vez.
- Los ocho retratos del selector usan identificadores neutros (`avatar-01` a `avatar-08`), se muestran en una cuadrícula uniforme y ya no tienen nombres debajo.
- Los rivales IA ahora tienen nombres ficticios propios: Don Jacinto, La Chispa, El Zurdo, Doña Mula, Capitán Doble, La Centella, Tito Seis y La Estratega.
- La selección de rivales evita repetir el retrato elegido por el jugador y evita duplicar retratos entre IA; en la modalidad local también asigna retratos distintos.
- Se corrigió la puntuación por cierre bloqueado en parejas: el equipo ganador recibe la diferencia entre los puntos restantes del equipo rival y los suyos.
- Nueva cobertura de pruebas para roster, avatares, programación de IA y puntuación por parejas.
- BioDefensa y Rummikub permanecen sin cambios en sus reglas ni en sus archivos.


## Dominó Club 1.8.4 — revisión funcional y avatares
- Se revisó el flujo de creación de partidas, temporizador de IA, cierre bloqueado y selección de participantes.
- Se eliminó una programación redundante del turno de IA al crear una partida.
- Se corrigió el cálculo de puntos por cierre bloqueado en parejas: el equipo ganador recibe la diferencia de puntos restantes entre ambos equipos.
- El selector presenta ocho retratos ilustrados uniformes, sin nombres debajo. Los archivos usan IDs neutrales (`avatar-01` a `avatar-08`).
- Los rivales de IA tienen nombres propios: Don Jacinto, La Chispa, El Zurdo, Doña Mula, Capitán Doble, La Centella, Tito Seis y La Estratega. Sus retratos se asignan sin duplicar el del jugador.
- Se migran las preferencias antiguas de avatar a los nuevos IDs neutrales para conservar la selección guardada.
- Suite verificada: 100 pruebas aprobadas y comprobación sintáctica superada.
- Limitación de esta revisión: no se pudo iniciar el servidor web real en este entorno porque Express y Socket.IO no están instalados localmente; ambos están declarados en las dependencias raíz para su instalación durante el despliegue.


## Dominó Club 1.8.5 — corrección de la cadena invisible

- **Causa raíz:** `Domino_Online/public/index.html` solicita `/domino/layout.js`, pero Express solo publica archivos que están dentro de `Domino_Online/public`. El módulo `layout.js` existía únicamente en la raíz del juego. Mientras la cadena estaba vacía, el cliente podía mostrar la mano; al recibir la primera ficha y tratar de dibujar una cadena no vacía, `window.DominoLayout` no existía y el render se interrumpía. Esto explica la mesa vacía de la captura.
- Se añadió `Domino_Online/public/layout.js`, copia exacta del módulo fuente `Domino_Online/layout.js`, para que Express lo pueda servir mediante la misma ruta solicitada por el HTML.
- Se versionaron las referencias de `layout.js`, `client.js` y `styles.css` a `1.8.5` para evitar mezclar recursos de versiones anteriores.
- El test del cliente ahora ejecuta el `layout.js` público real en el DOM simulado en vez de inyectar únicamente el módulo Node. Se añadió una regresión que entrega un `gameState` con tres fichas y comprueba que el HTML del tablero contiene todas las fichas, la apertura y los conectores.
- Se añadió una verificación de que el archivo público existe y coincide byte por byte con el módulo fuente.
- Verificación: `npm run check` correcto; `npm test` con 102 pruebas aprobadas, 0 fallidas.
- BioDefensa y Rummikub no se modificaron.


## Corrección de orientación de fichas · v1.8.6

Al volver una fila en el recorrido serpenteante, se invierten únicamente las mitades visuales (a/b) para que el número coincidente quede junto a la ficha anterior. La secuencia lógica del servidor permanece en orden a→b. Se añadieron pruebas para ramas izquierda/derecha y giros arriba/abajo.


## Dominó Club 1.8.6 — orientación 5-4 en la cadena serpenteante
- Se detectó que las fichas de las filas de retorno se mostraban con las mitades al revés: el modelo lógico seguía `a → b`, pero el diseño visual no reflejaba que la cadena ahora avanzaba de derecha a izquierda.
- `layout.js` ahora entrega `reverseHalves` según el sentido físico del tramo, tanto en la rama izquierda como derecha y para giros arriba/abajo.
- El renderer añade la clase `reverse-halves`; CSS intercambia la posición de las mitades dentro de la cuadrícula horizontal o vertical.
- `rules.playTile` mantiene la conexión del valor coincidente y la respuesta `played` devuelve el orden normalizado del servidor. Para el caso reportado, `5-4` conectado al `5` se muestra con el 5 en el lado de unión durante el retorno.
- Las referencias CSS, layout y cliente se versionaron a `1.8.6`.
- Verificación: `npm test` 109/109 aprobadas y `npm run check` correcto.
