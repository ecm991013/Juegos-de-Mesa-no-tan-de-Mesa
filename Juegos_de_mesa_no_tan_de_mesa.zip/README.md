# Juegos de mesa no tan de mesa

Portal web que reúne juegos HTML independientes en una sola plataforma.

## Juegos incluidos

- **BioDefensa 0.15.4** — cartas, estrategia, multijugador y rivales de IA.
- **Rummikub Online Club 1.4.1** — fichas, combinaciones, multijugador y rivales de IA.
- **Parqués Club 1.1.0** — tablero personalizable de 4 o 6 puestos, cuatro fichas por jugador, dados, rivales de IA con tres dificultades y salas online por código.

Cada juego conserva su servidor, recursos y reglas. El proceso principal sirve el catálogo y enruta HTTP y WebSocket hacia los juegos.

## Estructura

```text
.
├── server.js
├── package.json
├── public/
├── virus_multijugador/
├── Rummikub_Online/
└── Parques_Online/
```

## GitHub y Render con el ZIP

Sube a la raíz del repositorio el archivo `Juegos_de_mesa_no_tan_de_mesa.zip` y el archivo `render.yaml`. Render ejecuta el `buildCommand` del Blueprint, extrae el ZIP e instala las dependencias declaradas en el `package.json` raíz. No descomprimas el ZIP antes de subirlo.

En Render crea el servicio usando **New → Blueprint** y selecciona el repositorio. Mantén `Root Directory` vacío. El servicio inicia los tres juegos secundarios desde el servidor principal.

## Despliegue manual alternativo

Si utilizas Web Service en lugar de Blueprint:

| Campo | Valor |
|---|---|
| Runtime | Node |
| Build Command | `unzip -o Juegos_de_mesa_no_tan_de_mesa.zip -d . && npm install --omit=dev --no-audit --no-fund` |
| Start Command | `npm start` |
| Health Check Path | `/health` |

## Ejecutar localmente

Requisitos: Node.js 20 o superior y conexión para instalar las dependencias la primera vez.

```bash
npm install --omit=dev
npm start
```

Rutas: `http://localhost:3000/`, `/biodefensa/`, `/rummikub/`, `/parques/` y `/health`.

Comprobaciones: `npm run check` y `npm test`.

## Reglas implementadas en Parqués Club

La primera versión usa un conjunto habitual de reglas de Parqués: dos dados; un 5 en cualquiera de los dados permite sacar una ficha; los pares conceden un lanzamiento adicional; las casillas de salida y las casillas seguras protegen de capturas; no existen barreras por acumulación, por lo que cualquier cantidad de fichas puede compartir una casilla y es posible pasar por ella; al aterrizar en una casilla no segura se capturan todas las fichas rivales que estén allí; y se requiere el número exacto para llegar a la meta. La penalización por tres pares seguidos es opcional.

La configuración inicial permite escoger uno de ocho retratos y el color del equipo; en salas online se respeta el retrato y se asigna un color disponible. El tablero usa una distribución cuadrada con casas en las esquinas, circuito perimetral, carriles de llegada y centro de colores. La interfaz mantiene el último resultado de dados visible incluso cuando el turno pasa automáticamente.

Las reglas de Parqués tienen variantes regionales y familiares. Esta implementación deja la regla de tres pares como opción y documenta el conjunto concreto utilizado, para no confundirlo con todas las variantes posibles.

## Salas online y almacenamiento

Las salas online de Parqués se crean con un código que se comparte con otros jugadores. En esta primera versión, el anfitrión elige tablero de 4 o 6 puestos y la partida comienza cuando todos los puestos están ocupados. Las salas y partidas viven en memoria del proceso; una suspensión o reinicio de un servicio gratuito puede cerrarlas. Para persistencia permanente hará falta una base de datos.

## Añadir futuros juegos

Cada juego nuevo se incorpora como carpeta independiente y se añade a `SERVICES` del servidor principal. Si utiliza Socket.IO, también se habilita su ruta WebSocket en el proxy. Después se agrega su tarjeta al catálogo y se incluyen las dependencias necesarias en el `package.json` raíz.
