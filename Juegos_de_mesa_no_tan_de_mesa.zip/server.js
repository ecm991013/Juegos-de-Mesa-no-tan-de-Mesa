'use strict';

// Puerta de entrada de Juegos de mesa no tan de mesa.
// Cada juego conserva su servidor y sus reglas; este proceso solo enruta tráfico.
const http = require('node:http');
const net = require('node:net');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const HOST = process.env.HOST || '0.0.0.0';
const PORT = Number(process.env.PORT || 3000);
const SERVICES = {
  '/biodefensa': { port: 3101, cwd: path.join(ROOT, 'virus_multijugador'), script: 'server.js' },
  '/rummikub': { port: 3102, cwd: path.join(ROOT, 'Rummikub_Online'), script: 'server.js' }
};
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.woff': 'font/woff',
  '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8'
};

const children = [];
let shuttingDown = false;

function startChild(name, config) {
  const child = spawn(process.execPath, [config.script], {
    cwd: config.cwd,
    env: {
      ...process.env,
      PORT: String(config.port),
      HOST: '127.0.0.1'
    },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  child.stdout.on('data', chunk => process.stdout.write(`[${name}] ${chunk}`));
  child.stderr.on('data', chunk => process.stderr.write(`[${name}] ${chunk}`));
  child.on('error', error => console.error(`[${name}] No se pudo iniciar:`, error.message));
  child.on('exit', (code, signal) => {
    console.error(`[${name}] terminó (código ${code ?? 'n/a'}, señal ${signal ?? 'n/a'}).`);
    if (!shuttingDown) console.error(`[${name}] El portal seguirá activo, pero este juego no estará disponible hasta reiniciar el servicio.`);
  });
  children.push(child);
  return child;
}

function serviceFor(pathname) {
  for (const [prefix, config] of Object.entries(SERVICES)) {
    if (pathname === prefix || pathname.startsWith(prefix + '/')) return { prefix, config };
  }
  return null;
}

function stripPrefix(requestUrl, prefix) {
  const parsed = new URL(requestUrl, 'http://localhost');
  let pathname = parsed.pathname.slice(prefix.length);
  if (!pathname) pathname = '/';
  if (!pathname.startsWith('/')) pathname = '/' + pathname;
  return pathname + parsed.search;
}

function proxyHttp(req, res, route) {
  const targetPath = stripPrefix(req.url, route.prefix);
  const proxyReq = http.request({
    hostname: '127.0.0.1',
    port: route.config.port,
    method: req.method,
    path: targetPath,
    headers: { ...req.headers, host: `127.0.0.1:${route.config.port}` }
  }, proxyRes => {
    res.writeHead(proxyRes.statusCode || 502, proxyRes.headers);
    proxyRes.pipe(res);
  });
  proxyReq.on('error', error => {
    if (res.headersSent) return res.destroy(error);
    const body = JSON.stringify({ ok: false, error: 'El juego está iniciando o no está disponible. Intenta de nuevo en unos segundos.' });
    res.writeHead(502, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body), 'cache-control': 'no-store' });
    res.end(body);
  });
  req.on('aborted', () => proxyReq.destroy());
  req.pipe(proxyReq);
}

function servePortal(req, res) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { allow: 'GET, HEAD' });
    return res.end('Method Not Allowed');
  }
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); }
  catch { res.writeHead(400); return res.end('Bad Request'); }
  if (pathname === '/') pathname = '/index.html';
  const filePath = path.resolve(PUBLIC_DIR, '.' + pathname);
  if (filePath !== PUBLIC_DIR && !filePath.startsWith(PUBLIC_DIR + path.sep)) {
    res.writeHead(403); return res.end('Forbidden');
  }
  fs.stat(filePath, (statError, stat) => {
    if (statError || !stat.isFile()) {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      return res.end('No encontrado.');
    }
    const contentType = MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
    const cache = path.extname(filePath).toLowerCase() === '.html' ? 'no-cache' : 'public, max-age=86400';
    res.writeHead(200, { 'content-type': contentType, 'content-length': stat.size, 'cache-control': cache, 'x-content-type-options': 'nosniff' });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(filePath).pipe(res);
  });
}

const server = http.createServer((req, res) => {
  const pathname = new URL(req.url, 'http://localhost').pathname;
  if (pathname === '/health') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    return res.end(JSON.stringify({ ok: true, app: 'Juegos de mesa no tan de mesa' }));
  }
  const route = serviceFor(pathname);
  if (route) return proxyHttp(req, res, route);
  return servePortal(req, res);
});

// Socket.IO usa WebSocket además de HTTP polling. Se reenvía el upgrade a
// Rummikub y se elimina el prefijo público antes de entregarlo.
server.on('upgrade', (req, socket, head) => {
  const pathname = new URL(req.url, 'http://localhost').pathname;
  const route = serviceFor(pathname);
  if (!route || route.prefix !== '/rummikub' || !pathname.startsWith(route.prefix + '/socket.io')) {
    socket.destroy();
    return;
  }
  const upstream = net.connect(route.config.port, '127.0.0.1');
  upstream.on('connect', () => {
    const target = stripPrefix(req.url, route.prefix);
    const headers = req.rawHeaders.slice();
    for (let i = 0; i < headers.length; i += 2) {
      if (headers[i].toLowerCase() === 'host') headers[i + 1] = `127.0.0.1:${route.config.port}`;
    }
    const headerLines = [];
    for (let i = 0; i < headers.length; i += 2) headerLines.push(`${headers[i]}: ${headers[i + 1]}`);
    upstream.write(`${req.method} ${target} HTTP/${req.httpVersion}\r\n${headerLines.join('\r\n')}\r\n\r\n`);
    if (head?.length) upstream.write(head);
    socket.pipe(upstream);
    upstream.pipe(socket);
  });
  upstream.on('error', () => {
    if (!socket.destroyed) {
      socket.end('HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n');
    }
  });
  socket.on('error', () => upstream.destroy());
  socket.on('close', () => upstream.destroy());
});

startChild('BioDefensa', SERVICES['/biodefensa']);
startChild('Rummikub', SERVICES['/rummikub']);
server.listen(PORT, HOST, () => {
  console.log(`Portal listo en http://localhost:${PORT}`);
  console.log('BioDefensa: /biodefensa/');
  console.log('Rummikub: /rummikub/');
});

function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`Cerrando plataforma (${signal})...`);
  server.close();
  for (const child of children) child.kill('SIGTERM');
  setTimeout(() => {
    for (const child of children) if (!child.killed) child.kill('SIGKILL');
  }, 7000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
