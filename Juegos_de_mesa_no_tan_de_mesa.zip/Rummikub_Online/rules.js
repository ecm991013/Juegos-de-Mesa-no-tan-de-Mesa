'use strict';

/**
 * Calcula los puntos aportados por las fichas propias en la apertura inicial.
 * normalizedGroups debe contener las combinaciones después de asignar los
 * comodines, por lo que el valor numérico del comodín está en tile.as.n.
 */
function calculateOpeningPoints(ownPlayed, normalizedGroups) {
  const normalizedFlat = (Array.isArray(normalizedGroups) ? normalizedGroups : []).flat();
  return (Array.isArray(ownPlayed) ? ownPlayed : []).reduce((sum, tile) => {
    if (!tile || typeof tile !== 'object') return sum;
    if (!tile.joker) return sum + (Number.isFinite(tile.n) ? tile.n : 0);
    const placed = normalizedFlat.find(candidate => candidate && candidate.id === tile.id);
    return sum + (Number.isFinite(placed?.as?.n) ? placed.as.n : 0);
  }, 0);
}

module.exports = { calculateOpeningPoints };
