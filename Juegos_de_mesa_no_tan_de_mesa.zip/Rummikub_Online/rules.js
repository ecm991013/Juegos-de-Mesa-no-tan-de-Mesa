'use strict';

const VALID_COLORS = ['red', 'blue', 'black', 'orange'];
const MAX_RUN_LENGTH = 13;

/**
 * Acepta conjuntos de 3-4 colores diferentes con el mismo número y
 * escaleras de 3-13 números consecutivos del mismo color.
 * El límite anterior de cuatro fichas se aplicaba por error también a escaleras.
 */
function isValidRummikubGroup(group) {
  if (!Array.isArray(group) || group.length < 3 || group.length > MAX_RUN_LENGTH) return false;
  if (group.some(tile => {
    if (!tile || typeof tile !== 'object') return true;
    if (tile.joker) {
      return !tile.as || !VALID_COLORS.includes(tile.as.color) ||
        !Number.isInteger(tile.as.n) || tile.as.n < 1 || tile.as.n > 13;
    }
    return !VALID_COLORS.includes(tile.color) || !Number.isInteger(tile.n) || tile.n < 1 || tile.n > 13;
  })) return false;

  const resolved = group.map(tile => tile.joker
    ? { color: tile.as.color, n: tile.as.n }
    : { color: tile.color, n: tile.n });
  const nums = resolved.map(tile => tile.n);
  const colors = resolved.map(tile => tile.color);

  const isSet = group.length <= 4 &&
    nums.every(number => number === nums[0]) &&
    new Set(colors).size === colors.length;

  const sorted = [...resolved].sort((a, b) => a.n - b.n);
  const isRun = resolved.every(tile => tile.color === colors[0]) &&
    new Set(nums).size === nums.length &&
    sorted[sorted.length - 1].n - sorted[0].n === sorted.length - 1;

  return isSet || isRun;
}

/** Asigna comodines sin perder el valor representado en las combinaciones. */
function assignRummikubGroup(group) {
  if (!Array.isArray(group) || group.length < 3 || group.length > MAX_RUN_LENGTH) return null;
  const jokers = [];
  group.forEach((tile, index) => { if (tile?.joker && !tile.as) jokers.push(index); });
  if (jokers.length === 0) return isValidRummikubGroup(group) ? group : null;

  const result = JSON.parse(JSON.stringify(group));
  function search(depth) {
    if (depth === jokers.length) return isValidRummikubGroup(result)
      ? JSON.parse(JSON.stringify(result))
      : null;
    const index = jokers[depth];
    for (const color of VALID_COLORS) {
      for (let number = 13; number >= 1; number--) {
        result[index].as = { color, n: number };
        const found = search(depth + 1);
        if (found) return found;
      }
    }
    delete result[index].as;
    return null;
  }
  return search(0);
}

/**
 * Calcula los puntos aportados por las fichas propias en la apertura inicial.
 * normalizedGroups contiene las combinaciones validadas por el servidor.
 */
function calculateOpeningPoints(ownPlayed, normalizedGroups) {
  const normalizedFlat = (Array.isArray(normalizedGroups) ? normalizedGroups : []).flat();
  return (Array.isArray(ownPlayed) ? ownPlayed : []).reduce((sum, tile) => {
    if (!tile || typeof tile !== 'object') return sum;
    if (!tile.joker) return sum + (Number.isFinite(tile.n) ? tile.n : 0);
    const placed = normalizedFlat.find(candidate => candidate && candidate.id === tile.id);
    return sum + (Number.isFinite(placed?.as?.n) ? placed.as.n : 0);
  }, 0);
}

module.exports = {
  calculateOpeningPoints,
  isValidRummikubGroup,
  assignRummikubGroup,
  MAX_RUN_LENGTH
};
