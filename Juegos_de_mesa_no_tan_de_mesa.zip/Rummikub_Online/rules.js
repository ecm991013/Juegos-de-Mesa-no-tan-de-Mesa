'use strict';

// Reglas puras compartidas por el servidor y las pruebas automáticas.
const crypto = require('node:crypto');

const COLORS = Object.freeze(['red', 'blue', 'black', 'orange']);
const clone = value => JSON.parse(JSON.stringify(value));

function makeTiles() {
  const tiles = [];
  for (let copy = 0; copy < 2; copy++) {
    for (const color of COLORS) {
      for (let n = 1; n <= 13; n++) tiles.push({ id: crypto.randomUUID(), color, n, joker: false });
    }
  }
  tiles.push({ id: crypto.randomUUID(), joker: true }, { id: crypto.randomUUID(), joker: true });
  for (let i = tiles.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [tiles[i], tiles[j]] = [tiles[j], tiles[i]];
  }
  return tiles;
}

function exactGroup(group) {
  if (!Array.isArray(group) || group.length < 3 || group.length > 4) return false;
  if (group.some(tile => !tile || (tile.joker && (!tile.as || !COLORS.includes(tile.as.color) || !Number.isInteger(tile.as.n) || tile.as.n < 1 || tile.as.n > 13)))) return false;
  const resolved = group.map(tile => tile.joker ? { color: tile.as.color, n: tile.as.n } : { color: tile.color, n: tile.n });
  if (resolved.some(tile => !COLORS.includes(tile.color) || !Number.isInteger(tile.n) || tile.n < 1 || tile.n > 13)) return false;
  const nums = resolved.map(tile => tile.n);
  const colors = resolved.map(tile => tile.color);
  const isSet = nums.every(n => n === nums[0]) && new Set(colors).size === colors.length;
  const sorted = [...resolved].sort((a, b) => a.n - b.n);
  const isRun = resolved.every(tile => tile.color === colors[0]) &&
    new Set(nums).size === nums.length &&
    sorted[sorted.length - 1].n - sorted[0].n === sorted.length - 1;
  return isSet || isRun;
}

// Asigna a los comodines la primera representación válida, sin modificar el grupo recibido.
function assignGroup(group) {
  if (!Array.isArray(group) || group.length < 3 || group.length > 4) return null;
  const jokers = [];
  group.forEach((tile, index) => { if (tile?.joker && !tile.as) jokers.push(index); });
  if (jokers.length === 0) return exactGroup(group) ? group : null;
  const result = clone(group);
  function search(depth) {
    if (depth === jokers.length) return exactGroup(result) ? clone(result) : null;
    const index = jokers[depth];
    for (const color of COLORS) {
      for (let n = 13; n >= 1; n--) {
        result[index].as = { color, n };
        const found = search(depth + 1);
        if (found) return found;
      }
    }
    delete result[index].as;
    return null;
  }
  return search(0);
}

function scoreHand(hand) {
  return hand.reduce((sum, tile) => sum + (tile.joker ? 30 : tile.n), 0);
}

module.exports = { COLORS, makeTiles, exactGroup, assignGroup, scoreHand };
