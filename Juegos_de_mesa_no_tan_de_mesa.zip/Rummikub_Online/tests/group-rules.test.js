'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { isValidRummikubGroup, assignRummikubGroup, MAX_RUN_LENGTH } = require('../rules');

const run = (color, start, end) => Array.from({ length: end - start + 1 }, (_, index) => ({
  id: `${color}-${start + index}`, color, n: start + index, joker: false
}));

test('acepta escaleras de más de cuatro fichas', () => {
  assert.equal(isValidRummikubGroup(run('blue', 2, 7)), true);
});

test('acepta una escalera de longitud máxima del 1 al 13', () => {
  assert.equal(MAX_RUN_LENGTH, 13);
  assert.equal(isValidRummikubGroup(run('orange', 1, 13)), true);
});

test('rechaza escaleras que exceden el rango disponible', () => {
  const fourteen = [...run('red', 1, 13), { id: 'red-14', color: 'red', n: 1, joker: false }];
  assert.equal(isValidRummikubGroup(fourteen), false);
});

test('mantiene la regla de conjuntos de tres o cuatro colores distintos', () => {
  const validSet = ['red', 'blue', 'black', 'orange'].map((color, index) => ({ id: `set-${index}`, color, n: 9 }));
  const invalidSet = [...validSet, { id: 'set-duplicate', color: 'red', n: 9 }];
  assert.equal(isValidRummikubGroup(validSet), true);
  assert.equal(isValidRummikubGroup(invalidSet), false);
});

test('rechaza una escalera con huecos o números repetidos', () => {
  assert.equal(isValidRummikubGroup([
    { id: 'a', color: 'blue', n: 2 },
    { id: 'b', color: 'blue', n: 3 },
    { id: 'c', color: 'blue', n: 5 },
    { id: 'd', color: 'blue', n: 6 }
  ]), false);
});

test('asigna correctamente un comodín dentro de una escalera larga', () => {
  const group = [
    { id: 'a', color: 'red', n: 1 },
    { id: 'b', color: 'red', n: 2 },
    { id: 'j', joker: true },
    { id: 'd', color: 'red', n: 4 },
    { id: 'e', color: 'red', n: 5 },
    { id: 'f', color: 'red', n: 6 }
  ];
  const normalized = assignRummikubGroup(group);
  assert.ok(normalized);
  assert.deepEqual(normalized.find(tile => tile.id === 'j').as, { color: 'red', n: 3 });
  assert.equal(isValidRummikubGroup(normalized), true);
});
