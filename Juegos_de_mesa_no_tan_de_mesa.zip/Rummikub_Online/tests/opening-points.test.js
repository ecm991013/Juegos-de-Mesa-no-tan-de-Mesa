'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { calculateOpeningPoints } = require('../rules');

test('calcula una apertura de más de 39 puntos con varias combinaciones', () => {
  const ownPlayed = [
    { id: 'r10', n: 10 }, { id: 'r11', n: 11 }, { id: 'r12', n: 12 },
    { id: 'b7', n: 7 }
  ];
  const normalizedGroups = [
    [{ id: 'r10', n: 10 }, { id: 'r11', n: 11 }, { id: 'r12', n: 12 }],
    [{ id: 'b5', n: 5 }, { id: 'b6', n: 6 }, { id: 'b7', n: 7 }]
  ];
  assert.equal(calculateOpeningPoints(ownPlayed, normalizedGroups), 40);
});

test('incluye el valor asignado al comodín al calcular la apertura', () => {
  const ownPlayed = [
    { id: 'a9', n: 9 }, { id: 'joker-1', joker: true }, { id: 'a11', n: 11 },
    { id: 'b8', n: 8 }, { id: 'b9', n: 9 }, { id: 'b10', n: 10 }
  ];
  const normalizedGroups = [
    [
      { id: 'a9', n: 9 },
      { id: 'joker-1', joker: true, as: { color: 'red', n: 10 } },
      { id: 'a11', n: 11 }
    ],
    [{ id: 'b8', n: 8 }, { id: 'b9', n: 9 }, { id: 'b10', n: 10 }]
  ];
  assert.equal(calculateOpeningPoints(ownPlayed, normalizedGroups), 57);
});

test('suma solamente fichas propias y no las que ya estaban en mesa', () => {
  const ownPlayed = [{ id: 'own-12', n: 12 }, { id: 'own-13', n: 13 }, { id: 'own-8', n: 8 }];
  const normalizedGroups = [
    [{ id: 'table-1', n: 10 }, { id: 'own-12', n: 12 }, { id: 'own-13', n: 13 }],
    [{ id: 'own-8', n: 8 }, { id: 'other-8', n: 8 }, { id: 'other-8b', n: 8 }]
  ];
  assert.equal(calculateOpeningPoints(ownPlayed, normalizedGroups), 33);
});
