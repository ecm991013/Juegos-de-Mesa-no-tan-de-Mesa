'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { COLORS, makeTiles, exactGroup, assignGroup, scoreHand } = require('../rules');

test('el mazo contiene 106 fichas, dos copias de cada número/color y dos comodines', () => {
  const tiles = makeTiles();
  assert.equal(tiles.length, 106);
  assert.equal(new Set(tiles.map(tile => tile.id)).size, 106);
  assert.equal(tiles.filter(tile => tile.joker).length, 2);
  for (const color of COLORS) {
    for (let n = 1; n <= 13; n++) {
      assert.equal(tiles.filter(tile => !tile.joker && tile.color === color && tile.n === n).length, 2);
    }
  }
});

test('acepta escaleras de tres o cuatro números consecutivos del mismo color', () => {
  assert.equal(exactGroup([
    { color: 'blue', n: 4 }, { color: 'blue', n: 5 }, { color: 'blue', n: 6 }
  ]), true);
  assert.equal(exactGroup([
    { color: 'orange', n: 9 }, { color: 'orange', n: 10 }, { color: 'orange', n: 11 }, { color: 'orange', n: 12 }
  ]), true);
});

test('acepta grupos de tres o cuatro números iguales con colores distintos', () => {
  assert.equal(exactGroup([
    { color: 'red', n: 8 }, { color: 'blue', n: 8 }, { color: 'black', n: 8 }
  ]), true);
  assert.equal(exactGroup(COLORS.map(color => ({ color, n: 3 }))), true);
});

test('rechaza escaleras interrumpidas, colores mezclados y grupos con color repetido', () => {
  assert.equal(exactGroup([
    { color: 'red', n: 4 }, { color: 'red', n: 6 }, { color: 'red', n: 7 }
  ]), false);
  assert.equal(exactGroup([
    { color: 'red', n: 4 }, { color: 'blue', n: 5 }, { color: 'red', n: 6 }
  ]), false);
  assert.equal(exactGroup([
    { color: 'red', n: 8 }, { color: 'red', n: 8 }, { color: 'blue', n: 8 }
  ]), false);
  assert.equal(exactGroup([
    { color: 'red', n: 8 }, { color: 'blue', n: 8 }
  ]), false);
});

test('asigna un comodín como el número intermedio de una escalera', () => {
  const input = [
    { id: 'a', color: 'red', n: 6 },
    { id: 'j', joker: true },
    { id: 'b', color: 'red', n: 8 }
  ];
  const result = assignGroup(input);
  assert.ok(result);
  assert.deepEqual(result[1].as, { color: 'red', n: 7 });
  assert.equal(exactGroup(result), true);
  assert.equal(Object.hasOwn(input[1], 'as'), false, 'la función no debe mutar el grupo de entrada');
});

test('asigna un comodín a un color libre en un grupo de números iguales', () => {
  const result = assignGroup([
    { color: 'red', n: 11 },
    { color: 'blue', n: 11 },
    { id: 'j', joker: true }
  ]);
  assert.ok(result);
  assert.deepEqual(result[2].as, { color: 'black', n: 11 });
  assert.equal(exactGroup(result), true);
});

test('no asigna comodines a combinaciones imposibles y cuenta el comodín como 30 puntos', () => {
  assert.equal(assignGroup([
    { color: 'red', n: 2 }, { color: 'blue', n: 5 }, { id: 'j', joker: true }
  ]), null);
  assert.equal(scoreHand([{ color: 'red', n: 4 }, { joker: true }, { color: 'blue', n: 9 }]), 43);
});
