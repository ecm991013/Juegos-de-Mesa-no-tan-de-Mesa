> **Integración:** Rummikub forma parte de Juegos de mesa no tan de mesa. Para iniciar o publicar la colección completa, sigue el `README.md` de la raíz. El portal publica este juego en `/rummikub/` y conserva su servidor Socket.IO independiente. Las instrucciones siguientes describen también su ejecución individual.

# Rummikub Online Club

Juego de fichas multijugador en tiempo real para 2 a 4 participantes, con salas privadas y modo en solitario contra la IA. Incluye una identidad visual propia, personalización de fichas y avatares, y diseño adaptable a teléfonos y computadores.

## Requisitos
- Node.js 18 o superior.
- Conexión a internet para el modo online.

## Ejecutarlo localmente
1. Descomprime `Rummikub_Online_Revision_Jugabilidad_Reglas.zip`.
2. Abre una terminal dentro de la carpeta `Rummikub_Online`.
3. Ejecuta `npm install`.
4. Ejecuta `npm start`.
5. Abre `http://localhost:3000`.

No basta con abrir `index.html` directamente: el servidor Node.js administra las salas, turnos, fichas, IA y validación de jugadas.

## Publicarlo en Render desde el ZIP
Sube estos dos archivos a la raíz del repositorio de GitHub:
- `Rummikub_Online_Revision_Jugabilidad_Reglas.zip` (el proyecto completo).
- `render.yaml` (la configuración de Render).

En Render puedes crear un Blueprint desde el repositorio. El archivo `render.yaml` descomprime el proyecto y ejecuta `npm install` dentro de `Rummikub_Online`; el servidor inicia con `npm start`. La comprobación del servicio usa `GET /api/ping`.

Si configuras un Web Service manualmente, usa:
- Runtime: Node.
- Build Command: `unzip -o Rummikub_Online_Revision_Jugabilidad_Reglas.zip -d . && cd Rummikub_Online && npm install`.
- Start Command: `cd Rummikub_Online && npm start`.

## Modos de juego
- **Online:** crea una sala privada de 5 caracteres y comparte el código. De 2 a 4 jugadores.
- **Contra IA:** juega con 1, 2 o 3 rivales controlados por el servidor.
- Los bots forman combinaciones, buscan aperturas de 30 puntos con más de una combinación, extienden combinaciones existentes y roban cuando no encuentran jugada.

## Personalización
Desde el botón **Personalizar** puedes elegir siete estilos de fichas: Clásico, Moderno, Mármol, Madera, Neón, Real y Rosa pastel. También puedes elegir entre ocho avatares. Estas preferencias se guardan localmente en el dispositivo y no afectan las fichas ni las reglas de los demás jugadores.

## Reglas implementadas
- 106 fichas: dos copias de los números 1 a 13 en cuatro colores y dos comodines.
- Para determinar quién empieza, cada jugador roba una ficha; el número más alto comienza. En caso de empate, repiten los empatados. Las fichas de desempate vuelven al montón y se mezclan antes de repartir.
- Cada jugador recibe 14 fichas.
- Apertura de al menos 30 puntos usando solo fichas del propio atril.
- Escaleras de 3 o más números consecutivos del mismo color.
- Grupos de 3 o 4 fichas del mismo número, con colores diferentes.
- Después de abrir, se pueden añadir fichas, dividir grupos y reorganizar la mesa, siempre que todas las combinaciones finales sean válidas y se juegue al menos una ficha propia.
- Si no se juega, se roba una ficha y termina el turno. La ficha recién robada no se puede jugar hasta el siguiente turno.
- Para recuperar un comodín debe colocarse la ficha exacta que representa en su combinación original y utilizar el comodín en otra combinación durante ese mismo turno.
- Gana quien se queda sin fichas. Si el montón se agota y todos pasan consecutivamente, gana quien tenga menos puntos; la puntuación se calcula por diferencia respecto a sus fichas restantes. Un comodín en el atril vale 30 puntos.

Algunas ediciones y mesas familiares pueden acordar variantes. Esta aplicación aplica las reglas descritas arriba y las valida en el servidor, no solo en el navegador.

## Controles
- Desde la pantalla de inicio, pulsa **¿Cómo se juega?** para abrir el reglamento completo; también puedes abrirlo desde el botón `?` de la barra superior. Se cierra con `×`, tocando fuera del panel o con la tecla Escape.
- Toca las fichas del atril o de la mesa para seleccionarlas.
- **Crear grupo** mueve la selección a una combinación nueva.
- Toca la etiqueta `GRUPO` para elegir el destino y pulsa **Añadir al grupo**.
- **Devolver al atril** solo permite devolver fichas propias que bajaste durante ese turno; un comodín recuperado debe volver a jugarse antes de terminar.
- **Deshacer** restaura el estado del comienzo del turno.
- **Robar ficha** descarta los cambios no enviados y pasa el turno.
- **Validar y terminar turno** envía la jugada al servidor para comprobar todas las combinaciones.

## Notas técnicas
- Express sirve la web y Socket.IO sincroniza los turnos en tiempo real.
- Las fichas y la legalidad de cada jugada se validan en el servidor.
- Las salas se guardan en memoria del proceso; si Render reinicia o suspende el servicio, las salas activas se pierden.
- En el plan gratuito de Render la instancia puede suspenderse tras periodos de inactividad, por lo que la primera solicitud puede tardar en responder.


### Mejoras de movimiento y orden de fichas
- Las escaleras de un mismo color se muestran de menor a mayor, incluso cuando contienen un comodín asignado.
- Al robar una ficha, se restablece el borrador local al estado real de la mesa y del atril antes de enviar la acción, evitando que queden movimientos locales a medio hacer o que se mezclen con el nuevo turno.
- Se puede arrastrar una ficha del atril sobre una combinación de la mesa. La combinación de destino se resalta y aparece un indicador junto al dedo o cursor.
- Si se arrastra dentro del atril, se conserva la opción de reordenar manualmente las fichas.
