@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo       BIODEFENSA - SERVIDOR MULTIJUGADOR
echo ============================================
echo.

set "NODE_EXE="

REM Primero intenta encontrar Node.js en el PATH de Windows.
where node >nul 2>&1
if not errorlevel 1 set "NODE_EXE=node"

REM Si no esta en el PATH, revisa ubicaciones habituales.
if not defined NODE_EXE if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if not defined NODE_EXE if exist "%LocalAppData%\Programs\nodejs\node.exe" set "NODE_EXE=%LocalAppData%\Programs\nodejs\node.exe"
if not defined NODE_EXE if exist "%ProgramFiles(x86)%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles(x86)%\nodejs\node.exe"

if not defined NODE_EXE goto NODE_MISSING

echo Node.js detectado. Iniciando el servidor...
echo.
"%NODE_EXE%" server.js
echo.
echo El servidor se ha detenido.
echo Si aparecio un mensaje de error arriba, toma una captura para revisarlo.
pause
exit /b

:NODE_MISSING
echo ERROR: No se encontro Node.js en este computador.
echo.
echo Para solucionarlo:
echo 1. Abre https://nodejs.org/ desde tu navegador.
echo 2. Descarga la version LTS para Windows.
echo 3. Ejecuta el instalador y deja activada la opcion para agregar Node.js al PATH.
echo 4. Cuando termine, cierra esta ventana y vuelve a abrir el archivo INICIAR_WINDOWS.bat.
echo.
echo Puedes comprobar la instalacion abriendo una ventana nueva de CMD y escribiendo:
echo     node -v
echo Si aparece un numero de version, Node.js quedo instalado correctamente.
echo.
pause
exit /b 1
