const test = require('node:test');
const assert = require('node:assert/strict');
const game = require('../server');

function makeRoom(players) {
  return {
    players,
    discard: [],
    mode: 'immunity',
    finished: false,
    wins: {},
    winnerId: null,
    winnerRecordedForGame: false,
    deck: [],
    log: [],
    version: 1,
    lastActivity: Date.now(),
    currentPlayerId: players[0]?.id || null
  };
}
function organ(id, color, { shielded = false, medicines = [] } = {}) {
  return { id, color, shielded, viruses: [], medicines };
}
function medicine(id, color = 'rojo') { return { id, kind: 'medicine', color }; }

test('el mazo contiene 74 cartas, dos Blindajes, dos Matasanos y un Cambio de cuerpo', () => {
  const deck = game.makeDeck();
  assert.equal(deck.length, 74);
  assert.equal(deck.filter(c => c.kind === 'treatment' && c.treatment === 'shield').length, 2);
  assert.equal(deck.filter(c => c.kind === 'treatment' && c.treatment === 'matasanos').length, 2);
  assert.equal(deck.filter(c => c.kind === 'treatment' && c.treatment === 'body').length, 1);
});

test('Blindaje solo se aplica a un órgano sano e inmunizado', () => {
  const p1 = { id: 'p1', name: 'Uno', hand: [{ id: 's', kind: 'treatment', treatment: 'shield' }], organs: [organ('o1', 'rojo', { medicines: [medicine('m1'), medicine('m2')] })] };
  const p2 = { id: 'p2', name: 'Dos', hand: [], organs: [] };
  const room = makeRoom([p1, p2]);
  game.playCard(room, p1, { cardId: 's', organId: 'o1' });
  assert.equal(p1.organs[0].shielded, true);
  assert.equal(p1.organs[0].medicines.length, 2);
  const p3 = { id: 'p3', name: 'Tres', hand: [{ id: 's2', kind: 'treatment', treatment: 'shield' }], organs: [organ('o2', 'azul')] };
  const invalidRoom = makeRoom([p3, { id: 'p4', name: 'Cuatro', hand: [], organs: [] }]);
  assert.throws(() => game.playCard(invalidRoom, p3, { cardId: 's2', organId: 'o2' }), /inmunizado/i);
});

test('Matasanos retira solo el blindaje y conserva inmunización y medicinas', () => {
  const protectedOrgan = organ('o1', 'rojo', { shielded: true, medicines: [medicine('m1'), medicine('m2')] });
  const p1 = { id: 'p1', name: 'Uno', hand: [{ id: 'm', kind: 'treatment', treatment: 'matasanos' }], organs: [] };
  const p2 = { id: 'p2', name: 'Dos', hand: [], organs: [protectedOrgan] };
  const room = makeRoom([p1, p2]);
  game.playCard(room, p1, { cardId: 'm', targetPlayerId: 'p2', organId: 'o1' });
  assert.equal(protectedOrgan.shielded, false);
  assert.equal(protectedOrgan.medicines.length, 2);
  assert.equal(game.isImmunized(protectedOrgan), true);
});

test('Extracción e Intercambio orgánico no pueden mover órganos blindados', () => {
  const protectedOrgan = organ('o1', 'rojo', { shielded: true, medicines: [medicine('m1'), medicine('m2')] });
  const otherOrgan = organ('o2', 'azul');
  const thief = { id: 'p1', name: 'Uno', hand: [{ id: 'steal', kind: 'treatment', treatment: 'steal' }], organs: [] };
  const owner = { id: 'p2', name: 'Dos', hand: [], organs: [protectedOrgan] };
  const stealRoom = makeRoom([thief, owner]);
  assert.throws(() => game.playCard(stealRoom, thief, { cardId: 'steal', targetPlayerId: 'p2', organId: 'o1' }), /blindado/i);

  const swapper = { id: 'p3', name: 'Tres', hand: [{ id: 'swap', kind: 'treatment', treatment: 'swap' }], organs: [protectedOrgan] };
  const other = { id: 'p4', name: 'Cuatro', hand: [], organs: [otherOrgan] };
  const swapRoom = makeRoom([swapper, other]);
  assert.throws(() => game.playCard(swapRoom, swapper, { cardId: 'swap', targetPlayerId: 'p3', targetPlayerId2: 'p4', organId: 'o1', organId2: 'o2' }), /blindado/i);
});

test('Cambio de cuerpo sí puede mover un órgano blindado y conserva su estado', () => {
  const protectedOrgan = organ('o1', 'rojo', { shielded: true, medicines: [medicine('m1'), medicine('m2')] });
  const p1 = { id: 'p1', name: 'Uno', hand: [{ id: 'body', kind: 'treatment', treatment: 'body' }], organs: [protectedOrgan] };
  const p2 = { id: 'p2', name: 'Dos', hand: [], organs: [organ('o2', 'azul')] };
  const room = makeRoom([p1, p2]);
  game.playCard(room, p1, { cardId: 'body', targetPlayerId: 'p2' });
  assert.equal(p2.organs.some(o => o.id === 'o1' && o.shielded), true);
  assert.equal(p1.organs.some(o => o.id === 'o2'), true);
});
