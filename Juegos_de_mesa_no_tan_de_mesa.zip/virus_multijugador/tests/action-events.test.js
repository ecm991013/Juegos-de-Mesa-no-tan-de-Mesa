const test = require('node:test');
const assert = require('node:assert/strict');
const game = require('../server');

function roomWithPlayers() {
  return {
    players: [
      { id: 'human-1', name: 'Ana', avatarIndex: 3, isAI: false, hand: [], organs: [] },
      { id: 'ai-1', name: 'NEXUS', avatarIndex: 4, isAI: true, hand: [], organs: [] }
    ],
    log: [], actionEvents: [], version: 1, lastActivity: Date.now(),
    deck: [], discard: [], mode: 'immunity', finished: false,
    wins: {}, currentPlayerId: 'human-1'
  };
}

test('el feed del servidor publica movimientos humanos e IA con identidad y avatar', () => {
  const room = roomWithPlayers();
  game.log(room, 'Ana colocó un órgano.', 'human-1');
  game.log(room, 'NEXUS jugó un virus.', 'ai-1');

  const snapshot = game.serialize(room, 'human-1');
  assert.equal(snapshot.actionEvents.length, 2);
  assert.equal(snapshot.actionEvents[0].playerId, 'human-1');
  assert.equal(snapshot.actionEvents[0].playerName, 'Ana');
  assert.equal(snapshot.actionEvents[0].avatarIndex, 3);
  assert.equal(snapshot.actionEvents[0].isAI, false);
  assert.equal(snapshot.actionEvents[1].playerId, 'ai-1');
  assert.equal(snapshot.actionEvents[1].playerName, 'NEXUS');
  assert.equal(snapshot.actionEvents[1].avatarIndex, 4);
  assert.equal(snapshot.actionEvents[1].isAI, true);
});

test('el feed conserva los 40 eventos más recientes sin perder los últimos movimientos', () => {
  const room = roomWithPlayers();
  for (let i = 0; i < 50; i++) game.log(room, `Movimiento ${i}`, 'human-1');
  const events = game.serialize(room, 'human-1').actionEvents;
  assert.equal(events.length, 40);
  assert.equal(events[0].message, 'Movimiento 10');
  assert.equal(events[39].message, 'Movimiento 49');
});
