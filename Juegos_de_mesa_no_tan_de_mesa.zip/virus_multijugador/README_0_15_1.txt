BIODEFENSA 0.15.1

Esta versión funciona sin registro ni inicio de sesión. Al abrir la página, escribe un nombre, elige tu avatar y selecciona:
- Crear una sala para jugar con otras personas.
- Unirte a una sala usando el código.
- Jugar contra rivales controlados por IA.

DESPLIEGUE EN RENDER
1. Sustituye el contenido del repositorio por el contenido de la carpeta virus_multijugador de este ZIP.
2. Conserva el servicio web de Node que ya tienes.
3. No necesitas añadir un Persistent Disk ni configurar BIODEFENSA_DATA_DIR para permitir el acceso de invitados.
4. Haz un nuevo deploy y abre la URL del servicio.

IMPORTANTE
El modo invitado no guarda perfiles, cuentas, XP ni estadísticas asociadas a una identidad. La reconexión de una partida se intenta desde el navegador, pero si Render reinicia el servidor y no conserva los archivos, una sala activa puede perderse. Esta versión elimina la barrera de registro, no convierte el almacenamiento temporal de Render en almacenamiento permanente.
