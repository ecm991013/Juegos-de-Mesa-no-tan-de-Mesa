const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..', 'public');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'client.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'styles.css'), 'utf8');

test('Dominó tiene tres pantallas separadas: inicio, lobby y partida', () => {
  assert.match(html, /id="homeView"/);
  assert.match(html, /id="lobbyView"/);
  assert.match(html, /id="gameView"/);
  assert.match(js, /function showView\(view\)/);
});

test('el inicio permite elegir IA, online y misma pantalla antes de abrir el lobby', () => {
  for (const mode of ['ai', 'online', 'local']) {
    assert.match(html, new RegExp(`data-home-mode="${mode}"`));
  }
  assert.match(js, /openLobby\(button\.dataset\.homeMode\)/);
});

test('el lobby contiene configuración y sala de espera online en la misma etapa', () => {
  assert.match(html, /id="lobbyConfigPanel"/);
  assert.match(html, /id="onlineLobbyPanel"/);
  assert.match(js, /lobbyConfigPanel'\)\.classList\.add\('hidden'\)/);
  assert.match(js, /onlineLobbyPanel'\)\.classList\.remove\('hidden'\)/);
});

test('la navegación permite volver al inicio y salir de una sala al lobby de configuración', () => {
  assert.match(html, /id="backHomeButton"/);
  assert.match(html, /id="cancelLobbyButton"/);
  assert.match(js, /showView\('home'\)/);
  assert.match(js, /function returnToLobbyConfig\(\)/);
});

test('las tres pantallas tienen estilos adaptables a celular', () => {
  assert.match(css, /\.home-mode-grid\{grid-template-columns:1fr/);
  assert.match(css, /\.lobby-view \.setup-grid\{grid-template-columns:1fr/);
});
