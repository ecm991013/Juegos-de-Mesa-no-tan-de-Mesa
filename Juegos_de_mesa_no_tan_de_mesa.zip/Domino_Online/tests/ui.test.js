const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..', 'public');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'client.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'styles.css'), 'utf8');
const portalServer = fs.readFileSync(path.join(__dirname, '..', '..', 'server.js'), 'utf8');
const portalHtml = fs.readFileSync(path.join(__dirname, '..', '..', 'public', 'index.html'), 'utf8');

test('Dominó tiene tres pantallas separadas: inicio, lobby y partida', () => {
  assert.match(html, /id="homeView"/);
  assert.match(html, /id="lobbyView"/);
  assert.match(html, /id="gameView"/);
  assert.match(js, /function showView\(view\)/);
});

test('el inicio permite elegir IA, online y misma pantalla antes de abrir el lobby', () => {
  for (const mode of ['ai', 'online', 'local']) {
    assert.match(html, new RegExp(`data-home-mode="${mode}"`));
  }
  assert.match(js, /openLobby\(button\.dataset\.homeMode\)/);
});

test('el lobby contiene configuración y sala de espera online en la misma etapa', () => {
  assert.match(html, /id="lobbyConfigPanel"/);
  assert.match(html, /id="onlineLobbyPanel"/);
  assert.match(js, /lobbyConfigPanel'\)\.classList\.add\('hidden'\)/);
  assert.match(js, /onlineLobbyPanel'\)\.classList\.remove\('hidden'\)/);
});

test('la navegación permite volver al inicio y salir de una sala al lobby de configuración', () => {
  assert.match(html, /id="backHomeButton"/);
  assert.match(html, /id="cancelLobbyButton"/);
  assert.match(js, /showView\('home'\)/);
  assert.match(js, /function returnToLobbyConfig\(\)/);
});

test('las tres pantallas tienen estilos adaptables a celular', () => {
  assert.match(css, /\.home-mode-grid\{grid-template-columns:1fr/);
  assert.match(css, /\.lobby-view \.setup-grid\{grid-template-columns:1fr/);
  assert.match(css, /@media\(max-width:680px\)/);
});

test('Dominó carga su propia hoja de estilos desde la ruta pública del juego', () => {
  assert.match(html, /href="\/domino\/styles\.css"/);
  assert.doesNotMatch(html, /href="\/styles\.css"/);
});

test('el cliente y Socket.IO usan rutas con prefijo /domino para el proxy', () => {
  assert.match(html, /src="\/domino\/socket\.io\/socket\.io\.js"/);
  assert.match(html, /src="\/domino\/client\.js"/);
  assert.match(js, /path:\s*'\/domino\/socket\.io'/);
  assert.match(portalServer, /'\/domino':\s*\{\s*port:\s*3103/);
  assert.match(portalServer, /server\.on\('upgrade'/);
});

test('los botones estáticos principales tienen manejadores de evento', () => {
  const ids = [
    'homeQuickPlayButton', 'homeCustomizeButton', 'homeRulesButton', 'backHomeButton',
    'startButton', 'createRoomButton', 'joinRoomButton', 'copyCodeButton',
    'startOnlineButton', 'cancelLobbyButton', 'leaveGameButton', 'rulesButton',
    'closeRules', 'soundToggle', 'gameSoundToggle', 'handTiles', 'moveControls',
    'drawButton', 'passButton'
  ];
  for (const id of ids) {
    assert.match(js, new RegExp(`\\$\\(['"]${id}['"]\\)\\.addEventListener`), `${id} necesita un manejador`);
  }
});

test('los selectores de modo, avatar, acabado y mesa reaccionan a clics', () => {
  assert.match(js, /querySelectorAll\('\[data-home-mode\]'\)[\s\S]*?addEventListener\('click'/);
  assert.match(js, /querySelectorAll\('\.mode-card'\)[\s\S]*?addEventListener\('click'/);
  assert.match(js, /querySelectorAll\('\.avatar-choice'\)[\s\S]*?addEventListener\('click'/);
  assert.match(js, /querySelectorAll\('\.skin-choice'\)[\s\S]*?addEventListener\('click'/);
  assert.match(js, /querySelectorAll\('\.table-choice'\)[\s\S]*?addEventListener\('click'/);
});

test('crear, entrar, iniciar y jugar emiten acciones por una conexión comprobada', () => {
  assert.match(js, /function emitAction\(eventName, payload\)/);
  for (const action of ['createAI', 'createLocal', 'createOnline', 'joinOnline', 'startOnline', 'playTile', 'drawTile', 'passTurn', 'newRound']) {
    assert.ok(js.includes(`'${action}'`), `falta acción ${action}`);
  }
  assert.match(js, /socket\.connected/);
  assert.match(js, /setConnectionStatus\('offline'/);
});

test('las preferencias no bloquean toda la interfaz si el navegador restringe localStorage', () => {
  assert.match(js, /const readPreference = \(key, fallback\) =>/);
  assert.match(js, /const savePreference = \(key, value\) =>/);
  assert.match(js, /catch \{ \/\* El juego sigue funcionando sin almacenamiento local/);
});

test('el lobby online no permite iniciar hasta que haya al menos dos jugadores', () => {
  assert.match(js, /startOnlineButton'\)\.disabled = !currentIsHost \|\| lobby\.playerCount < 2/);
});

test('el diseño actualizado incluye indicador de conexión y mesa táctil', () => {
  assert.match(html, /id="connectionStatus"/);
  assert.match(css, /\.connection-pill\[data-state="online"\]/);
  assert.match(css, /\.table-surface/);
  assert.match(css, /\.domino-tile\.hand-tile\.selected/);
  assert.match(css, /\.hand-panel/);
});

test('todos los retratos de Dominó y su portada de catálogo existen como recursos locales', () => {
  const assetsDir = path.join(__dirname, '..', 'public', 'assets');
  for (const avatar of ['abuelo-rafa','la-paisa','profe-lee','camila','tomas','dona-clara','santiago','valeria']) {
    assert.ok(fs.existsSync(path.join(assetsDir, 'avatars', `${avatar}.webp`)), `falta el avatar ${avatar}`);
  }
  const portalHtml = fs.readFileSync(path.join(__dirname, '..', '..', 'public', 'index.html'), 'utf8');
  assert.match(portalHtml, /href="\/domino\/"/);
  assert.ok(fs.existsSync(path.join(__dirname, '..', '..', 'public', 'images', 'domino-cover.svg')));
});

test('los recursos de la página se sirven por la ruta del sub-juego y los enlaces de regreso vuelven al catálogo', () => {
  assert.match(html, /href="\/" aria-label="Volver a la biblioteca"/);
  assert.match(html, /href="\/">← Biblioteca/);
  assert.match(html, /src="\/domino\/assets\/avatars\//);
  assert.match(html, /src="\/domino\/socket\.io\/socket\.io\.js"/);
});

test('las fichas de la mano se pueden arrastrar con ratón o pantalla táctil hasta la mesa', () => {
  assert.match(html, /id="chainStage"/);
  assert.match(html, /id="dropGuide"/);
  assert.match(js, /addEventListener\('pointerdown', beginTileDrag\)/);
  assert.match(js, /addEventListener\('pointermove', moveTileDrag/);
  assert.match(js, /addEventListener\('pointerup', finishTileDrag\)/);
  assert.match(js, /emitAction\('playTile', \{ tileId: drag\.id, side: chosenMove\.side \}\)/);
  assert.match(css, /\.chain-stage\.drop-active/);
  assert.match(css, /\.domino-tile\.drag-ghost/);
});

test('la portada de Dominó mantiene su proporción panorámica y el título se dibuja fuera del SVG', () => {
  const cover = fs.readFileSync(path.join(__dirname, '..', '..', 'public', 'images', 'domino-cover.svg'), 'utf8');
  assert.match(cover, /viewBox="0 0 1200 500"/);
  assert.doesNotMatch(cover, /<text[ >]/i);
  assert.match(portalHtml, /<span class="domino-art-title">DOMINÓ <em>CLUB<\/em><\/span>/);
  assert.match(fs.readFileSync(path.join(__dirname, '..', '..', 'public', 'styles.css'), 'utf8'), /\.domino-art-title\{left:50%/);
});
