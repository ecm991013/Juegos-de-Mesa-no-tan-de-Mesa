const test = require('node:test');
const assert = require('node:assert/strict');
const { AVATARS, AI_ROSTER, selectAIOpponents, selectLocalAvatars } = require('../ai-roster');

test('los ocho avatares usan identificadores neutrales, sin nombres visibles', () => {
  assert.equal(AVATARS.length, 8);
  assert.equal(new Set(AVATARS).size, 8);
  assert.ok(AVATARS.every(id => /^avatar-\d{2}$/.test(id)));
});

test('los rivales IA tienen nombres ficticios independientes de los archivos de avatar', () => {
  const names = AI_ROSTER.map(entry => entry.name);
  assert.equal(names.length, 8);
  assert.equal(new Set(names).size, 8);
  assert.deepEqual(names, ['Don Jacinto', 'La Chispa', 'El Zurdo', 'Doña Mula', 'Capitán Doble', 'La Centella', 'Tito Seis', 'La Estratega']);
  assert.ok(AI_ROSTER.every(entry => AVATARS.includes(entry.avatar)));
});

test('los rivales IA reciben avatares y nombres únicos y no reutilizan el retrato humano', () => {
  const opponents = selectAIOpponents(3, 'avatar-01', () => 0);
  assert.equal(opponents.length, 3);
  assert.equal(new Set(opponents.map(entry => entry.name)).size, 3);
  assert.equal(new Set(opponents.map(entry => entry.avatar)).size, 3);
  assert.ok(opponents.every(entry => entry.avatar !== 'avatar-01'));
});

test('en la misma pantalla los retratos de los participantes no se repiten', () => {
  const avatars = ['avatar-01', ...selectLocalAvatars(3, 'avatar-01')];
  assert.equal(avatars.length, 4);
  assert.equal(new Set(avatars).size, 4);
});
