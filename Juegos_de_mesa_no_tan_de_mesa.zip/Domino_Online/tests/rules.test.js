const test = require('node:test');
const assert = require('node:assert/strict');
const Rules = require('../rules');

const defs = count => Array.from({ length: count }, (_, i) => ({ id: `p${i + 1}`, name: `Jugador ${i + 1}` }));

test('el doble-seis contiene exactamente 28 fichas únicas', () => {
  const tiles = Rules.createSet();
  assert.equal(tiles.length, 28);
  assert.equal(new Set(tiles.map(t => `${t.a}-${t.b}`)).size, 28);
  assert.ok(tiles.some(t => t.a === 6 && t.b === 6));
  assert.ok(tiles.some(t => t.a === 0 && t.b === 0));
});

test('reparte siete fichas por jugador y deja el sobrante en el pozo', () => {
  const two = Rules.createGame(defs(2), { playerCount: 2 }, () => 0.4);
  const four = Rules.createGame(defs(4), { playerCount: 4 }, () => 0.4);
  assert.deepEqual(two.players.map(p => p.hand.length), [7, 7]);
  assert.equal(two.boneyard.length, 14);
  assert.equal(four.players.reduce((n, p) => n + p.hand.length, 0), 28);
  assert.equal(four.boneyard.length, 0);
});

test('la salida obliga a colocar la mula más alta disponible', () => {
  const game = Rules.createGame(defs(2), { playerCount: 2 }, () => 0.37);
  const active = game.players[game.turnIndex];
  const forced = active.hand.find(t => t.id === game.openingTileId);
  assert.ok(forced);
  assert.equal(forced.a, forced.b);
  assert.equal(Math.max(...game.players.flatMap(p => p.hand.filter(t => t.a === t.b).map(t => t.a))), forced.a);
  const moves = Rules.legalMoves(game, active.id);
  assert.deepEqual(moves.map(m => m.tileId), [game.openingTileId]);
  assert.equal(moves[0].side, 'center');
});

test('una ficha coincidente puede colocarse a ambos extremos y se orienta correctamente', () => {
  const game = Rules.createGame(defs(2), { playerCount: 2 }, () => 0.21);
  const opener = game.players[game.turnIndex];
  const first = opener.hand.find(t => t.id === game.openingTileId);
  assert.equal(Rules.playTile(game, opener.id, first.id, 'center').ok, true);
  const next = game.players[game.turnIndex];
  game.chain = [{ id: 'left', a: 4, b: 2 }, { id: 'right', a: 5, b: 4 }];
  next.hand = [{ id: 'match', a: 4, b: 6 }];
  const moves = Rules.legalMoves(game, next.id);
  assert.deepEqual(moves.map(m => m.side).sort(), ['left', 'right']);
  assert.equal(Rules.playTile(game, next.id, 'match', 'left').ok, true);
  assert.deepEqual([game.chain[0].a, game.chain[0].b], [6, 4]);
});

test('robar solo es válido cuando no hay jugadas disponibles', () => {
  const game = Rules.createGame(defs(2), { playerCount: 2, ruleMode: 'draw' }, () => 0.47);
  const player = game.players[game.turnIndex];
  game.openingPending = false;
  game.openingTileId = null;
  game.chain = [{ id: 'table', a: 6, b: 6 }];
  player.hand = [{ id: 'not-match', a: 1, b: 2 }];
  const before = game.boneyard.length;
  const result = Rules.drawTile(game, player.id);
  assert.equal(result.ok, true);
  assert.equal(game.boneyard.length, before - 1);
  assert.equal(player.hand.length, 2);
});

test('en modalidad de pasar se puede pasar sin robar y el turno avanza', () => {
  const game = Rules.createGame(defs(2), { playerCount: 2, ruleMode: 'block' }, () => 0.51);
  const player = game.players[game.turnIndex];
  game.openingPending = false;
  game.chain = [{ id: 'table', a: 6, b: 6 }];
  player.hand = [{ id: 'not-match', a: 1, b: 2 }];
  const currentIndex = game.turnIndex;
  const result = Rules.passTurn(game, player.id);
  assert.equal(result.ok, true);
  assert.notEqual(game.turnIndex, currentIndex);
  assert.equal(game.consecutivePasses, 1);
});

test('el cierre por bloqueo se resuelve tras una vuelta completa de pases', () => {
  const game = Rules.createGame(defs(2), { playerCount: 2, ruleMode: 'block' }, () => 0.49);
  game.openingPending = false;
  game.chain = [{ id: 'table', a: 6, b: 6 }];
  game.players.forEach((player, i) => { player.hand = [{ id: `x${i}`, a: i, b: i }]; });
  const firstId = game.players[game.turnIndex].id;
  assert.equal(Rules.passTurn(game, firstId).ok, true);
  const second = game.players[game.turnIndex];
  const result = Rules.passTurn(game, second.id);
  assert.equal(result.ok, true);
  assert.equal(game.roundOver, true);
  assert.equal(game.result.reason, 'blocked');
});

test('en cuatro jugadores se asignan equipos opuestos cuando se activa parejas', () => {
  const game = Rules.createGame(defs(4), { playerCount: 4, teamMode: true }, () => 0.5);
  assert.deepEqual(game.players.map(p => p.team), [0, 1, 0, 1]);
});

test('la IA puede elegir entre las jugadas legales', () => {
  const game = Rules.createGame([{ id: 'ai', name: 'IA', isAI: true, difficulty: 'hard' }, { id: 'p2' }], { playerCount: 2 }, () => 0.5);
  const ai = game.players[game.turnIndex];
  const move = Rules.chooseAIMove(game, ai);
  assert.ok(move);
  assert.ok(Rules.legalMoves(game, ai.id).some(candidate => candidate.tileId === move.tileId && candidate.side === move.side));
});

test('siguiente ronda conserva los marcadores y reparte de nuevo', () => {
  const game = Rules.createGame(defs(2), { playerCount: 2 }, () => 0.5);
  game.roundOver = true;
  game.result = { winnerId: 'p1' };
  game.players[0].score = 45;
  game.players[1].score = 12;
  assert.equal(Rules.nextRound(game, () => 0.5).ok, true);
  assert.equal(game.players[0].score, 45);
  assert.equal(game.players[1].score, 12);
  assert.equal(game.roundNumber, 2);
  assert.equal(game.roundOver, false);
});

test('al alcanzar la meta, nueva partida reinicia los puntos y conserva a los participantes', () => {
  const game = Rules.createGame(defs(2), { playerCount: 2, pointsTarget: 50 }, () => 0.5);
  game.roundOver = true;
  game.matchOver = true;
  game.players[0].score = 60;
  game.players[1].score = 15;
  assert.equal(Rules.nextRound(game, () => 0.5).ok, true);
  assert.deepEqual(game.players.map(player => player.score), [0, 0]);
  assert.equal(game.roundNumber, 1);
  assert.equal(game.matchOver, false);
  assert.equal(game.roundOver, false);
});

test('rechaza una ficha que no coincide con ninguno de los extremos', () => {
  const game = Rules.createGame(defs(2), { playerCount: 2 }, () => 0.5);
  const opener = game.players[game.turnIndex];
  const first = opener.hand.find(t => t.id === game.openingTileId);
  Rules.playTile(game, opener.id, first.id, 'center');
  const next = game.players[game.turnIndex];
  game.openingPending = false;
  game.chain = [{ id: 'table', a: 6, b: 6 }];
  next.hand = [{ id: 'wrong', a: 1, b: 2 }];
  const result = Rules.playTile(game, next.id, 'wrong', 'right');
  assert.equal(result.ok, false);
  assert.match(result.error, /no coincide/i);
  assert.equal(next.hand.length, 1);
});

test('no permite pasar cuando el jugador sí tiene una ficha legal', () => {
  const game = Rules.createGame(defs(2), { playerCount: 2, ruleMode: 'block' }, () => 0.5);
  const player = game.players[game.turnIndex];
  game.openingPending = false;
  game.chain = [{ id: 'table', a: 3, b: 3 }];
  player.hand = [{ id: 'legal', a: 3, b: 5 }];
  const result = Rules.passTurn(game, player.id);
  assert.equal(result.ok, false);
  assert.match(result.error, /puedes jugar/i);
});

test('termina la ronda cuando un jugador coloca su última ficha', () => {
  const game = Rules.createGame(defs(2), { playerCount: 2 }, () => 0.5);
  const player = game.players[game.turnIndex];
  game.openingPending = false;
  game.chain = [{ id: 'table', a: 4, b: 4 }];
  player.hand = [{ id: 'last', a: 4, b: 2 }];
  const result = Rules.playTile(game, player.id, 'last', 'right');
  assert.equal(result.ok, true);
  assert.equal(game.roundOver, true);
  assert.equal(game.result.winnerId, player.id);
  assert.equal(game.result.reason, 'empty');
});


test('la orientación elegida se conserva en la ficha colocada y viaja con el estado de mesa', () => {
  const game = Rules.createGame(defs(2), { playerCount: 2 }, () => 0.37);
  const player = game.players[game.turnIndex];
  const opener = player.hand.find(tile => tile.id === game.openingTileId);
  const result = Rules.playTile(game, player.id, opener.id, 'center', 'vertical');
  assert.equal(result.ok, true);
  assert.equal(game.chain[0].orientation, 'vertical');
  assert.equal(result.played.orientation, 'vertical');
  const next = game.players[game.turnIndex];
  const ends = Rules.getEnds(game.chain);
  next.hand = [{ id: 'next-vertical', a: ends.right, b: 2 }];
  const placed = Rules.playTile(game, next.id, 'next-vertical', 'right', 'vertical');
  assert.equal(placed.ok, true);
  assert.equal(game.chain.at(-1).orientation, 'vertical');
});


test('una ficha colocada puede guardar el giro visual de la cadena hacia abajo o arriba', () => {
  const game = Rules.createGame(defs(2), { playerCount: 2 }, () => 0.37);
  const opener = game.players[game.turnIndex];
  Rules.playTile(game, opener.id, game.openingTileId, 'center');
  const next = game.players[game.turnIndex];
  const matching = game.chain.at(-1).b;
  next.hand = [{ id: 'down-turn', a: matching, b: 4 }];
  const down = Rules.playTile(game, next.id, 'down-turn', 'right', 'horizontal', 'down');
  assert.equal(down.ok, true);
  assert.equal(game.chain.at(-1).flowAfter, 'down');
  assert.equal(down.played.flowAfter, 'down');
});


test('en cierre por bloqueo en parejas se puntúa la diferencia entre los dos equipos', () => {
  const game = {
    options: { teamMode: true, pointsTarget: 100 },
    players: [
      { id: 'a1', team: 0, score: 0, hand: [{ id: 'a1t', a: 1, b: 0 }] },
      { id: 'b1', team: 1, score: 0, hand: [{ id: 'b1t', a: 4, b: 0 }] },
      { id: 'a2', team: 0, score: 0, hand: [{ id: 'a2t', a: 2, b: 0 }] },
      { id: 'b2', team: 1, score: 0, hand: [{ id: 'b2t', a: 3, b: 0 }] }
    ],
    roundOver: false,
    matchOver: false,
    result: null
  };
  const result = Rules.finishRound(game, null, 'blocked');
  assert.equal(result.awarded, 4); // 7 puntos rivales menos 3 del equipo ganador.
  assert.deepEqual(game.players.map(player => player.score), [4, 0, 4, 0]);
});
