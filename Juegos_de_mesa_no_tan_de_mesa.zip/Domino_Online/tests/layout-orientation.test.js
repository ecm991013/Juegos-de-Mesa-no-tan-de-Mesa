const test = require('node:test');
const assert = require('node:assert/strict');
const Layout = require('../layout');
const Rules = require('../rules');

function positions(chain, opening = 'opening', width = 900) {
  return Layout.buildChainLayout(chain, opening, width, { minHeight: 285, centerY: 142 }).positions;
}

test('la fila que vuelve hacia la izquierda invierte visualmente las mitades sin cambiar los valores', () => {
  const chain = [
    { id: 'opening', a: 6, b: 6 },
    { id: 'bend-down', a: 6, b: 5, flowAfter: 'down' },
    { id: 'tile-5-4', a: 5, b: 4 }
  ];
  const layout = positions(chain);
  assert.equal(layout[2].orientation, 'horizontal');
  assert.equal(layout[2].reverseHalves, true);
  assert.deepEqual([chain[2].a, chain[2].b], [5, 4]);
});

test('el orden visual permanece normal en la primera fila que avanza a la derecha', () => {
  const layout = positions([
    { id: 'opening', a: 6, b: 6 },
    { id: 'right-1', a: 6, b: 5 },
    { id: 'right-2', a: 5, b: 4 }
  ]);
  assert.equal(layout[1].reverseHalves, false);
  assert.equal(layout[2].reverseHalves, false);
});

test('la mula de giro vertical hacia abajo conserva a arriba y b abajo', () => {
  const layout = positions([
    { id: 'opening', a: 6, b: 6 },
    { id: 'bend-down', a: 6, b: 5, flowAfter: 'down' },
    { id: 'next', a: 5, b: 4 }
  ]);
  assert.equal(layout[1].orientation, 'vertical');
  assert.equal(layout[1].reverseHalves, false);
});

test('un giro vertical hacia arriba invierte el orden de las mitades', () => {
  const layout = positions([
    { id: 'opening', a: 6, b: 6 },
    { id: 'bend-up', a: 6, b: 5, flowAfter: 'up' },
    { id: 'next', a: 5, b: 4 }
  ]);
  assert.equal(layout[1].orientation, 'vertical');
  assert.equal(layout[1].reverseHalves, true);
});

test('la rama izquierda invierte las mitades cuando el recorrido serpentea', () => {
  const chain = [
    { id: 'left-far', a: 4, b: 5, flowAfter: 'down' },
    { id: 'left-near', a: 5, b: 6 },
    { id: 'opening', a: 6, b: 6 }
  ];
  const layout = positions(chain);
  assert.equal(layout[0].orientation, 'vertical');
  assert.equal(layout[0].reverseHalves, true);
  assert.equal(layout[1].reverseHalves, false);
});

test('al jugar 5-4 contra el extremo 5 conserva 5-4 en la secuencia lógica y lo pinta en el lado correcto', () => {
  const game = Rules.createGame([
    { id: 'p1', name: 'Jugador' },
    { id: 'p2', name: 'Rival' }
  ], { playerCount: 2 }, () => 0.4);
  const first = game.players[game.turnIndex];
  const opening = first.hand.find(tile => tile.id === game.openingTileId);
  assert.equal(Rules.playTile(game, first.id, opening.id, 'center').ok, true);
  game.chain = [
    { id: 'opening', a: 6, b: 6 },
    { id: 'bend', a: 6, b: 5, flowAfter: 'down' }
  ];
  game.openingPending = false;
  const next = game.players[game.turnIndex];
  next.hand = [{ id: 'played-5-4', a: 5, b: 4 }];
  const result = Rules.playTile(game, next.id, 'played-5-4', 'right');
  assert.equal(result.ok, true);
  assert.deepEqual([game.chain.at(-1).a, game.chain.at(-1).b], [5, 4]);
  assert.deepEqual([result.played.a, result.played.b], [5, 4]);
  const layout = positions(game.chain);
  assert.equal(layout.at(-1).reverseHalves, true);
});

test('el giro hacia abajo crea una L continua: entra por arriba de la ficha vertical y sale hacia la fila inferior', () => {
  const chain = [
    { id: 'opening', a: 6, b: 6 },
    { id: 'right-1', a: 6, b: 5 },
    { id: 'right-2', a: 5, b: 4 },
    { id: 'bend-down', a: 4, b: 3, flowAfter: 'down' },
    { id: 'return-1', a: 3, b: 2 },
    { id: 'return-2', a: 2, b: 1 }
  ];
  const layout = Layout.buildChainLayout(chain, 'opening', 900, { minHeight: 285, centerY: 142 });
  const root = layout.positions[0];
  const bend = layout.positions[3];
  const returnTile = layout.positions[4];
  assert.equal(root.x, 450);
  assert.equal(root.y, 142);
  assert.equal(bend.orientation, 'vertical');
  assert.equal(returnTile.orientation, 'horizontal');
  assert.ok(returnTile.y > bend.y, 'la fila de retorno debe quedar debajo del giro');
  assert.ok(returnTile.x < bend.x, 'la fila inferior debe regresar hacia la izquierda');

  const intoBend = layout.connectors.find(item => item.toIndex === 3);
  const outOfBend = layout.connectors.find(item => item.toIndex === 4);
  assert.match(intoBend.path, /L .* L /, 'la entrada al giro debe dibujar un codo');
  assert.match(outOfBend.path, /L .* L /, 'la salida del giro debe dibujar otro codo');
  assert.ok(intoBend.path.startsWith(`M ${layout.positions[2].endX} ${layout.positions[2].endY}`));
  assert.ok(outOfBend.path.startsWith(`M ${bend.endX} ${bend.endY}`));
  assert.ok(intoBend.path.endsWith(`${bend.startX} ${bend.startY}`));
  assert.ok(outOfBend.path.endsWith(`${returnTile.startX} ${returnTile.startY}`));
});

test('el giro hacia arriba crea la fila superior y mantiene conectados los extremos', () => {
  const chain = [
    { id: 'opening', a: 4, b: 4 },
    { id: 'right-1', a: 4, b: 2 },
    { id: 'bend-up', a: 2, b: 1, flowAfter: 'up' },
    { id: 'upper-row', a: 1, b: 5 }
  ];
  const layout = Layout.buildChainLayout(chain, 'opening', 900, { minHeight: 285, centerY: 142 });
  const bend = layout.positions[2];
  const upper = layout.positions[3];
  assert.equal(bend.orientation, 'vertical');
  assert.equal(bend.turnDirection, 'up');
  assert.ok(upper.y < bend.y);
  assert.ok(upper.x < bend.x);
  const connector = layout.connectors.find(item => item.toIndex === 3);
  assert.ok(connector.path.startsWith(`M ${bend.endX} ${bend.endY}`));
  assert.ok(connector.path.endsWith(`${upper.startX} ${upper.startY}`));
});

test('un giro hacia abajo en la rama izquierda también dibuja los dos codos desde el centro', () => {
  const chain = [
    { id: 'outer', a: 1, b: 2 },
    { id: 'bend-left', a: 2, b: 3, flowAfter: 'down' },
    { id: 'near-root', a: 3, b: 6 },
    { id: 'opening', a: 6, b: 6 }
  ];
  const layout = Layout.buildChainLayout(chain, 'opening', 900, { minHeight: 285, centerY: 142 });
  const bend = layout.positions[1];
  const outer = layout.positions[0];
  assert.equal(bend.orientation, 'vertical');
  assert.equal(bend.reverseHalves, true);
  assert.ok(outer.y > bend.y);
  assert.ok(outer.x > bend.x);
  const connector = layout.connectors.find(item => item.toIndex === 1);
  assert.match(connector.path, /L .* L /);
});

test('cada unión de la cadena tiene un conector entre los puertos de sus dos fichas', () => {
  const chain = [
    { id: 'left-far', a: 1, b: 2, flowAfter: 'down' },
    { id: 'left-near', a: 2, b: 3 },
    { id: 'opening', a: 3, b: 3 },
    { id: 'right-one', a: 3, b: 4 },
    { id: 'right-bend', a: 4, b: 5, flowAfter: 'down' },
    { id: 'right-return', a: 5, b: 6 }
  ];
  const layout = Layout.buildChainLayout(chain, 'opening', 900, { minHeight: 285, centerY: 142 });
  assert.equal(layout.connectors.length, chain.length - 1);
  for (const connector of layout.connectors) {
    const from = layout.positions[connector.fromIndex];
    const to = layout.positions[connector.toIndex];
    assert.ok(connector.path.startsWith(`M ${connector.from.x} ${connector.from.y}`));
    assert.ok(connector.path.endsWith(`${connector.to.x} ${connector.to.y}`));
    assert.ok(Number.isFinite(from.x) && Number.isFinite(to.x));
  }
});

test('la distribución serpenteante mantiene la apertura centrada también en móvil', () => {
  const chain = [
    { id: 'opening', a: 6, b: 6 },
    { id: 'a', a: 6, b: 5 },
    { id: 'b', a: 5, b: 4, flowAfter: 'down' },
    { id: 'c', a: 4, b: 3 },
    { id: 'd', a: 3, b: 2, flowAfter: 'down' },
    { id: 'e', a: 2, b: 1 }
  ];
  const layout = Layout.buildChainLayout(chain, 'opening', 390, { minHeight: 220, centerY: 110 });
  assert.equal(layout.root.x, 195);
  assert.equal(layout.root.y, 110);
  assert.equal(layout.connectors.length, chain.length - 1);
  assert.ok(layout.positions.every(position => Number.isFinite(position.x) && Number.isFinite(position.y)));
});
