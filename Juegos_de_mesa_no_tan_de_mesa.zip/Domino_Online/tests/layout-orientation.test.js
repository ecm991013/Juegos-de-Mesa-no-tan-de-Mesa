const test = require('node:test');
const assert = require('node:assert/strict');
const Layout = require('../layout');
const Rules = require('../rules');

function positions(chain, opening = 'opening', width = 900) {
  return Layout.buildChainLayout(chain, opening, width, { minHeight: 285, centerY: 142 }).positions;
}

test('la fila que vuelve hacia la izquierda invierte visualmente las mitades sin cambiar los valores', () => {
  const chain = [
    { id: 'opening', a: 6, b: 6 },
    { id: 'bend-down', a: 6, b: 5, flowAfter: 'down' },
    { id: 'tile-5-4', a: 5, b: 4 }
  ];
  const layout = positions(chain);
  assert.equal(layout[2].orientation, 'horizontal');
  assert.equal(layout[2].reverseHalves, true);
  assert.deepEqual([chain[2].a, chain[2].b], [5, 4]);
});

test('el orden visual permanece normal en la primera fila que avanza a la derecha', () => {
  const layout = positions([
    { id: 'opening', a: 6, b: 6 },
    { id: 'right-1', a: 6, b: 5 },
    { id: 'right-2', a: 5, b: 4 }
  ]);
  assert.equal(layout[1].reverseHalves, false);
  assert.equal(layout[2].reverseHalves, false);
});

test('la mula de giro vertical hacia abajo conserva a arriba y b abajo', () => {
  const layout = positions([
    { id: 'opening', a: 6, b: 6 },
    { id: 'bend-down', a: 6, b: 5, flowAfter: 'down' },
    { id: 'next', a: 5, b: 4 }
  ]);
  assert.equal(layout[1].orientation, 'vertical');
  assert.equal(layout[1].reverseHalves, false);
});

test('un giro vertical hacia arriba invierte el orden de las mitades', () => {
  const layout = positions([
    { id: 'opening', a: 6, b: 6 },
    { id: 'bend-up', a: 6, b: 5, flowAfter: 'up' },
    { id: 'next', a: 5, b: 4 }
  ]);
  assert.equal(layout[1].orientation, 'vertical');
  assert.equal(layout[1].reverseHalves, true);
});

test('la rama izquierda invierte las mitades cuando el recorrido serpentea', () => {
  const chain = [
    { id: 'left-far', a: 4, b: 5, flowAfter: 'down' },
    { id: 'left-near', a: 5, b: 6 },
    { id: 'opening', a: 6, b: 6 }
  ];
  const layout = positions(chain);
  assert.equal(layout[0].orientation, 'vertical');
  assert.equal(layout[0].reverseHalves, true);
  assert.equal(layout[1].reverseHalves, false);
});

test('al jugar 5-4 contra el extremo 5 conserva 5-4 en la secuencia lógica y lo pinta en el lado correcto', () => {
  const game = Rules.createGame([
    { id: 'p1', name: 'Jugador' },
    { id: 'p2', name: 'Rival' }
  ], { playerCount: 2 }, () => 0.4);
  const first = game.players[game.turnIndex];
  const opening = first.hand.find(tile => tile.id === game.openingTileId);
  assert.equal(Rules.playTile(game, first.id, opening.id, 'center').ok, true);
  game.chain = [
    { id: 'opening', a: 6, b: 6 },
    { id: 'bend', a: 6, b: 5, flowAfter: 'down' }
  ];
  game.openingPending = false;
  const next = game.players[game.turnIndex];
  next.hand = [{ id: 'played-5-4', a: 5, b: 4 }];
  const result = Rules.playTile(game, next.id, 'played-5-4', 'right');
  assert.equal(result.ok, true);
  assert.deepEqual([game.chain.at(-1).a, game.chain.at(-1).b], [5, 4]);
  assert.deepEqual([result.played.a, result.played.b], [5, 4]);
  const layout = positions(game.chain);
  assert.equal(layout.at(-1).reverseHalves, true);
});
