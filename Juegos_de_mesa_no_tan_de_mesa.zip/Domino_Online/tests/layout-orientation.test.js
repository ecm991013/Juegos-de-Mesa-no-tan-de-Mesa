const test = require('node:test');
const assert = require('node:assert/strict');
const Layout = require('../layout');
const Rules = require('../rules');

function layoutFor(chain, opening = 'opening', width = 900) {
  return Layout.buildChainLayout(chain, opening, width, { minHeight: 285, centerY: 142 });
}

test('la ficha que ordena bajar permanece horizontal y la siguiente cae bajo su mitad abierta', () => {
  const chain = [
    { id: 'opening', a: 6, b: 6 },
    { id: 'approach', a: 6, b: 5 },
    { id: 'down-source', a: 5, b: 4, flowAfter: 'down' },
    { id: 'down-tile', a: 4, b: 3 },
    { id: 'return', a: 3, b: 2 }
  ];
  const result = layoutFor(chain);
  const source = result.positions[2];
  const downTile = result.positions[3];
  const returnTile = result.positions[4];

  assert.equal(source.orientation, 'horizontal');
  assert.equal(source.turnDirection, 'down');
  assert.equal(downTile.orientation, 'vertical');
  assert.equal(downTile.x, source.endX, 'la ficha vertical queda justo bajo la mitad abierta');
  assert.ok(downTile.y > source.y);
  assert.equal(returnTile.orientation, 'horizontal');
  assert.ok(returnTile.y > downTile.y, 'la fila de retorno queda debajo de la ficha vertical');
  assert.ok(returnTile.x < downTile.x, 'la fila inferior vuelve en sentido contrario');
});

test('la ficha que ordena subir permanece horizontal y la siguiente cae sobre su mitad abierta', () => {
  const chain = [
    { id: 'opening', a: 6, b: 6 },
    { id: 'approach', a: 6, b: 5 },
    { id: 'up-source', a: 5, b: 4, flowAfter: 'up' },
    { id: 'up-tile', a: 4, b: 3 },
    { id: 'return', a: 3, b: 2 }
  ];
  const result = layoutFor(chain);
  const source = result.positions[2];
  const upTile = result.positions[3];
  assert.equal(source.orientation, 'horizontal');
  assert.equal(upTile.orientation, 'vertical');
  assert.equal(upTile.x, source.endX);
  assert.ok(upTile.y < source.y);
  assert.equal(result.positions[4].orientation, 'horizontal');
  assert.ok(result.positions[4].y < upTile.y);
});

test('en la rama izquierda la ficha descendente queda bajo la mitad izquierda de la ficha fuente', () => {
  const chain = [
    { id: 'down-tile', a: 2, b: 1 },
    { id: 'down-source', a: 3, b: 2, flowAfter: 'down' },
    { id: 'near-left', a: 6, b: 3 },
    { id: 'opening', a: 6, b: 6 }
  ];
  const result = layoutFor(chain);
  const source = result.positions[1];
  const downTile = result.positions[0];
  assert.equal(source.orientation, 'horizontal');
  assert.equal(source.turnDirection, 'down');
  assert.equal(downTile.orientation, 'vertical');
  assert.equal(downTile.x, source.x - result.tileLong / 4);
  assert.equal(downTile.x, source.endX);
  assert.ok(downTile.y > source.y);
});

test('si la ficha fuente ya está vertical, la siguiente queda directamente bajo su punta', () => {
  const chain = [
    { id: 'opening', a: 6, b: 6 },
    { id: 'source', a: 6, b: 5, flowAfter: 'down' },
    { id: 'vertical-source', a: 5, b: 4, flowAfter: 'down' },
    { id: 'under-tip', a: 4, b: 3 }
  ];
  const result = layoutFor(chain);
  const verticalSource = result.positions[2];
  const underTip = result.positions[3];
  assert.equal(verticalSource.orientation, 'vertical');
  assert.equal(verticalSource.turnDirection, 'down');
  assert.equal(underTip.orientation, 'vertical');
  assert.equal(underTip.x, verticalSource.endX);
  assert.ok(underTip.y > verticalSource.endY);
});

test('la ficha inicial permanece en el centro aunque ambos extremos tengan giros', () => {
  const result = layoutFor([
    { id: 'left-far', a: 1, b: 2, flowAfter: 'down' },
    { id: 'left-near', a: 2, b: 3 },
    { id: 'opening', a: 3, b: 3 },
    { id: 'right-near', a: 3, b: 4, flowAfter: 'up' },
    { id: 'right-far', a: 4, b: 5 }
  ]);
  assert.equal(result.root.x, 450);
  assert.ok(result.root.y >= 142, 'la apertura se desplaza solo lo necesario para que el brazo superior no salga del tablero');
  assert.equal(result.connectors.length, 4);
  assert.ok(result.positions.every(item => Number.isFinite(item.x) && Number.isFinite(item.y)));
});

test('la conexión de la ficha que baja nace en el borde inferior de la mitad abierta', () => {
  const result = layoutFor([
    { id: 'opening', a: 6, b: 6 },
    { id: 'source', a: 6, b: 5, flowAfter: 'down' },
    { id: 'turn', a: 5, b: 4 }
  ]);
  const source = result.positions[1];
  const turn = result.positions[2];
  const connector = result.connectors.find(item => item.toIndex === 2);
  assert.equal(connector.from.x, source.x + result.tileLong / 4);
  assert.equal(connector.from.y, source.y + result.tileShort / 2);
  assert.equal(connector.to.x, turn.x);
  assert.equal(connector.to.y, turn.y - result.tileLong / 2);
  assert.equal(connector.from.x, connector.to.x);
  assert.ok(connector.to.y > connector.from.y);
});

test('el giro automático también coloca la ficha siguiente bajo la mitad abierta', () => {
  const longChain = [
    { id: 'opening', a: 6, b: 6 },
    ...Array.from({ length: 16 }, (_, index) => ({ id: `tile-${index}`, a: index % 7, b: (index + 1) % 7 }))
  ];
  const result = Layout.buildChainLayout(longChain, 'opening', 420, { minHeight: 285, centerY: 142 });
  const autoTurnIndex = result.positions.findIndex(item => item.automaticTurn);
  assert.ok(autoTurnIndex >= 0);
  const source = result.positions[autoTurnIndex];
  const next = result.positions[autoTurnIndex + 1];
  assert.equal(next.orientation, 'vertical');
  assert.equal(next.x, source.endX);
  assert.ok(next.y > source.y);
  assert.ok(result.height > 285);
});

test('un doble cruzando el recorrido conserva sus dimensiones y los puertos de conexión', () => {
  const result = layoutFor([
    { id: 'opening', a: 6, b: 5 },
    { id: 'double', a: 5, b: 5 },
    { id: 'next', a: 5, b: 3 }
  ]);
  const double = result.positions[1];
  assert.equal(double.orientation, 'vertical');
  assert.equal(double.isDouble, true);
  const incoming = result.connectors.find(item => item.toIndex === 1);
  assert.equal(incoming.to.x, double.x - result.tileShort / 2);
  assert.equal(incoming.to.y, double.y);
});

test('los valores de las fichas no cambian por los giros ni por el lado de la mesa', () => {
  const chain = [
    { id: 'opening', a: 6, b: 6 },
    { id: 'source', a: 6, b: 4, flowAfter: 'down' },
    { id: 'turn', a: 4, b: 2 },
    { id: 'lower', a: 2, b: 1 }
  ];
  const before = chain.map(tile => [tile.a, tile.b]);
  layoutFor(chain);
  assert.deepEqual(chain.map(tile => [tile.a, tile.b]), before);
});

test('la regla de colocación sigue validando los valores aunque el diseño baje o suba', () => {
  const game = Rules.createGame([
    { id: 'p1', name: 'Jugador' },
    { id: 'p2', name: 'Rival' }
  ], { playerCount: 2 }, () => 0.4);
  const player = game.players[game.turnIndex];
  const opening = player.hand.find(tile => tile.id === game.openingTileId);
  assert.ok(opening);
  assert.equal(Rules.playTile(game, player.id, opening.id, 'center').ok, true);
  const nextPlayer = game.players[game.turnIndex];
  const valid = nextPlayer.hand.find(tile => tile.a === game.chain[0].a || tile.b === game.chain[0].a);
  if (valid) {
    const attempt = Rules.playTile(game, nextPlayer.id, valid.id, 'right', undefined, 'down');
    assert.equal(attempt.ok, true);
    assert.equal(game.chain.at(-1).flowAfter, 'down');
  }
});


test('un doble que ordena bajar deja espacio bajo su borde antes de colocar la siguiente ficha', () => {
  const chain = [
    { id: 'opening', a: 6, b: 6 },
    { id: 'approach', a: 6, b: 5 },
    { id: 'double-source', a: 5, b: 5, flowAfter: 'down' },
    { id: 'down-tile', a: 5, b: 4 },
    { id: 'return', a: 4, b: 2 }
  ];
  const result = layoutFor(chain, 'opening', 390);
  const source = result.positions[2];
  const downTile = result.positions[3];
  const sourceBottom = source.y + result.tileLong / 2;
  const downTileTop = downTile.y - (downTile.orientation === 'vertical' ? result.tileLong : result.tileShort) / 2;
  assert.ok(downTileTop >= sourceBottom + 7, 'la ficha que baja no debe montarse sobre el doble transversal');
  const connector = result.connectors.find(item => item.toIndex === 3);
  assert.equal(connector.from.x, connector.to.x);
  assert.ok(connector.to.y > connector.from.y);
});

test('las fichas consecutivas de un tramo vertical no regresan sobre la ficha anterior', () => {
  const result = layoutFor([
    { id: 'opening', a: 6, b: 6 },
    { id: 'source', a: 6, b: 5, flowAfter: 'down' },
    { id: 'vertical-1', a: 5, b: 4, flowAfter: 'down' },
    { id: 'vertical-2', a: 4, b: 3 },
    { id: 'return', a: 3, b: 2 }
  ]);
  const first = result.positions[2];
  const second = result.positions[3];
  assert.ok(second.y > first.y, 'el tramo vertical continúa hacia su punta inferior');
  assert.ok(result.positions[4].y > second.y, 'la fila de retorno queda debajo del tramo vertical');
});


test('después de bajar se puede continuar hacia la derecha sin invertir la fila hacia la izquierda', () => {
  const result = layoutFor([
    { id: 'opening', a: 6, b: 6 },
    { id: 'approach', a: 6, b: 5 },
    { id: 'down-source', a: 5, b: 4, flowAfter: 'down' },
    { id: 'down-tile', a: 4, b: 3, flowAfter: 'right' },
    { id: 'right-tile', a: 3, b: 2 },
    { id: 'right-next', a: 2, b: 1 }
  ]);
  const source = result.positions[2];
  const downTile = result.positions[3];
  const rightTile = result.positions[4];
  assert.equal(downTile.travelX, 0);
  assert.equal(downTile.travelY, 1);
  assert.equal(downTile.x, source.endX, 'la ficha que baja queda bajo el punto de giro');
  assert.equal(downTile.turnDirection, 'right');
  assert.equal(rightTile.travelX, 1);
  assert.equal(rightTile.travelY, 0);
  assert.ok(rightTile.x > downTile.x, 'la continuación elegida a la derecha no debe volver a la izquierda');
  assert.equal(rightTile.y, downTile.endY, 'la ficha horizontal sale desde la mitad abierta inferior');
  assert.ok(result.positions[5].x > rightTile.x, 'las fichas siguientes conservan el sentido derecho');
});

test('desde un tramo vertical también se puede elegir continuar a la izquierda', () => {
  const result = layoutFor([
    { id: 'opening', a: 6, b: 6 },
    { id: 'approach', a: 6, b: 5 },
    { id: 'down-source', a: 5, b: 4, flowAfter: 'down' },
    { id: 'down-tile', a: 4, b: 3, flowAfter: 'left' },
    { id: 'left-tile', a: 3, b: 2 }
  ]);
  const downTile = result.positions[3];
  const leftTile = result.positions[4];
  assert.equal(downTile.turnDirection, 'left');
  assert.equal(leftTile.travelX, -1);
  assert.ok(leftTile.x < downTile.x, 'la salida izquierda se respeta de forma explícita');
  assert.equal(leftTile.y, downTile.endY);
});

test('una instrucción derecha se conserva en el estado visual de la ficha jugada', () => {
  const game = Rules.createGame([
    { id: 'p1', name: 'Jugador' },
    { id: 'p2', name: 'Rival' }
  ], { playerCount: 2 }, () => 0.42);
  game.openingPending = false;
  game.openingTileId = null;
  game.chain = [
    { id: 'opening', a: 6, b: 6 },
    { id: 'source', a: 6, b: 5 },
    { id: 'down', a: 5, b: 4, flowAfter: 'down' }
  ];
  game.turnIndex = 0;
  game.players[0].hand = [{ id: 'right-piece', a: 4, b: 2 }];
  const played = Rules.playTile(game, game.players[0].id, 'right-piece', 'right', 'horizontal', 'right');
  assert.equal(played.ok, true);
  assert.equal(game.chain.at(-1).flowAfter, 'right');
  assert.equal(played.played.flowAfter, 'right');
});

test('una secuencia larga con giros repetidos no coloca fichas superpuestas en un mismo brazo', () => {
  let seed = 91273;
  const random = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
  for (let sample = 0; sample < 120; sample++) {
    const count = 8 + Math.floor(random() * 24);
    const chain = [{ id: 'opening', a: 6, b: 6 }];
    for (let index = 1; index < count; index++) {
      chain.push({
        id: `tile-${index}`,
        a: Math.floor(random() * 7),
        b: Math.floor(random() * 7),
        flowAfter: random() < 0.18 ? (random() < 0.5 ? 'down' : 'up') : 'straight'
      });
    }
    const result = Layout.buildChainLayout(chain, 'opening', 320 + Math.floor(random() * 420), { minHeight: 285, centerY: 142 });
    for (let i = 0; i < result.positions.length; i++) {
      for (let j = i + 1; j < result.positions.length; j++) {
        const a = result.positions[i], b = result.positions[j];
        const aw = a.orientation === 'horizontal' ? result.tileLong : result.tileShort;
        const ah = a.orientation === 'horizontal' ? result.tileShort : result.tileLong;
        const bw = b.orientation === 'horizontal' ? result.tileLong : result.tileShort;
        const bh = b.orientation === 'horizontal' ? result.tileShort : result.tileLong;
        const overlapX = (aw + bw) / 2 - Math.abs(a.x - b.x);
        const overlapY = (ah + bh) / 2 - Math.abs(a.y - b.y);
        assert.ok(!(overlapX > 0.5 && overlapY > 0.5), `fichas ${i} y ${j} se superponen en la muestra ${sample}`);
      }
    }
  }
});
