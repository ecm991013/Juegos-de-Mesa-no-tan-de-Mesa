const test = require('node:test');
const assert = require('node:assert/strict');
const { THINKING_RANGES, getAIThinkingDelay } = require('../ai-timing');

test('la IA tiene pausas de varios segundos y el nivel difícil piensa más', () => {
  assert.deepEqual(getAIThinkingDelay('easy', () => 0), 3600);
  assert.deepEqual(getAIThinkingDelay('easy', () => 1), 4400);
  assert.deepEqual(getAIThinkingDelay('normal', () => 0), 4200);
  assert.deepEqual(getAIThinkingDelay('hard', () => 1), 5600);
  assert.ok(THINKING_RANGES.hard[0] > THINKING_RANGES.easy[0]);
});

test('una dificultad desconocida usa el tiempo normal y el aleatorio queda acotado', () => {
  assert.equal(getAIThinkingDelay('unknown', () => 0.5), 4600);
  assert.equal(getAIThinkingDelay('hard', () => -100), 4800);
  assert.ok(getAIThinkingDelay('hard', () => 100) <= 5600);
});
