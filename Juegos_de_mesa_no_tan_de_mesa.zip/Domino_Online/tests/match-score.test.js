const test = require('node:test');
const assert = require('node:assert/strict');
const Scoreboard = require('../match-score');

test('el marcador individual ordena jugadores por puntos y calcula la meta', () => {
  const board = Scoreboard.buildStandings({
    options: { pointsTarget: 100, teamMode: false },
    players: [
      { id: 'p1', name: 'Ana', score: 42, avatar: 'avatar-01' },
      { id: 'p2', name: 'Luis', score: 77, avatar: 'avatar-02' },
      { id: 'p3', name: 'IA', score: 77, avatar: 'avatar-03', isAI: true }
    ]
  });
  assert.equal(board.target, 100);
  assert.deepEqual(board.rows.map(row => row.score), [77, 77, 42]);
  assert.equal(board.leaders.length, 2);
  assert.equal(board.topScore, 77);
  assert.equal(board.rows[0].label, 'IA'.localeCompare('Luis', 'es') < 0 ? 'IA' : 'Luis');
});

test('el marcador por parejas no duplica la puntuación compartida por los compañeros', () => {
  const board = Scoreboard.buildStandings({
    options: { pointsTarget: 150, teamMode: true },
    players: [
      { id: 'a', name: 'Ana', team: 0, score: 60, avatar: 'avatar-01' },
      { id: 'b', name: 'Luis', team: 1, score: 45, avatar: 'avatar-02' },
      { id: 'c', name: 'Marta', team: 0, score: 60, avatar: 'avatar-03' },
      { id: 'd', name: 'Pablo', team: 1, score: 45, avatar: 'avatar-04' }
    ]
  });
  assert.equal(board.rows.length, 2);
  assert.equal(board.rows.find(row => row.team === 0).score, 60);
  assert.deepEqual(board.rows.find(row => row.team === 0).members.map(member => member.name), ['Ana', 'Marta']);
  assert.equal(board.rows[0].score, 60);
});

test('el marcador soporta jugadores sin puntuación o metas válidas ausentes', () => {
  const board = Scoreboard.buildStandings({ players: [{ id: 'p', name: 'Jugador' }] });
  assert.equal(board.target, 100);
  assert.equal(board.rows[0].score, 0);
  assert.equal(board.leaders.length, 1);
});
