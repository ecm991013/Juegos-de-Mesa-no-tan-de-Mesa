const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const publicDir = path.join(__dirname, '..', 'public');
const html = fs.readFileSync(path.join(publicDir, 'index.html'), 'utf8');
const client = fs.readFileSync(path.join(publicDir, 'client.js'), 'utf8');

class ClassList {
  constructor(owner) { this.owner = owner; this.values = new Set(); }
  add(...tokens) { tokens.forEach(token => this.values.add(token)); }
  remove(...tokens) { tokens.forEach(token => this.values.delete(token)); }
  contains(token) { return this.values.has(token); }
  toggle(token, force) {
    const shouldAdd = force === undefined ? !this.values.has(token) : !!force;
    if (shouldAdd) this.values.add(token); else this.values.delete(token);
    return shouldAdd;
  }
}

class Element {
  constructor(id = '') {
    this.id = id;
    this.dataset = {};
    this.listeners = {};
    this.classList = new ClassList(this);
    this.attributes = {};
    this.style = {};
    this.value = '';
    this.checked = false;
    this.disabled = false;
    this.textContent = '';
    this.innerHTML = '';
    this.title = '';
  }
  addEventListener(type, callback) { (this.listeners[type] ||= []).push(callback); }
  dispatch(type, event = {}) { for (const callback of this.listeners[type] || []) callback(event); }
  appendChild(child) { (this.children ||= []).push(child); return child; }
  cloneNode() { const clone = new Element(`${this.id}-clone`); clone.className = this.className; clone.dataset = { ...this.dataset }; return clone; }
  removeAttribute(name) { delete this.attributes[name]; }
  remove() { this.removed = true; }
  getBoundingClientRect() { return this.rect || { left: 100, top: 100, right: 500, bottom: 400, width: 400, height: 300 }; }
  setAttribute(name, value) { this.attributes[name] = String(value); }
  querySelector(selector) {
    if (selector === 'span') return this._span ||= new Element(`${this.id}-span`);
    return null;
  }
  set className(value) {
    this._className = value;
    this.classList.values = new Set(String(value).split(/\s+/).filter(Boolean));
  }
  get className() { return this._className || [...this.classList.values].join(' '); }
  click(target = this) {
    for (const callback of this.listeners.click || []) callback({ target, preventDefault() {} });
  }
}

function createHarness() {
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
  const elements = new Map(ids.map(id => [id, new Element(id)]));
  for (const match of html.matchAll(/<[^>]*\bid="([^"]+)"[^>]*\bclass="([^"]+)"[^>]*>/g)) {
    const element = elements.get(match[1]);
    if (element) element.className = match[2];
  }
  const groups = {
    '[data-home-mode]': ['ai', 'online', 'local'].map(mode => { const el = new Element(`home-${mode}`); el.dataset.homeMode = mode; return el; }),
    '.mode-card': ['ai', 'online', 'local'].map(mode => { const el = new Element(`mode-${mode}`); el.dataset.mode = mode; return el; }),
    '.avatar-choice': ['abuelo-rafa','la-paisa','profe-lee','camila','tomas','dona-clara','santiago','valeria'].map(avatar => { const el = new Element(`avatar-${avatar}`); el.dataset.avatar = avatar; return el; }),
    '.skin-choice': ['classic','wood','obsidian','marble','gold','neon','ocean','caribe'].map(skin => { const el = new Element(`skin-${skin}`); el.dataset.skin = skin; return el; }),
    '.table-choice': ['green','purple','blue','red','wood'].map(table => { const el = new Element(`table-${table}`); el.dataset.table = table; return el; }),
    '.move-button': ['left','right','center'].map(side => { const el = new Element(`move-${side}`); el.dataset.side = side; return el; })
  };
  elements.get('playerName').value = 'Jugador de prueba';
  elements.get('playerCount').value = '4';
  elements.get('difficulty').value = 'normal';
  elements.get('pointsTarget').value = '100';
  elements.get('ruleMode').value = 'draw';
  elements.get('roomCodeInput').value = '';

  const listeners = {};
  const mockSocket = {
    connected: true,
    on(event, callback) { (listeners[event] ||= []).push(callback); if (event === 'connect') callback(); return this; },
    trigger(event, payload) { (listeners[event] || []).forEach(callback => callback(payload)); },
    emit(event, payload) {
      events.push({ event, payload });
      if (event === 'createAI' || event === 'createLocal') {
        this.trigger('joined', { code: 'TEST01', mode: event === 'createAI' ? 'ai' : 'local', playerId: 'human-1' });
        const players = [
          { id:'human-1', name:payload.name, avatar:payload.avatar, isAI:false, connected:true, handCount:2, score:0, team:0 },
          { id:'ai-1', name:'El Gallo', avatar:'abuelo-rafa', isAI:true, difficulty:payload.difficulty, connected:true, handCount:7, score:0, team:1 }
        ];
        const game = {
          code:'TEST01', mode:event === 'createAI' ? 'ai' : 'local', options:{ruleMode:payload.ruleMode}, settings:payload,
          players, chain:[], boneyardCount:4, turnPlayerId:'human-1', turnPlayerName:payload.name,
          turnNumber:1, roundNumber:1, openingPending:true, openingTileId:'tile-1',
          legalMoves:[{tileId:'tile-1',side:'center'}], result:null, roundOver:false, matchOver:false,
          you:'human-1', hand:[{id:'tile-1',a:6,b:6},{id:'tile-2',a:1,b:4}], isYourTurn:true,
          localHotseat:event === 'createLocal'
        };
        this.trigger('gameState', game);
      }
      if (event === 'createOnline') {
        this.trigger('joined', { code:'ABC123', mode:'online', playerId:'host-1' });
        this.trigger('lobbyState', { code:'ABC123', mode:'online', hostId:'host-1', hostName:payload.name, started:false, playerCount:1, maxPlayers:payload.playerCount, settings:payload, players:[{id:'host-1',name:payload.name,avatar:payload.avatar,connected:true}] });
      }
      if (event === 'joinOnline') this.trigger('notice', {message:'No encontramos esa sala.',kind:'error'});
    }
  };
  const events = [];
  const documentListeners = {};
  const document = {
    body: new Element('body'),
    getElementById: id => elements.get(id) || null,
    querySelectorAll: selector => groups[selector] || [],
    querySelector: () => null,
    addEventListener(type, callback) { (documentListeners[type] ||= []).push(callback); }
  };
  const localStore = new Map();
  const context = {
    document,
    window: {
      io: () => mockSocket,
      scrollTo() {},
      AudioContext: null,
      webkitAudioContext: null
    },
    navigator: { clipboard: { writeText: async () => {} } },
    localStorage: {
      getItem: key => localStore.has(key) ? localStore.get(key) : null,
      setItem: (key, value) => localStore.set(key, String(value))
    },
    console,
    setTimeout: () => 1,
    clearTimeout() {},
    Math,
    String,
    Number,
    Array,
    JSON
  };
  vm.runInNewContext(client, context, { filename: 'Domino_Online/public/client.js' });
  return { elements, groups, mockSocket, events, documentListeners };
}

test('el cliente se inicia y conecta sin errores con los elementos del DOM', () => {
  const h = createHarness();
  assert.equal(h.elements.get('homeView').classList.contains('hidden'), false);
  assert.equal(h.elements.get('lobbyView').classList.contains('hidden'), true);
  assert.equal(h.elements.get('connectionStatus').dataset.state, 'online');
});

test('los botones del inicio y el lobby navegan y permiten personalizar avatar, fichas y mesa', () => {
  const h = createHarness();
  h.groups['[data-home-mode]'][0].click();
  assert.equal(h.elements.get('lobbyView').classList.contains('hidden'), false);
  h.groups['.avatar-choice'][1].click();
  assert.equal(h.groups['.avatar-choice'][1].classList.contains('selected'), true);
  h.groups['.skin-choice'][1].click();
  assert.equal(h.groups['.skin-choice'][1].classList.contains('selected'), true);
  h.groups['.table-choice'][1].click();
  assert.equal(h.elements.get('gameTable').className, 'table-surface table-purple');
  h.elements.get('backHomeButton').click();
  assert.equal(h.elements.get('homeView').classList.contains('hidden'), false);
});

test('el botón de empezar crea una partida IA y muestra la mesa', () => {
  const h = createHarness();
  h.elements.get('homeQuickPlayButton').click();
  h.elements.get('startButton').click();
  assert.ok(h.events.some(event => event.event === 'createAI'));
  assert.equal(h.elements.get('gameView').classList.contains('hidden'), false);
  assert.match(h.elements.get('handTiles').innerHTML, /data-hand-id=/);
});

test('seleccionar una ficha y un extremo emite la jugada al servidor', () => {
  const h = createHarness();
  h.elements.get('homeQuickPlayButton').click();
  h.elements.get('startButton').click();
  const target = { closest: selector => selector === '[data-hand-id]' ? { dataset:{handId:'tile-1'}, disabled:false } : null };
  h.elements.get('handTiles').click(target);
  assert.equal(h.elements.get('moveControls').classList.contains('hidden'), false);
  const moveTarget = { closest: selector => selector === '[data-side]' ? {dataset:{side:'center'}} : null };
  h.elements.get('moveControls').click(moveTarget);
  assert.ok(h.events.some(event => event.event === 'playTile' && event.payload.side === 'center'));
});

test('el lobby online crea una sala y permite volver a la configuración', () => {
  const h = createHarness();
  h.groups['[data-home-mode]'][1].click();
  h.elements.get('createRoomButton').click();
  assert.ok(h.events.some(event => event.event === 'createOnline'));
  assert.equal(h.elements.get('onlineLobbyPanel').classList.contains('hidden'), false);
  assert.equal(h.elements.get('lobbyCode').textContent, 'ABC123');
  h.elements.get('cancelLobbyButton').click();
  assert.equal(h.elements.get('lobbyConfigPanel').classList.contains('hidden'), false);
});

test('si Socket.IO está desconectado, las acciones de juego muestran aviso en vez de fallar silenciosamente', () => {
  const h = createHarness();
  h.mockSocket.connected = false;
  h.elements.get('homeQuickPlayButton').click();
  h.elements.get('startButton').click();
  assert.equal(h.events.length, 0);
  assert.match(h.elements.get('toast').textContent, /Conectando con la mesa/);
});


test('arrastrar una ficha de la mano al tablero envía la jugada al extremo correcto', () => {
  const h = createHarness();
  h.elements.get('homeQuickPlayButton').click();
  h.elements.get('startButton').click();
  const tileButton = new Element('drag-tile');
  tileButton.dataset.handId = 'tile-1';
  tileButton.disabled = false;
  tileButton.closest = selector => selector === '[data-hand-id]' ? tileButton : null;
  h.elements.get('handTiles').dispatch('pointerdown', {
    target: tileButton, pointerId: 7, button: 0, clientX: 130, clientY: 140
  });
  for (const callback of h.documentListeners.pointermove || []) callback({
    pointerId: 7, clientX: 280, clientY: 220, preventDefault() {}
  });
  for (const callback of h.documentListeners.pointerup || []) callback({
    pointerId: 7, clientX: 280, clientY: 220, preventDefault() {}
  });
  assert.ok(h.events.some(event => event.event === 'playTile' && event.payload.tileId === 'tile-1' && event.payload.side === 'center'));
});
