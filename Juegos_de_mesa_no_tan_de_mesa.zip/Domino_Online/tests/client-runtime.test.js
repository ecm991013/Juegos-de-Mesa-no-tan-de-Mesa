const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const publicDir = path.join(__dirname, '..', 'public');
const html = fs.readFileSync(path.join(publicDir, 'index.html'), 'utf8');
const client = fs.readFileSync(path.join(publicDir, 'client.js'), 'utf8');
const layoutClient = fs.readFileSync(path.join(publicDir, 'layout.js'), 'utf8');
const publicStyles = fs.readFileSync(path.join(publicDir, 'styles.css'), 'utf8');
const DominoLayout = require('../layout');

class ClassList {
  constructor(owner) { this.owner = owner; this.values = new Set(); }
  add(...tokens) { tokens.forEach(token => this.values.add(token)); }
  remove(...tokens) { tokens.forEach(token => this.values.delete(token)); }
  contains(token) { return this.values.has(token); }
  toggle(token, force) {
    const shouldAdd = force === undefined ? !this.values.has(token) : !!force;
    if (shouldAdd) this.values.add(token); else this.values.delete(token);
    return shouldAdd;
  }
}

class Element {
  constructor(id = '') {
    this.id = id;
    this.dataset = {};
    this.listeners = {};
    this.classList = new ClassList(this);
    this.attributes = {};
    this.style = {};
    this.value = '';
    this.checked = false;
    this.disabled = false;
    this.textContent = '';
    this.innerHTML = '';
    this.title = '';
  }
  addEventListener(type, callback) { (this.listeners[type] ||= []).push(callback); }
  dispatch(type, event = {}) { for (const callback of this.listeners[type] || []) callback(event); }
  appendChild(child) { (this.children ||= []).push(child); return child; }
  cloneNode() { const clone = new Element(`${this.id}-clone`); clone.className = this.className; clone.dataset = { ...this.dataset }; return clone; }
  removeAttribute(name) { delete this.attributes[name]; }
  remove() { this.removed = true; }
  getBoundingClientRect() { return this.rect || { left: 100, top: 100, right: 500, bottom: 400, width: 400, height: 300 }; }
  setAttribute(name, value) { this.attributes[name] = String(value); }
  querySelector(selector) {
    if (selector === 'span') return this._span ||= new Element(`${this.id}-span`);
    return null;
  }
  set className(value) {
    this._className = value;
    this.classList.values = new Set(String(value).split(/\s+/).filter(Boolean));
  }
  get className() { return this._className || [...this.classList.values].join(' '); }
  click(target = this) {
    for (const callback of this.listeners.click || []) callback({ target, preventDefault() {} });
  }
}

function createHarness() {
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
  const elements = new Map(ids.map(id => [id, new Element(id)]));
  for (const match of html.matchAll(/<[^>]*\bid="([^"]+)"[^>]*\bclass="([^"]+)"[^>]*>/g)) {
    const element = elements.get(match[1]);
    if (element) element.className = match[2];
  }
  const groups = {
    '[data-home-mode]': ['ai', 'online', 'local'].map(mode => { const el = new Element(`home-${mode}`); el.dataset.homeMode = mode; return el; }),
    '.mode-card': ['ai', 'online', 'local'].map(mode => { const el = new Element(`mode-${mode}`); el.dataset.mode = mode; return el; }),
    '.avatar-choice': ['avatar-01','avatar-02','avatar-03','avatar-04','avatar-05','avatar-06','avatar-07','avatar-08'].map(avatar => { const el = new Element(`avatar-${avatar}`); el.dataset.avatar = avatar; return el; }),
    '.skin-choice': ['classic','wood','obsidian','marble','gold','neon','ocean','caribe'].map(skin => { const el = new Element(`skin-${skin}`); el.dataset.skin = skin; return el; }),
    '.table-choice': ['green','purple','blue','red','wood'].map(table => { const el = new Element(`table-${table}`); el.dataset.table = table; return el; }),
    '.move-button': ['left','right','center'].map(side => { const el = new Element(`move-${side}`); el.dataset.side = side; return el; })
  };
  elements.get('playerName').value = 'Jugador de prueba';
  elements.get('playerCount').value = '4';
  elements.get('difficulty').value = 'normal';
  elements.get('pointsTarget').value = '100';
  elements.get('ruleMode').value = 'draw';
  elements.get('roomCodeInput').value = '';

  const listeners = {};
  const mockSocket = {
    connected: true,
    on(event, callback) { (listeners[event] ||= []).push(callback); if (event === 'connect') callback(); return this; },
    trigger(event, payload) { (listeners[event] || []).forEach(callback => callback(payload)); },
    emit(event, payload) {
      events.push({ event, payload });
      if (event === 'createAI' || event === 'createLocal') {
        this.trigger('joined', { code: 'TEST01', mode: event === 'createAI' ? 'ai' : 'local', playerId: 'human-1' });
        const players = [
          { id:'human-1', name:payload.name, avatar:payload.avatar, isAI:false, connected:true, handCount:2, score:0, team:0 },
          { id:'ai-1', name:'Don Jacinto', avatar:'avatar-01', isAI:true, difficulty:payload.difficulty, connected:true, handCount:7, score:0, team:1 }
        ];
        const game = {
          code:'TEST01', mode:event === 'createAI' ? 'ai' : 'local', options:{ruleMode:payload.ruleMode}, settings:payload,
          players, chain:[], boneyardCount:4, turnPlayerId:'human-1', turnPlayerName:payload.name,
          turnNumber:1, roundNumber:1, openingPending:true, openingTileId:'tile-1',
          legalMoves:[{tileId:'tile-1',side:'center'}], result:null, roundOver:false, matchOver:false,
          you:'human-1', hand:[{id:'tile-1',a:6,b:6},{id:'tile-2',a:1,b:4}], isYourTurn:true,
          localHotseat:event === 'createLocal'
        };
        this.trigger('gameState', game);
      }
      if (event === 'createOnline') {
        this.trigger('joined', { code:'ABC123', mode:'online', playerId:'host-1' });
        this.trigger('lobbyState', { code:'ABC123', mode:'online', hostId:'host-1', hostName:payload.name, started:false, playerCount:1, maxPlayers:payload.playerCount, settings:payload, players:[{id:'host-1',name:payload.name,avatar:payload.avatar,connected:true}] });
      }
      if (event === 'joinOnline') this.trigger('notice', {message:'No encontramos esa sala.',kind:'error'});
    }
  };
  const events = [];
  const documentListeners = {};
  const document = {
    body: new Element('body'),
    getElementById: id => elements.get(id) || null,
    querySelectorAll: selector => groups[selector] || [],
    querySelector: () => null,
    addEventListener(type, callback) { (documentListeners[type] ||= []).push(callback); }
  };
  const localStore = new Map();
  const context = {
    document,
    window: {
      io: () => mockSocket,
      innerWidth: 1024,
      scrollTo() {},
      AudioContext: null,
      webkitAudioContext: null
    },
    navigator: { clipboard: { writeText: async () => {} } },
    localStorage: {
      getItem: key => localStore.has(key) ? localStore.get(key) : null,
      setItem: (key, value) => localStore.set(key, String(value))
    },
    console,
    setTimeout: () => 1,
    clearTimeout() {},
    Math,
    String,
    Number,
    Array,
    JSON
  };
  // Ejecuta primero el mismo layout.js que sirve Express al navegador.
  // No inyectamos el módulo de Node: así una ruta pública rota sí hace fallar la prueba.
  vm.runInNewContext(layoutClient, context, { filename: 'Domino_Online/public/layout.js' });
  vm.runInNewContext(client, context, { filename: 'Domino_Online/public/client.js' });
  return { elements, groups, mockSocket, events, documentListeners, document };
}

test('el cliente se inicia y conecta sin errores con los elementos del DOM', () => {
  const h = createHarness();
  assert.equal(h.elements.get('homeView').classList.contains('hidden'), false);
  assert.equal(h.elements.get('lobbyView').classList.contains('hidden'), true);
  assert.equal(h.elements.get('connectionStatus').dataset.state, 'online');
});

test('los botones del inicio y el lobby navegan y permiten personalizar avatar, fichas y mesa', () => {
  const h = createHarness();
  h.groups['[data-home-mode]'][0].click();
  assert.equal(h.elements.get('lobbyView').classList.contains('hidden'), false);
  h.groups['.avatar-choice'][1].click();
  assert.equal(h.groups['.avatar-choice'][1].classList.contains('selected'), true);
  h.groups['.skin-choice'][1].click();
  assert.equal(h.groups['.skin-choice'][1].classList.contains('selected'), true);
  h.groups['.table-choice'][1].click();
  assert.equal(h.elements.get('gameTable').className, 'table-surface table-purple');
  h.elements.get('backHomeButton').click();
  assert.equal(h.elements.get('homeView').classList.contains('hidden'), false);
});

test('el botón de empezar crea una partida IA y muestra la mesa', () => {
  const h = createHarness();
  h.elements.get('homeQuickPlayButton').click();
  h.elements.get('startButton').click();
  assert.ok(h.events.some(event => event.event === 'createAI'));
  assert.equal(h.elements.get('gameView').classList.contains('hidden'), false);
  assert.match(h.elements.get('handTiles').innerHTML, /data-hand-id=/);
});

test('seleccionar una ficha y un extremo emite la jugada al servidor', () => {
  const h = createHarness();
  h.elements.get('homeQuickPlayButton').click();
  h.elements.get('startButton').click();
  const target = { closest: selector => selector === '[data-hand-id]' ? { dataset:{handId:'tile-1'}, disabled:false } : null };
  h.elements.get('handTiles').click(target);
  assert.equal(h.elements.get('moveControls').classList.contains('hidden'), false);
  const moveTarget = { closest: selector => selector === '[data-side]' ? {dataset:{side:'center'}} : null };
  h.elements.get('moveControls').click(moveTarget);
  assert.ok(h.events.some(event => event.event === 'playTile' && event.payload.side === 'center'));
});

test('el lobby online crea una sala y permite volver a la configuración', () => {
  const h = createHarness();
  h.groups['[data-home-mode]'][1].click();
  h.elements.get('createRoomButton').click();
  assert.ok(h.events.some(event => event.event === 'createOnline'));
  assert.equal(h.elements.get('onlineLobbyPanel').classList.contains('hidden'), false);
  assert.equal(h.elements.get('lobbyCode').textContent, 'ABC123');
  h.elements.get('cancelLobbyButton').click();
  assert.equal(h.elements.get('lobbyConfigPanel').classList.contains('hidden'), false);
});

test('si Socket.IO está desconectado, las acciones de juego muestran aviso en vez de fallar silenciosamente', () => {
  const h = createHarness();
  h.mockSocket.connected = false;
  h.elements.get('homeQuickPlayButton').click();
  h.elements.get('startButton').click();
  assert.equal(h.events.length, 0);
  assert.match(h.elements.get('toast').textContent, /Conectando con la mesa/);
});


test('arrastrar una ficha de la mano al tablero envía la jugada al extremo correcto', () => {
  const h = createHarness();
  h.elements.get('homeQuickPlayButton').click();
  h.elements.get('startButton').click();
  const tileButton = new Element('drag-tile');
  tileButton.dataset.handId = 'tile-1';
  tileButton.disabled = false;
  tileButton.closest = selector => selector === '[data-hand-id]' ? tileButton : null;
  h.elements.get('handTiles').dispatch('pointerdown', {
    target: tileButton, pointerId: 7, button: 0, clientX: 130, clientY: 140
  });
  for (const callback of h.documentListeners.pointermove || []) callback({
    pointerId: 7, clientX: 280, clientY: 220, preventDefault() {}
  });
  for (const callback of h.documentListeners.pointerup || []) callback({
    pointerId: 7, clientX: 280, clientY: 220, preventDefault() {}
  });
  assert.ok(h.events.some(event => event.event === 'playTile' && event.payload.tileId === 'tile-1' && event.payload.side === 'center'));
});


test('al elegir acabado de fichas o color de mesa la vista previa se actualiza en vivo', () => {
  const h = createHarness();
  assert.match(h.elements.get('customPreviewTiles').innerHTML, /preview-6-3/);
  h.groups['.skin-choice'].find(button => button.dataset.skin === 'gold').click();
  assert.match(h.elements.get('customPreview').className, /skin-gold/);
  assert.match(h.elements.get('previewSkinName').textContent, /Oro/);
  h.groups['.table-choice'].find(button => button.dataset.table === 'purple').click();
  assert.match(h.elements.get('customPreviewTable').className, /table-purple/);
  assert.equal(h.elements.get('previewTableName').textContent, 'Violeta');
  assert.match(h.elements.get('customPreviewTiles').innerHTML, /domino-tile/);
});

test('la ficha inicial queda centrada y las dos ramas crecen a izquierda y derecha', () => {
  const layout = DominoLayout.buildChainLayout([
    { id: 'left-1', a: 2, b: 4 },
    { id: 'opening', a: 6, b: 6 },
    { id: 'right-1', a: 6, b: 3 }
  ], 'opening', 900, { minHeight: 285, centerY: 142 });
  assert.equal(layout.rootIndex, 1);
  assert.equal(layout.root.x, 450);
  assert.equal(layout.positions[0].x < layout.root.x, true);
  assert.equal(layout.positions[2].x > layout.root.x, true);
});

test('una ficha puede marcar un giro manual hacia abajo o arriba en cualquier punto de la rama', () => {
  const down = DominoLayout.buildChainLayout([
    { id: 'opening', a: 6, b: 6 },
    { id: 'turn', a: 6, b: 2, flowAfter: 'down' },
    { id: 'next', a: 2, b: 4 }
  ], 'opening', 900, { minHeight: 285, centerY: 142 });
  assert.equal(down.positions[1].orientation, 'vertical');
  assert.equal(down.positions[1].turnDirection, 'down');
  assert.ok(down.positions[2].y > down.positions[1].y);

  const up = DominoLayout.buildChainLayout([
    { id: 'opening', a: 6, b: 6 },
    { id: 'turn', a: 6, b: 2, flowAfter: 'up' },
    { id: 'next', a: 2, b: 4 }
  ], 'opening', 900, { minHeight: 285, centerY: 142 });
  assert.equal(up.positions[1].turnDirection, 'up');
  assert.ok(up.positions[2].y < up.positions[1].y);
});

test('un giro hacia abajo funciona también en la rama izquierda sin mover la ficha inicial', () => {
  const layout = DominoLayout.buildChainLayout([
    { id: 'further-left', a: 4, b: 1 },
    { id: 'left-turn', a: 5, b: 4, flowAfter: 'down' },
    { id: 'near-left', a: 6, b: 5 },
    { id: 'opening', a: 6, b: 6 }
  ], 'opening', 900, { minHeight: 285, centerY: 142 });
  assert.equal(layout.root.x, 450);
  assert.equal(layout.positions[1].orientation, 'vertical');
  assert.equal(layout.positions[1].turnDirection, 'down');
  assert.ok(layout.positions[0].y > layout.positions[1].y);
});

test('la rama dobla automáticamente al alcanzar el borde disponible', () => {
  const longChain = [{ id: 'opening', a: 6, b: 6 }, ...Array.from({ length: 14 }, (_, index) => ({ id: `tile-${index}`, a: index % 7, b: (index + 1) % 7 }))];
  const layout = DominoLayout.buildChainLayout(longChain, 'opening', 420, { minHeight: 285, centerY: 142 });
  assert.ok(layout.positions.some(position => position.turnsAfter && position.turnDirection === 'down'));
  assert.ok(layout.height > 285);
});

test('al arrastrar una ficha hacia la mesa se elige el extremo visual más cercano', () => {
  const h = createHarness();
  h.mockSocket.trigger('gameState', {
    code: 'TEST01', mode: 'ai', options: { ruleMode: 'draw' },
    players: [{ id: 'human-1', name: 'Jugador', avatar: 'avatar-01', isAI: false, connected: true, handCount: 2, score: 0 }],
    chain: [{ id: 'chain-0', a: 6, b: 4 }, { id: 'chain-1', a: 4, b: 2 }],
    boneyardCount: 0, turnPlayerId: 'human-1', turnPlayerName: 'Jugador', turnNumber: 2,
    roundNumber: 1, openingPending: false, openingTileId: null, legalMoves: [{ tileId: 'tile-1', side: 'right' }], result: null,
    roundOver: false, matchOver: false, you: 'human-1', hand: [{ id: 'tile-1', a: 2, b: 5 }], isYourTurn: true, localHotseat: false
  });
  h.elements.get('chainStage').rect = { left: 100, right: 500, top: 100, bottom: 400, width: 400, height: 300 };
  h.elements.get('handTiles').rect = { left: 100, right: 500, top: 500, bottom: 680, width: 400, height: 180 };
  const endpoints = {
    '#dominoChain [data-chain-index="0"]': new Element('chain-first'),
    '#dominoChain [data-chain-index="1"]': new Element('chain-last')
  };
  endpoints['#dominoChain [data-chain-index="0"]'].rect = { left: 110, right: 150, top: 120, bottom: 180, width: 40, height: 60 };
  endpoints['#dominoChain [data-chain-index="1"]'].rect = { left: 430, right: 470, top: 120, bottom: 180, width: 40, height: 60 };
  h.document.querySelector = selector => endpoints[selector] || null;
  const handTile = new Element('drag-tile');
  handTile.dataset.handId = 'tile-1';
  handTile.disabled = false;
  handTile.closest = selector => selector === '[data-hand-id]' ? handTile : null;
  h.elements.get('handTiles').dispatch('pointerdown', { target: handTile, pointerId: 11, button: 0, clientX: 160, clientY: 210 });
  for (const callback of h.documentListeners.pointermove || []) callback({ pointerId: 11, clientX: 450, clientY: 150, preventDefault() {} });
  for (const callback of h.documentListeners.pointerup || []) callback({ pointerId: 11, clientX: 450, clientY: 150, preventDefault() {} });
  const play = h.events.find(event => event.event === 'playTile');
  assert.equal(play.payload.side, 'right');
  assert.equal(play.payload.flowAfter, 'straight');
});

test('al soltar debajo de un extremo la ficha marca el giro hacia abajo', () => {
  const h = createHarness();
  h.mockSocket.trigger('gameState', {
    code: 'TEST01', mode: 'ai', options: { ruleMode: 'draw' },
    players: [{ id: 'human-1', name: 'Jugador', avatar: 'avatar-01', isAI: false, connected: true, handCount: 2, score: 0 }],
    chain: [{ id: 'opening', a: 6, b: 6 }],
    boneyardCount: 0, turnPlayerId: 'human-1', turnPlayerName: 'Jugador', turnNumber: 2,
    roundNumber: 1, openingPending: false, openingTileId: 'opening', legalMoves: [{ tileId: 'tile-1', side: 'right' }], result: null,
    roundOver: false, matchOver: false, you: 'human-1', hand: [{ id: 'tile-1', a: 6, b: 3 }], isYourTurn: true, localHotseat: false
  });
  const endpoint = new Element('chain-opening');
  endpoint.rect = { left: 480, right: 558, top: 220, bottom: 262, width: 78, height: 42 };
  h.document.querySelector = selector => selector.includes('data-chain-index="0"') ? endpoint : null;
  h.elements.get('chainStage').rect = { left: 100, right: 1000, top: 100, bottom: 500, width: 900, height: 400 };
  h.elements.get('handTiles').rect = { left: 100, right: 1000, top: 520, bottom: 700, width: 900, height: 180 };
  const handTile = new Element('drag-tile');
  handTile.dataset.handId = 'tile-1'; handTile.disabled = false;
  handTile.closest = selector => selector === '[data-hand-id]' ? handTile : null;
  h.elements.get('handTiles').dispatch('pointerdown', { target: handTile, pointerId: 12, button: 0, clientX: 200, clientY: 600 });
  for (const callback of h.documentListeners.pointermove || []) callback({ pointerId: 12, clientX: 620, clientY: 320, preventDefault() {} });
  for (const callback of h.documentListeners.pointerup || []) callback({ pointerId: 12, clientX: 620, clientY: 320, preventDefault() {} });
  const play = h.events.find(event => event.event === 'playTile');
  assert.equal(play.payload.side, 'right');
  assert.equal(play.payload.flowAfter, 'down');
});

test('el jugador puede ordenar su mano arrastrando una ficha sobre otra', () => {
  const h = createHarness();
  h.elements.get('homeQuickPlayButton').click();
  h.elements.get('startButton').click();
  const hand = h.elements.get('handTiles');
  hand.rect = { left: 100, right: 500, top: 500, bottom: 680, width: 400, height: 180 };
  h.elements.get('chainStage').rect = { left: 600, right: 1000, top: 100, bottom: 400, width: 400, height: 300 };
  const source = new Element('source'); source.dataset.handId = 'tile-1'; source.disabled = false;
  source.closest = selector => selector === '[data-hand-id]' ? source : null;
  const target = new Element('target'); target.dataset.handId = 'tile-2';
  target.rect = { left: 200, right: 250, top: 540, bottom: 620, width: 50, height: 80 };
  target.classList.add('domino-tile');
  target.closest = selector => selector === '[data-hand-id]' ? target : selector === '#handTiles' ? hand : null;
  h.document.elementFromPoint = () => target;
  hand.dispatch('pointerdown', { target: source, pointerId: 13, button: 0, clientX: 350, clientY: 600 });
  for (const callback of h.documentListeners.pointermove || []) callback({ pointerId: 13, clientX: 205, clientY: 580, preventDefault() {} });
  for (const callback of h.documentListeners.pointerup || []) callback({ pointerId: 13, clientX: 205, clientY: 580, preventDefault() {} });
  const markup = hand.innerHTML;
  assert.ok(markup.indexOf('data-hand-id="tile-1"') < markup.indexOf('data-hand-id="tile-2"'));
});

test('las fichas de la mano no revelan cuáles son legales: todas siguen seleccionables en el turno', () => {
  const h = createHarness();
  h.elements.get('homeQuickPlayButton').click();
  h.elements.get('startButton').click();
  const html = h.elements.get('handTiles').innerHTML;
  assert.match(html, /data-hand-id="tile-1"/);
  assert.match(html, /data-hand-id="tile-2"/);
  assert.doesNotMatch(html, /data-hand-id="tile-2"[^>]*disabled/);
  assert.doesNotMatch(html, /data-hand-id="tile-2"[^>]*legal/);
});

test('el jugador puede intentar una ficha no sugerida y el servidor recibe el intento para validarlo', () => {
  const h = createHarness();
  h.elements.get('homeQuickPlayButton').click();
  h.elements.get('startButton').click();
  const tile = { dataset: { handId: 'tile-2' }, disabled: false };
  const clickTarget = { closest: selector => selector === '[data-hand-id]' ? tile : null };
  h.elements.get('handTiles').click(clickTarget);
  const right = { closest: selector => selector === '[data-side]' ? { dataset: { side: 'right' } } : null };
  h.elements.get('moveControls').click(right);
  const attempt = h.events.find(event => event.event === 'playTile');
  assert.equal(attempt.payload.tileId, 'tile-2');
  assert.equal(attempt.payload.side, 'right');
  assert.equal(Object.hasOwn(attempt.payload, 'orientation'), false);
});


test('al llegar un gameState con fichas en la cadena, el cliente dibuja las fichas en la mesa', () => {
  const h = createHarness();
  h.mockSocket.trigger('gameState', {
    code: 'TEST02', mode: 'ai', options: { ruleMode: 'draw' },
    players: [{ id:'human-1', name:'Jugador', avatar:'avatar-01', isAI:false, connected:true, handCount:2, score:0 }],
    chain: [
      { id:'opening', a:6, b:6, flowAfter:'straight' },
      { id:'played-2', a:6, b:3, flowAfter:'straight' },
      { id:'played-3', a:3, b:1, flowAfter:'down' }
    ],
    boneyardCount: 14, turnPlayerId:'human-1', turnPlayerName:'Jugador', turnNumber:3,
    roundNumber:1, openingPending:false, openingTileId:'opening',
    legalMoves:[{tileId:'tile-1',side:'right'}], result:null, roundOver:false, matchOver:false,
    you:'human-1', hand:[{id:'tile-1',a:1,b:4},{id:'tile-2',a:0,b:2}], isYourTurn:true, localHotseat:false
  });
  const board = h.elements.get('dominoChain').innerHTML;
  assert.match(board, /data-chain-index="0"/);
  assert.match(board, /data-chain-index="1"/);
  assert.match(board, /data-chain-index="2"/);
  assert.match(board, /opening-tile/);
  assert.match(board, /chain-connectors/);
});


test('la ficha 5-4 conectada al 5 se refleja visualmente en la fila de retorno', () => {
  const h = createHarness();
  h.mockSocket.trigger('gameState', {
    code: 'ORIENT1', mode: 'ai', options: { ruleMode: 'draw' },
    players: [{ id:'human-1', name:'Jugador', avatar:'avatar-01', isAI:false, connected:true, handCount:1, score:0 }],
    chain: [
      { id:'opening', a:6, b:6 },
      { id:'bend', a:6, b:5, flowAfter:'down' },
      { id:'five-four', a:5, b:4 }
    ],
    boneyardCount:0, turnPlayerId:'human-1', turnPlayerName:'Jugador', turnNumber:4,
    roundNumber:1, openingPending:false, openingTileId:'opening',
    legalMoves:[], result:null, roundOver:false, matchOver:false,
    you:'human-1', hand:[{id:'in-hand',a:1,b:2}], isYourTurn:true, localHotseat:false
  });
  const board = h.elements.get('dominoChain').innerHTML;
  const playedTile = board.match(/<div class="domino-tile horizontal[^>]*data-tile-id="five-four"[^>]*>/);
  assert.ok(playedTile, 'la ficha 5-4 debe renderizarse en la mesa');
  assert.match(playedTile[0], /reverse-halves/, 'la mitad 5 debe quedar en el lado que conecta con la ficha anterior');
  assert.match(publicStyles, /\.domino-tile\.reverse-halves\.horizontal \.tile-half:first-child\{grid-column:2/);
  assert.match(publicStyles, /\.domino-tile\.reverse-halves\.horizontal \.tile-half:last-child\{grid-column:1/);
});
