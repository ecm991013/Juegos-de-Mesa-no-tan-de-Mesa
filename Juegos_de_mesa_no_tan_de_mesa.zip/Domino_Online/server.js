'use strict';

const http = require('node:http');
const crypto = require('node:crypto');
const path = require('node:path');
const express = require('express');
const { Server } = require('socket.io');
const Rules = require('./rules');
const { getAIThinkingDelay } = require('./ai-timing');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true, credentials: true },
  transports: ['websocket', 'polling'],
  pingInterval: 25000,
  pingTimeout: 60000,
  connectionStateRecovery: { maxDisconnectionDuration: 120000, skipMiddlewares: true }
});
const PORT = Number(process.env.PORT || 3103);
const ROOT = __dirname;
const AVATARS = ['abuelo-rafa', 'la-paisa', 'profe-lee', 'camila', 'tomas', 'dona-clara', 'santiago', 'valeria'];
const AI_NAMES = [
  { name: 'El Gallo', avatar: 'abuelo-rafa' },
  { name: 'La Paisa', avatar: 'la-paisa' },
  { name: 'Profe Lee', avatar: 'profe-lee' },
  { name: 'Camila', avatar: 'camila' },
  { name: 'Tomás', avatar: 'tomas' },
  { name: 'Doña Clara', avatar: 'dona-clara' },
  { name: 'Santiago', avatar: 'santiago' },
  { name: 'Valeria', avatar: 'valeria' }
];
const rooms = new Map();
const socketRooms = new Map();
const aiTimers = new Map();

app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(ROOT, 'public')));
app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'Domino Club', rooms: rooms.size }));
app.get('/api/ping', (_req, res) => res.json({ ok: true, app: 'Domino Club' }));

const uid = prefix => `${prefix || 'p'}-${crypto.randomUUID()}`;
const cleanName = value => String(value || 'Jugador').trim().replace(/[<>]/g, '').slice(0, 20) || 'Jugador';
const cleanAvatar = value => AVATARS.includes(value) ? value : AVATARS[0];
const validDifficulty = value => ['easy', 'normal', 'hard'].includes(value) ? value : 'normal';
const clone = value => JSON.parse(JSON.stringify(value));
const pickAI = (used = new Set()) => {
  const available = AI_NAMES.filter(item => !used.has(item.name));
  return available[Math.floor(Math.random() * available.length)] || AI_NAMES[Math.floor(Math.random() * AI_NAMES.length)];
};

function newCode() {
  let code;
  do { code = crypto.randomBytes(3).toString('hex').toUpperCase(); } while (rooms.has(code));
  return code;
}

function playerFromSocket(socket, data = {}) {
  return {
    id: uid('player'), socketId: socket.id,
    name: cleanName(data.name), avatar: cleanAvatar(data.avatar),
    isAI: false, difficulty: 'normal', connected: true
  };
}

function publicLobby(room) {
  return {
    code: room.code,
    mode: room.mode,
    hostId: room.hostId,
    hostName: room.players[0]?.name || 'Anfitrión',
    started: !!room.game,
    playerCount: room.players.length,
    maxPlayers: room.maxPlayers,
    settings: room.settings,
    players: room.players.map(p => ({ id: p.id, name: p.name, avatar: p.avatar, connected: p.connected !== false }))
  };
}

function publicGame(room) {
  const game = room.game;
  const current = game.players[game.turnIndex];
  return {
    code: room.code,
    mode: room.mode,
    settings: room.settings,
    options: game.options,
    players: game.players.map(p => ({
      id: p.id, name: p.name, avatar: p.avatar, isAI: !!p.isAI,
      difficulty: p.isAI ? p.difficulty : null,
      connected: p.connected !== false,
      handCount: p.hand.length,
      score: p.score,
      team: p.team
    })),
    chain: clone(game.chain),
    boneyardCount: game.boneyard.length,
    turnPlayerId: current?.id || null,
    turnPlayerName: current?.name || '—',
    turnNumber: game.turnNumber,
    roundNumber: game.roundNumber,
    aiThinking: !!room.aiThinking,
    aiThinkingDelay: room.aiThinkingDelay || 0,
    openingPending: game.openingPending,
    openingTileId: game.openingTileId,
    legalMoves: Rules.legalMoves(game, current?.id || ''),
    result: game.result,
    roundOver: game.roundOver,
    matchOver: game.matchOver
  };
}

function emitNotice(socket, message, kind = 'info') {
  socket.emit('notice', { message, kind });
}

function emitLobby(room) {
  io.to(room.code).emit('lobbyState', publicLobby(room));
}

function emitGameState(room) {
  if (!room.game) return;
  const state = publicGame(room);
  if (room.mode === 'local') {
    const active = room.game.players[room.game.turnIndex];
    const socketId = room.controllerSocketId;
    if (socketId) io.to(socketId).emit('gameState', { ...state, you: active?.id, hand: clone(active?.hand || []), isYourTurn: true, localHotseat: true });
    return;
  }
  for (const player of room.game.players) {
    if (!player.socketId || !player.connected) continue;
    io.to(player.socketId).emit('gameState', {
      ...state,
      you: player.id,
      hand: clone(player.hand),
      isYourTurn: room.game.players[room.game.turnIndex]?.id === player.id,
      localHotseat: false
    });
  }
}

function stopAITimer(room) {
  const timer = aiTimers.get(room.code);
  if (timer) clearTimeout(timer);
  aiTimers.delete(room.code);
  room.aiThinking = false;
  room.aiThinkingDelay = 0;
}

function chooseSideForMove(game, move) {
  if (move.side === 'center') return 'center';
  const ends = Rules.getEnds(game.chain);
  const tile = game.players[game.turnIndex].hand.find(item => item.id === move.tileId);
  if (!tile) return move.side;
  const matching = move.side === 'left' ? ends.left : ends.right;
  return tile.a === matching || tile.b === matching ? move.side : move.side;
}

function runAITurn(room) {
  if (!room.game || room.game.roundOver) return;
  room.aiThinking = false;
  room.aiThinkingDelay = 0;
  const game = room.game;
  const player = game.players[game.turnIndex];
  if (!player?.isAI) return;
  const moves = Rules.legalMoves(game, player.id);
  if (moves.length) {
    const move = Rules.chooseAIMove(game, player);
    if (move) Rules.playTile(game, player.id, move.tileId, chooseSideForMove(game, move));
  } else if (game.options.ruleMode === 'draw' && game.boneyard.length) {
    let drawCount = 0;
    while (!Rules.legalMoves(game, player.id).length && game.boneyard.length && drawCount < 28) {
      Rules.drawTile(game, player.id);
      drawCount++;
    }
    const afterDrawMoves = Rules.legalMoves(game, player.id);
    if (afterDrawMoves.length) {
      const move = Rules.chooseAIMove(game, player);
      if (move) Rules.playTile(game, player.id, move.tileId, chooseSideForMove(game, move));
    } else {
      Rules.passTurn(game, player.id);
    }
  } else {
    Rules.passTurn(game, player.id);
  }
  emitGameState(room);
  scheduleAI(room);
}

function scheduleAI(room) {
  stopAITimer(room);
  if (!room.game || room.game.roundOver) return;
  const player = room.game.players[room.game.turnIndex];
  if (!player?.isAI) return;
  const delay = getAIThinkingDelay(player.difficulty);
  room.aiThinking = true;
  room.aiThinkingDelay = delay;
  // Enviar un estado inmediato para mostrar que la IA está pensando durante la pausa.
  emitGameState(room);
  aiTimers.set(room.code, setTimeout(() => runAITurn(room), delay));
}

function createStartedRoom(socket, mode, settings, definitions) {
  const code = newCode();
  const room = {
    code, mode, settings,
    maxPlayers: definitions.length,
    hostId: definitions[0].id,
    hostSocketId: socket.id,
    controllerSocketId: mode === 'local' ? socket.id : null,
    players: definitions,
    game: null
  };
  room.game = Rules.createGame(definitions, settings);
  rooms.set(code, room);
  socket.join(code);
  socketRooms.set(socket.id, code);
  socket.emit('joined', { code, mode, playerId: definitions[0].id });
  emitGameState(room);
  scheduleAI(room);
  return room;
}

function startOnlineRoom(room) {
  if (room.game) return { ok: false, error: 'La partida ya comenzó.' };
  if (room.players.length < 2) return { ok: false, error: 'Necesitan entrar al menos dos jugadores.' };
  const definitions = room.players.map(p => ({ ...p, connected: p.connected !== false }));
  room.settings = Rules.normalizeSettings({ ...room.settings, playerCount: definitions.length });
  room.maxPlayers = definitions.length;
  room.game = Rules.createGame(definitions, room.settings);
  emitLobby(room);
  emitGameState(room);
  scheduleAI(room);
  return { ok: true };
}

function getSocketPlayer(room, socket) {
  if (!room) return null;
  if (room.mode === 'local') return room.game?.players[room.game.turnIndex] || null;
  return room.players.find(p => p.socketId === socket.id) || null;
}

function handleHumanAction(socket, eventName, handler) {
  const code = socketRooms.get(socket.id);
  const room = code ? rooms.get(code) : null;
  if (!room?.game) return emitNotice(socket, 'No hay una partida activa.', 'error');
  const player = getSocketPlayer(room, socket);
  if (!player) return emitNotice(socket, 'No perteneces a esta partida.', 'error');
  if (room.mode !== 'local' && player.isAI) return emitNotice(socket, 'No puedes controlar a un rival de IA.', 'error');
  const result = handler(room.game, player);
  if (!result?.ok) return emitNotice(socket, result?.error || 'No se pudo realizar la acción.', 'error');
  emitGameState(room);
  scheduleAI(room);
}

io.on('connection', socket => {
  socket.emit('connected', { ok: true, app: 'Domino Club' });

  socket.on('createAI', (payload = {}) => {
    const settings = Rules.normalizeSettings(payload);
    const playerCount = settings.playerCount;
    const human = playerFromSocket(socket, payload);
    const definitions = [human];
    const usedNames = new Set();
    for (let i = 1; i < playerCount; i++) {
      const ai = pickAI(usedNames);
      usedNames.add(ai.name);
      definitions.push({
        id: uid('ai'), name: ai.name, avatar: ai.avatar,
        isAI: true, difficulty: validDifficulty(payload.difficulty), connected: true
      });
    }
    createStartedRoom(socket, 'ai', settings, definitions);
  });

  socket.on('createLocal', (payload = {}) => {
    const settings = Rules.normalizeSettings(payload);
    const names = ['Jugador 1', 'Jugador 2', 'Jugador 3', 'Jugador 4'];
    const definitions = Array.from({ length: settings.playerCount }, (_, index) => ({
      id: uid('local'),
      name: index === 0 ? cleanName(payload.name) : names[index],
      avatar: index === 0 ? cleanAvatar(payload.avatar) : AVATARS[index],
      isAI: false, difficulty: 'normal', connected: true
    }));
    createStartedRoom(socket, 'local', settings, definitions);
  });

  socket.on('createOnline', (payload = {}) => {
    const settings = Rules.normalizeSettings(payload);
    const player = playerFromSocket(socket, payload);
    const room = {
      code: newCode(), mode: 'online', settings,
      maxPlayers: settings.playerCount,
      hostId: player.id,
      hostSocketId: socket.id,
      players: [player], game: null
    };
    rooms.set(room.code, room);
    socket.join(room.code);
    socketRooms.set(socket.id, room.code);
    socket.emit('joined', { code: room.code, mode: 'online', playerId: player.id });
    emitLobby(room);
  });

  socket.on('joinOnline', (payload = {}) => {
    const code = String(payload.code || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
    const room = rooms.get(code);
    if (!room || room.mode !== 'online') return emitNotice(socket, 'No encontramos esa sala. Revisa el código.', 'error');
    if (room.game) return emitNotice(socket, 'La partida ya comenzó y no admite más jugadores.', 'error');
    if (room.players.length >= room.maxPlayers) return emitNotice(socket, 'La sala está completa.', 'error');
    const player = playerFromSocket(socket, payload);
    room.players.push(player);
    socket.join(room.code);
    socketRooms.set(socket.id, room.code);
    socket.emit('joined', { code: room.code, mode: 'online', playerId: player.id });
    emitLobby(room);
  });

  socket.on('startOnline', () => {
    const room = rooms.get(socketRooms.get(socket.id));
    if (!room || room.mode !== 'online') return emitNotice(socket, 'No tienes una sala online activa.', 'error');
    if (room.hostSocketId !== socket.id) return emitNotice(socket, 'Solo el anfitrión puede iniciar la partida.', 'error');
    const result = startOnlineRoom(room);
    if (!result.ok) emitNotice(socket, result.error, 'error');
  });

  socket.on('playTile', payload => handleHumanAction(socket, 'playTile', (game, player) => Rules.playTile(game, player.id, String(payload?.tileId || ''), payload?.side, payload?.orientation)));
  socket.on('drawTile', () => handleHumanAction(socket, 'drawTile', (game, player) => Rules.drawTile(game, player.id)));
  socket.on('passTurn', () => handleHumanAction(socket, 'passTurn', (game, player) => Rules.passTurn(game, player.id)));

  socket.on('newRound', () => {
    const room = rooms.get(socketRooms.get(socket.id));
    if (!room?.game) return emitNotice(socket, 'No hay una partida para reiniciar.', 'error');
    if (room.mode === 'online' && room.hostSocketId !== socket.id) return emitNotice(socket, 'Solo el anfitrión puede iniciar otra ronda.', 'error');
    const result = Rules.nextRound(room.game);
    if (!result.ok) return emitNotice(socket, result.error, 'error');
    emitGameState(room);
    scheduleAI(room);
  });

  socket.on('leaveRoom', () => {
    const code = socketRooms.get(socket.id);
    const room = rooms.get(code);
    if (room) {
      if (room.game) {
        const player = room.game.players.find(p => p.socketId === socket.id);
        if (player) player.connected = false;
      } else {
        room.players = room.players.filter(p => p.socketId !== socket.id);
        if (!room.players.length) rooms.delete(code);
        else emitLobby(room);
      }
    }
    socket.leave(code || '');
    socketRooms.delete(socket.id);
  });

  socket.on('disconnect', () => {
    const code = socketRooms.get(socket.id);
    const room = rooms.get(code);
    if (room) {
      const player = room.players.find(p => p.socketId === socket.id);
      if (player) player.connected = false;
      if (room.game) {
        const gamePlayer = room.game.players.find(p => p.id === player?.id);
        if (gamePlayer) gamePlayer.connected = false;
        emitGameState(room);
      } else emitLobby(room);
    }
    socketRooms.delete(socket.id);
  });
});

server.listen(PORT, process.env.HOST || '0.0.0.0', () => {
  console.log(`Domino Club escuchando en ${PORT}`);
});

function shutdown() {
  for (const timer of aiTimers.values()) clearTimeout(timer);
  server.close();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
