'use strict';

(function attachDominoLayout(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.DominoLayout = api;
})(typeof window !== 'undefined' ? window : globalThis, function createDominoLayout() {
  const FLOW_VECTORS = Object.freeze({
    down: Object.freeze({ x: 0, y: 1 }),
    up: Object.freeze({ x: 0, y: -1 }),
    left: Object.freeze({ x: -1, y: 0 }),
    right: Object.freeze({ x: 1, y: 0 })
  });
  const validFlow = value => Object.prototype.hasOwnProperty.call(FLOW_VECTORS, value) ? value : 'straight';
  const isHorizontal = direction => Math.abs(direction.x) > 0;
  const directionForFlow = flow => FLOW_VECTORS[flow] || { x: 0, y: 0 };

  function portHalfForDirection(orientation, direction, geometry) {
    const horizontalTravel = isHorizontal(direction);
    const tileLongAxisHorizontal = orientation === 'horizontal';
    const lengthAlongTravel = horizontalTravel === tileLongAxisHorizontal
      ? geometry.tileLong
      : geometry.tileShort;
    return lengthAlongTravel / 2;
  }

  // Devuelve el punto de salida de la mitad abierta de la ficha. La dirección
  // elegida puede ser perpendicular en cualquiera de los cuatro sentidos:
  // horizontal -> arriba/abajo; vertical -> izquierda/derecha.
  function turnAnchorForFlow(center, orientation, travelDirection, flow, geometry) {
    const nextDirection = directionForFlow(flow);
    const horizontalTravel = isHorizontal(travelDirection);
    const tileLongAxisHorizontal = orientation === 'horizontal';
    const followsLongAxis = horizontalTravel === tileLongAxisHorizontal;

    if (horizontalTravel) {
      if (followsLongAxis) {
        return {
          x: center.x + Math.sign(travelDirection.x) * (geometry.tileLong / 4),
          y: center.y + Math.sign(nextDirection.y) * (geometry.tileShort / 2)
        };
      }
      // Doble transversal: el puerto de salida está en el centro del lado corto.
      return {
        x: center.x + Math.sign(travelDirection.x) * (geometry.tileShort / 2),
        y: center.y
      };
    }

    if (followsLongAxis) {
      return {
        x: center.x + Math.sign(nextDirection.x) * (geometry.tileShort / 2),
        y: center.y + Math.sign(travelDirection.y) * (geometry.tileLong / 4)
      };
    }
    // Doble transversal sobre un tramo vertical.
    return {
      x: center.x,
      y: center.y + Math.sign(travelDirection.y) * (geometry.tileShort / 2)
    };
  }

  function buildArm(entries, sideSign, geometry, rootIndex, rootOrientation = 'horizontal') {
    const positions = [];
    const connectors = [];
    const rootCenter = { x: geometry.centerX, y: 0 };
    let previousCenter = rootCenter;
    let previousOrientation = rootOrientation;
    let previousTravelDirection = { x: sideSign, y: 0 };
    let direction = { x: sideSign, y: 0 };
    let horizontalDirection = sideSign;
    let rowCount = 0;
    let pendingTurn = null;
    // Se usa solo para el serpenteo automático. Si el jugador marca izquierda
    // o derecha desde un tramo vertical, se respeta esa elección sin invertirla.
    let returnRowPending = false;
    let returnRowSign = 1;
    let branchVerticalSign = null;
    let previousIndex = rootIndex;
    let previousEnd = {
      x: rootCenter.x + direction.x * portHalfForDirection(rootOrientation, direction, geometry),
      y: rootCenter.y
    };

    entries.forEach((entry) => {
      const isDouble = entry.tile.a === entry.tile.b;
      const incomingTurn = pendingTurn;
      let travelDirection;
      let orientation;
      let startAnchor;
      let center;
      let connectorPath;

      if (incomingTurn) {
        // La ficha siguiente viaja en el sentido exacto pedido por la pieza
        // anterior: abajo, arriba, izquierda o derecha.
        travelDirection = directionForFlow(incomingTurn);
        if (incomingTurn === 'down' || incomingTurn === 'up') {
          // Si la ficha de giro es un doble transversal, su cuerpo sobresale
          // más hacia abajo/arriba que su puerto lateral. Baja desde su borde
          // exterior para que la ficha siguiente quede debajo, no a su costado.
          const sourceWasHorizontal = Math.abs(previousTravelDirection.x) > 0;
          const sourceHalfHeight = previousOrientation === 'vertical'
            ? geometry.tileLong / 2
            : geometry.tileShort / 2;
          const turnStartY = sourceWasHorizontal
            ? previousCenter.y + travelDirection.y * (sourceHalfHeight + geometry.gap)
            : previousEnd.y + travelDirection.y * geometry.gap;
          startAnchor = { x: previousEnd.x, y: turnStartY };
        } else {
          // Desde una punta vertical, izquierda/derecha sale desde el punto de
          // conexión de esa mitad y mantiene el sentido que eligió el jugador.
          startAnchor = {
            x: previousEnd.x + travelDirection.x * geometry.gap,
            y: previousEnd.y + travelDirection.y * geometry.gap
          };
        }
        const horizontalTravel = isHorizontal(travelDirection);
        orientation = isDouble
          ? (horizontalTravel ? 'vertical' : 'horizontal')
          : (horizontalTravel ? 'horizontal' : 'vertical');
        const incomingHalf = portHalfForDirection(orientation, travelDirection, geometry);
        center = {
          x: startAnchor.x + travelDirection.x * incomingHalf,
          y: startAnchor.y + travelDirection.y * incomingHalf
        };
        pendingTurn = null;
      } else {
        travelDirection = direction;
        if (returnRowPending) {
          // Vuelta automática de serpiente: baja/sube hasta el carril libre y
          // después recorre la fila en sentido contrario.
          const laneY = previousEnd.y + returnRowSign * (geometry.tileLong / 2 + geometry.gap);
          startAnchor = {
            x: previousEnd.x + travelDirection.x * geometry.gap,
            y: laneY
          };
          connectorPath = `M ${previousEnd.x} ${previousEnd.y} L ${previousEnd.x} ${laneY} L ${startAnchor.x} ${startAnchor.y}`;
          returnRowPending = false;
        } else {
          startAnchor = {
            x: previousEnd.x + travelDirection.x * geometry.gap,
            y: previousEnd.y + travelDirection.y * geometry.gap
          };
        }
        const horizontalTravel = isHorizontal(travelDirection);
        orientation = isDouble
          ? (horizontalTravel ? 'vertical' : 'horizontal')
          : (horizontalTravel ? 'horizontal' : 'vertical');
        const incomingHalf = portHalfForDirection(orientation, travelDirection, geometry);
        center = {
          x: startAnchor.x + travelDirection.x * incomingHalf,
          y: startAnchor.y + travelDirection.y * incomingHalf
        };
      }

      if (travelDirection.x) horizontalDirection = travelDirection.x;

      let requestedFlow = validFlow(entry.tile.flowAfter);
      // Solo se permiten giros perpendiculares al tramo actual. En horizontal
      // se elige arriba/abajo; en vertical se elige izquierda/derecha.
      if (isHorizontal(travelDirection)) {
        if (!['down', 'up'].includes(requestedFlow)) requestedFlow = 'straight';
        if (requestedFlow !== 'straight') {
          const requestedSign = requestedFlow === 'down' ? 1 : -1;
          if (branchVerticalSign === null) branchVerticalSign = requestedSign;
          else if (requestedSign !== branchVerticalSign) requestedFlow = branchVerticalSign > 0 ? 'down' : 'up';
        }
      } else {
        const forwardFlow = travelDirection.y > 0 ? 'down' : 'up';
        // Repetir la dirección vertical significa continuar por la punta actual;
        // izquierda/derecha crea una salida lateral elegida por el jugador.
        if (requestedFlow === forwardFlow) {
          // Se conserva como instrucción explícita de seguir por el mismo eje.
        } else if (!['left', 'right'].includes(requestedFlow)) {
          requestedFlow = 'straight';
        }
      }

      let automaticTurn = false;
      if (requestedFlow === 'straight' && isHorizontal(travelDirection) && !incomingTurn && rowCount + 1 >= geometry.maxPerRow) {
        if (branchVerticalSign === null) branchVerticalSign = 1;
        requestedFlow = branchVerticalSign > 0 ? 'down' : 'up';
        automaticTurn = true;
      }

      let endAnchor;
      let turnDirection = 'straight';
      const verticalContinuation = !isHorizontal(travelDirection)
        && requestedFlow === (travelDirection.y > 0 ? 'down' : 'up');
      if (requestedFlow !== 'straight' && !verticalContinuation) {
        turnDirection = requestedFlow;
        endAnchor = turnAnchorForFlow(center, orientation, travelDirection, requestedFlow, geometry);
        pendingTurn = requestedFlow;
        rowCount = 0;
      } else {
        const outgoingHalf = portHalfForDirection(orientation, travelDirection, geometry);
        endAnchor = {
          x: center.x + travelDirection.x * outgoingHalf,
          y: center.y + travelDirection.y * outgoingHalf
        };

        if (verticalContinuation) {
          // La ficha siguiente mantiene la misma bajada/subida. No se desplaza
          // lateralmente ni activa todavía la fila de retorno.
          turnDirection = requestedFlow;
          pendingTurn = requestedFlow;
          rowCount = 0;
        } else if (incomingTurn === 'down' || incomingTurn === 'up') {
          // Comportamiento por defecto después de una bajada/subida: regresar
          // en sentido contrario para formar una serpiente. Si el usuario
          // elige izquierda/derecha en la ficha vertical, se procesa arriba y
          // esta inversión automática no se ejecuta.
          horizontalDirection *= -1;
          direction = { x: horizontalDirection, y: 0 };
          returnRowPending = true;
          returnRowSign = incomingTurn === 'down' ? 1 : -1;
          rowCount = 0;
        } else {
          direction = travelDirection;
          if (isHorizontal(travelDirection)) rowCount += 1;
          else rowCount = 0;
        }
      }

      const axisDirection = travelDirection.x || travelDirection.y;
      const logicalDirection = sideSign * axisDirection;
      const position = {
        index: entry.index,
        id: entry.tile.id,
        x: center.x,
        y: center.y,
        orientation,
        isDouble,
        reverseHalves: logicalDirection < 0,
        logicalDirection,
        travelX: travelDirection.x,
        travelY: travelDirection.y,
        turnsAfter: turnDirection !== 'straight',
        turnDirection,
        automaticTurn,
        startX: startAnchor.x,
        startY: startAnchor.y,
        endX: endAnchor.x,
        endY: endAnchor.y
      };
      positions.push(position);
      connectors.push({
        fromIndex: previousIndex,
        toIndex: entry.index,
        from: { x: previousEnd.x, y: previousEnd.y },
        to: { x: startAnchor.x, y: startAnchor.y },
        path: connectorPath || `M ${previousEnd.x} ${previousEnd.y} L ${startAnchor.x} ${startAnchor.y}`
      });

      previousCenter = center;
      previousOrientation = orientation;
      previousTravelDirection = travelDirection;
      previousEnd = endAnchor;
      previousIndex = entry.index;
    });

    return { positions, connectors };
  }

  function buildChainLayout(chain, openingTileId, width, options = {}) {
    const safeChain = Array.isArray(chain) ? chain : [];
    const safeWidth = Math.max(280, Number(width) || 900);
    const mobile = safeWidth < 520;
    const tileLong = mobile ? 56 : 78;
    const tileShort = mobile ? 32 : 42;
    const gap = mobile ? 8 : 12;
    const paddingX = mobile ? 12 : 22;
    const paddingY = mobile ? 18 : 22;
    const centerX = safeWidth / 2;
    const maxPerRow = Math.max(2, Math.floor((centerX - tileLong / 2 - paddingX) / (tileLong + gap)) - 1);

    if (!safeChain.length) {
      return {
        width: safeWidth,
        height: Math.max(Number(options.minHeight) || 285, tileLong + paddingY * 2),
        rootIndex: -1,
        root: null,
        positions: [],
        connectors: [],
        tileLong,
        tileShort,
        maxPerRow
      };
    }

    let rootIndex = safeChain.findIndex(tile => tile.id === openingTileId);
    if (rootIndex < 0) rootIndex = Math.floor((safeChain.length - 1) / 2);

    const leftEntries = safeChain.slice(0, rootIndex)
      .map((tile, offset) => ({ tile, index: offset })).reverse();
    const rightEntries = safeChain.slice(rootIndex + 1)
      .map((tile, offset) => ({ tile, index: rootIndex + 1 + offset }));
    const geometry = { centerX, tileLong, tileShort, gap, maxPerRow };
    const openingTile = safeChain[rootIndex];
    const openingIsDouble = openingTile.a === openingTile.b;
    const rootOrientation = openingIsDouble ? 'vertical' : 'horizontal';
    const left = buildArm(leftEntries, -1, geometry, rootIndex, rootOrientation);
    const right = buildArm(rightEntries, 1, geometry, rootIndex, rootOrientation);
    const all = [...left.positions, ...right.positions];
    const minY = Math.min(0, ...all.map(item => item.y - (item.orientation === 'vertical' ? tileLong : tileShort) / 2));
    const maxY = Math.max(0, ...all.map(item => item.y + (item.orientation === 'vertical' ? tileLong : tileShort) / 2));
    const centerY = Math.max(Number(options.centerY) || 142, paddingY + tileLong / 2 - minY);
    const shiftY = centerY;
    const positions = new Array(safeChain.length);
    positions[rootIndex] = {
      index: rootIndex,
      id: openingTile.id,
      x: centerX,
      y: shiftY,
      orientation: rootOrientation,
      isDouble: openingIsDouble,
      reverseHalves: false,
      turnsAfter: false,
      turnDirection: 'straight',
      opening: true,
      startX: centerX - (rootOrientation === 'horizontal' ? tileLong : tileShort) / 2,
      startY: shiftY,
      endX: centerX + (rootOrientation === 'horizontal' ? tileLong : tileShort) / 2,
      endY: shiftY,
      travelX: 0,
      travelY: 0
    };

    for (const item of all) positions[item.index] = { ...item, y: item.y + shiftY, startY: item.startY + shiftY, endY: item.endY + shiftY };
    const shiftPathY = path => path.replace(/([ML])\s*(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)/g,
      (match, command, x, y) => `${command} ${x} ${Number(y) + shiftY}`);
    const connectors = [...left.connectors, ...right.connectors].map(item => ({
      ...item,
      from: { x: item.from.x, y: item.from.y + shiftY },
      to: { x: item.to.x, y: item.to.y + shiftY },
      path: shiftPathY(item.path)
    }));

    const verticalExtent = Math.max(0, ...positions.map(item => item.orientation === 'vertical' ? tileLong / 2 : tileShort / 2));
    const actualMinY = Math.min(...positions.map(item => item.y - (item.orientation === 'vertical' ? tileLong : tileShort) / 2));
    const actualMaxY = Math.max(...positions.map(item => item.y + (item.orientation === 'vertical' ? tileLong : tileShort) / 2));
    const height = Math.max(Number(options.minHeight) || 285, actualMaxY + paddingY, verticalExtent * 2 + paddingY * 2);

    return {
      width: safeWidth,
      height,
      rootIndex,
      root: positions[rootIndex],
      positions,
      connectors,
      tileLong,
      tileShort,
      maxPerRow,
      minY: actualMinY,
      maxY: actualMaxY
    };
  }

  return { buildChainLayout };
});
