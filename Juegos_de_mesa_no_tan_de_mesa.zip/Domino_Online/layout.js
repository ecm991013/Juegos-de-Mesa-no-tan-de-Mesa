'use strict';

(function attachDominoLayout(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.DominoLayout = api;
})(typeof window !== 'undefined' ? window : globalThis, function createDominoLayout() {
  const validFlow = value => value === 'down' || value === 'up' ? value : 'straight';

  function portHalfForDirection(orientation, direction, geometry) {
    const horizontalTravel = Math.abs(direction.x) > 0;
    const tileLongAxisHorizontal = orientation === 'horizontal';
    const lengthAlongTravel = horizontalTravel === tileLongAxisHorizontal
      ? geometry.tileLong
      : geometry.tileShort;
    return lengthAlongTravel / 2;
  }

  function buildArm(entries, sideSign, geometry, rootIndex, rootOrientation = 'horizontal') {
    const positions = [];
    const connectors = [];
    let previousCenter = { x: geometry.centerX, y: 0 };
    let previousDirection = { x: sideSign, y: 0 };
    let previousOrientation = rootOrientation;
    let previousIndex = rootIndex;
    let horizontalDirection = sideSign;
    let rowCount = 0;

    entries.forEach((entry) => {
      const requestedFlow = validFlow(entry.tile.flowAfter);
      const automaticTurn = requestedFlow === 'straight' && rowCount + 1 >= geometry.maxPerRow;
      const turnDirection = requestedFlow !== 'straight' ? requestedFlow : (automaticTurn ? 'down' : 'straight');
      let exitDirection;
      if (turnDirection === 'down' || turnDirection === 'up') {
        exitDirection = { x: 0, y: turnDirection === 'down' ? 1 : -1 };
        rowCount = 0;
        // Después del giro, la nueva fila regresa en sentido contrario.
        horizontalDirection *= -1;
      } else {
        exitDirection = { x: horizontalDirection, y: 0 };
        rowCount += 1;
      }

      const isDouble = entry.tile.a === entry.tile.b;
      const travellingHorizontally = Math.abs(exitDirection.x) > 0;
      const enteringHorizontally = Math.abs(previousDirection.x) > 0;
      // Las fichas normales siguen la dirección de salida de su tramo.
      // Un doble cruza el recorrido que llega a él: queda centrado y perpendicular
      // a la dirección de entrada, incluso cuando marca un giro de la cadena.
      const orientation = isDouble
        ? (enteringHorizontally ? 'vertical' : 'horizontal')
        : (travellingHorizontally ? 'horizontal' : 'vertical');

      const previousHalf = portHalfForDirection(previousOrientation, previousDirection, geometry);
      const previousEnd = {
        x: previousCenter.x + previousDirection.x * previousHalf,
        y: previousCenter.y + previousDirection.y * previousHalf
      };
      const dot = previousDirection.x * exitDirection.x + previousDirection.y * exitDirection.y;
      let startAnchor;
      let path;

      if (dot > 0) {
        startAnchor = {
          x: previousEnd.x + exitDirection.x * geometry.gap,
          y: previousEnd.y + exitDirection.y * geometry.gap
        };
        path = `M ${previousEnd.x} ${previousEnd.y} L ${startAnchor.x} ${startAnchor.y}`;
      } else {
        const corner = {
          x: previousEnd.x + previousDirection.x * geometry.gap,
          y: previousEnd.y + previousDirection.y * geometry.gap
        };
        startAnchor = {
          x: corner.x + exitDirection.x * geometry.gap,
          y: corner.y + exitDirection.y * geometry.gap
        };
        path = `M ${previousEnd.x} ${previousEnd.y} L ${corner.x} ${corner.y} L ${startAnchor.x} ${startAnchor.y}`;
      }

      // El punto de entrada se sitúa en el borde real de la ficha según
      // la dirección que trae la cadena. Esto permite que un doble cruce
      // el recorrido y que una ficha de giro conecte por su lateral, sin huecos.
      const incomingPortHalf = portHalfForDirection(orientation, previousDirection, geometry);
      const center = {
        x: startAnchor.x + previousDirection.x * incomingPortHalf,
        y: startAnchor.y + previousDirection.y * incomingPortHalf
      };
      const outgoingPortHalf = portHalfForDirection(orientation, exitDirection, geometry);
      const endAnchor = {
        x: center.x + exitDirection.x * outgoingPortHalf,
        y: center.y + exitDirection.y * outgoingPortHalf
      };
      const axisDirection = exitDirection.x || exitDirection.y;
      const logicalDirection = sideSign * axisDirection;
      const position = {
        index: entry.index,
        id: entry.tile.id,
        x: center.x,
        y: center.y,
        orientation,
        isDouble,
        reverseHalves: logicalDirection < 0,
        logicalDirection,
        turnsAfter: turnDirection !== 'straight',
        turnDirection,
        startX: startAnchor.x,
        startY: startAnchor.y,
        endX: endAnchor.x,
        endY: endAnchor.y
      };
      positions.push(position);
      connectors.push({ fromIndex: previousIndex, toIndex: entry.index, from: previousEnd, to: startAnchor, path });

      previousCenter = center;
      previousDirection = exitDirection;
      previousOrientation = orientation;
      previousIndex = entry.index;
    });

    return { positions, connectors };
  }

  function buildChainLayout(chain, openingTileId, width, options = {}) {
    const safeChain = Array.isArray(chain) ? chain : [];
    const safeWidth = Math.max(280, Number(width) || 900);
    const mobile = safeWidth < 520;
    const tileLong = mobile ? 56 : 78;
    const tileShort = mobile ? 32 : 42;
    const gap = mobile ? 8 : 12;
    const paddingX = mobile ? 12 : 22;
    const paddingY = mobile ? 18 : 22;
    const centerX = safeWidth / 2;
    const maxPerRow = Math.max(2, Math.floor((centerX - tileLong / 2 - paddingX) / (tileLong + gap)));

    if (!safeChain.length) {
      return {
        width: safeWidth,
        height: Math.max(Number(options.minHeight) || 285, tileLong + paddingY * 2),
        rootIndex: -1,
        root: null,
        positions: [],
        connectors: [],
        tileLong,
        tileShort,
        maxPerRow
      };
    }

    let rootIndex = safeChain.findIndex(tile => tile.id === openingTileId);
    if (rootIndex < 0) rootIndex = Math.floor((safeChain.length - 1) / 2);

    const leftEntries = safeChain.slice(0, rootIndex)
      .map((tile, offset) => ({ tile, index: offset })).reverse();
    const rightEntries = safeChain.slice(rootIndex + 1)
      .map((tile, offset) => ({ tile, index: rootIndex + 1 + offset }));
    const geometry = { centerX, tileLong, tileShort, gap, maxPerRow };
    const openingTile = safeChain[rootIndex];
    const openingIsDouble = openingTile.a === openingTile.b;
    const rootOrientation = openingIsDouble ? 'vertical' : 'horizontal';
    const left = buildArm(leftEntries, -1, geometry, rootIndex, rootOrientation);
    const right = buildArm(rightEntries, 1, geometry, rootIndex, rootOrientation);
    const all = [...left.positions, ...right.positions];
    const minY = Math.min(0, ...all.map(item => item.y - (item.orientation === 'vertical' ? tileLong : tileShort) / 2));
    const maxY = Math.max(0, ...all.map(item => item.y + (item.orientation === 'vertical' ? tileLong : tileShort) / 2));
    const centerY = Math.max(Number(options.centerY) || 142, paddingY + tileLong / 2 - minY);
    const shiftY = centerY;
    const positions = new Array(safeChain.length);
    positions[rootIndex] = {
      index: rootIndex,
      id: openingTile.id,
      x: centerX,
      y: shiftY,
      orientation: rootOrientation,
      isDouble: openingIsDouble,
      reverseHalves: false,
      turnsAfter: false,
      turnDirection: 'straight',
      opening: true,
      startX: centerX - (rootOrientation === 'horizontal' ? tileLong : tileShort) / 2,
      startY: shiftY,
      endX: centerX + (rootOrientation === 'horizontal' ? tileLong : tileShort) / 2,
      endY: shiftY
    };

    for (const item of all) positions[item.index] = { ...item, y: item.y + shiftY, startY: item.startY + shiftY, endY: item.endY + shiftY };
    const shiftPathY = path => path.replace(/([ML])\s*(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)/g,
      (match, command, x, y) => `${command} ${x} ${Number(y) + shiftY}`);
    const connectors = [...left.connectors, ...right.connectors].map(item => ({
      ...item,
      from: { x: item.from.x, y: item.from.y + shiftY },
      to: { x: item.to.x, y: item.to.y + shiftY },
      path: shiftPathY(item.path)
    }));

    const verticalExtent = Math.max(0, ...positions.map(item => item.orientation === 'vertical' ? tileLong / 2 : tileShort / 2));
    const actualMinY = Math.min(...positions.map(item => item.y - (item.orientation === 'vertical' ? tileLong : tileShort) / 2));
    const actualMaxY = Math.max(...positions.map(item => item.y + (item.orientation === 'vertical' ? tileLong : tileShort) / 2));
    const height = Math.max(Number(options.minHeight) || 285, actualMaxY + paddingY, verticalExtent * 2 + paddingY * 2);

    return {
      width: safeWidth,
      height,
      rootIndex,
      root: positions[rootIndex],
      positions,
      connectors,
      tileLong,
      tileShort,
      maxPerRow,
      minY: actualMinY,
      maxY: actualMaxY
    };
  }

  return { buildChainLayout };
});
