'use strict';

(function attachDominoLayout(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.DominoLayout = api;
})(typeof window !== 'undefined' ? window : globalThis, function createDominoLayout() {
  function layoutArm(entries, sideSign, geometry) {
    const positions = [];
    let x = geometry.centerX + sideSign * geometry.stepX;
    let y = 0;
    let direction = sideSign;
    let inRow = 0;
    let minY = 0;
    let maxY = 0;

    entries.forEach((entry) => {
      const flow = ['down', 'up'].includes(entry.tile.flowAfter) ? entry.tile.flowAfter : 'straight';
      const turnByCapacity = inRow + 1 >= geometry.maxPerRow;
      const turnsAfter = flow !== 'straight' || turnByCapacity;
      positions.push({
        index: entry.index,
        id: entry.tile.id,
        x,
        y,
        orientation: turnsAfter ? 'vertical' : 'horizontal',
        turnsAfter,
        turnDirection: flow !== 'straight' ? flow : (turnByCapacity ? 'down' : 'straight')
      });
      minY = Math.min(minY, y);
      maxY = Math.max(maxY, y);

      if (turnsAfter) {
        y += (flow === 'up' ? -1 : 1) * geometry.stepY;
        direction *= -1;
        inRow = 0;
      } else {
        x += direction * geometry.stepX;
        inRow += 1;
      }
    });

    return { positions, minY, maxY };
  }

  function buildChainLayout(chain, openingTileId, width, options = {}) {
    const safeChain = Array.isArray(chain) ? chain : [];
    const safeWidth = Math.max(280, Number(width) || 900);
    const mobile = safeWidth < 520;
    const tileWidth = mobile ? 56 : 78;
    const tileHeight = mobile ? 32 : 42;
    const gap = mobile ? 9 : 12;
    const paddingX = mobile ? 8 : 18;
    const paddingY = mobile ? 18 : 22;
    const centerX = safeWidth / 2;
    const stepX = tileWidth + gap;
    // Separación necesaria entre un dominó vertical de giro y el siguiente horizontal.
    const stepY = (tileWidth + tileHeight) / 2 + gap;
    const maxPerRow = Math.max(2, Math.floor((centerX - tileWidth / 2 - paddingX) / stepX));

    if (!safeChain.length) {
      return {
        width: safeWidth,
        height: Math.max(Number(options.minHeight) || 285, tileHeight + paddingY * 2),
        rootIndex: -1,
        root: null,
        positions: []
      };
    }

    let rootIndex = safeChain.findIndex(tile => tile.id === openingTileId);
    if (rootIndex < 0) rootIndex = Math.floor((safeChain.length - 1) / 2);

    const leftEntries = safeChain.slice(0, rootIndex).map((tile, offset) => ({ tile, index: offset })).reverse();
    const rightEntries = safeChain.slice(rootIndex + 1).map((tile, offset) => ({ tile, index: rootIndex + 1 + offset }));
    const geometry = { centerX, stepX, stepY, maxPerRow };
    const left = layoutArm(leftEntries, -1, geometry);
    const right = layoutArm(rightEntries, 1, geometry);
    const all = [...left.positions, ...right.positions];
    const minY = Math.min(0, ...all.map(item => item.y));
    const maxY = Math.max(0, ...all.map(item => item.y));
    const baseY = Math.max(Number(options.centerY) || 142, paddingY + tileWidth / 2 - minY);
    const positions = new Array(safeChain.length);
    const rootTile = safeChain[rootIndex];
    positions[rootIndex] = {
      index: rootIndex,
      id: rootTile.id,
      x: centerX,
      y: baseY,
      orientation: 'horizontal',
      turnsAfter: false,
      turnDirection: 'straight',
      opening: true
    };
    for (const item of all) positions[item.index] = { ...item, y: item.y + baseY };

    const maxExtentY = Math.max(...positions.map(item => item.orientation === 'vertical' ? tileWidth / 2 : tileHeight / 2));
    const height = Math.max(
      Number(options.minHeight) || 285,
      baseY + maxY + maxExtentY + paddingY
    );
    return { width: safeWidth, height, rootIndex, root: positions[rootIndex], positions, tileWidth, tileHeight, maxPerRow };
  }

  return { buildChainLayout };
});
