'use strict';

(function attachDominoLayout(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.DominoLayout = api;
})(typeof window !== 'undefined' ? window : globalThis, function createDominoLayout() {
  const validFlow = value => value === 'down' || value === 'up' ? value : 'straight';

  function portHalfForDirection(orientation, direction, geometry) {
    const horizontalTravel = Math.abs(direction.x) > 0;
    const tileLongAxisHorizontal = orientation === 'horizontal';
    const lengthAlongTravel = horizontalTravel === tileLongAxisHorizontal
      ? geometry.tileLong
      : geometry.tileShort;
    return lengthAlongTravel / 2;
  }

  function turnAnchorForFlow(center, orientation, direction, flow, geometry) {
    const verticalSign = flow === 'down' ? 1 : -1;
    const horizontalTravel = Math.abs(direction.x) > 0;
    const tileLongAxisHorizontal = orientation === 'horizontal';
    const followsLongAxis = horizontalTravel === tileLongAxisHorizontal;

    // Cuando la ficha está alineada con el recorrido horizontal, el giro
    // nace debajo/encima del centro de la mitad abierta (no del borde exterior
    // de toda la ficha). Así la pieza vertical queda bajo el valor de salida.
    if (followsLongAxis && horizontalTravel) {
      return {
        x: center.x + direction.x * (geometry.tileLong / 4),
        y: center.y + verticalSign * (geometry.tileShort / 2)
      };
    }

    // En un tramo vertical, el giro continúa desde la punta inferior/superior.
    // También cubre los dobles atravesados, cuyo eje largo es perpendicular.
    if (!horizontalTravel && followsLongAxis) {
      return { x: center.x, y: center.y + verticalSign * (geometry.tileLong / 2) };
    }

    // Ficha transversal (por ejemplo, un doble cruzando el recorrido):
    // usa el puerto central del lado por donde continúa la cadena.
    return {
      x: center.x + direction.x * (geometry.tileShort / 2),
      y: center.y + direction.y * (geometry.tileShort / 2)
    };
  }

  function buildArm(entries, sideSign, geometry, rootIndex, rootOrientation = 'horizontal') {
    const positions = [];
    const connectors = [];
    const rootCenter = { x: geometry.centerX, y: 0 };
    let previousCenter = rootCenter;
    let previousOrientation = rootOrientation;
    let previousTravelDirection = { x: sideSign, y: 0 };
    let direction = { x: sideSign, y: 0 };
    let horizontalDirection = sideSign;
    let rowCount = 0;
    let pendingTurn = null;
    // Tras completar una ficha vertical de giro, la fila de retorno necesita
    // su propio carril. Se reserva el espacio de una ficha completa para que
    // los dobles transversales no se monten sobre la ficha del giro.
    let returnRowPending = false;
    let returnRowSign = 1;
    // Cada brazo serpentea siempre hacia el mismo lado vertical. Cambiar de
    // abajo a arriba a mitad del recorrido cruzaría filas ya ocupadas.
    let branchVerticalSign = null;
    let previousIndex = rootIndex;
    let previousEnd = {
      x: rootCenter.x + direction.x * portHalfForDirection(rootOrientation, direction, geometry),
      y: rootCenter.y
    };

    entries.forEach((entry) => {
      const isDouble = entry.tile.a === entry.tile.b;
      const incomingTurn = pendingTurn;
      let travelDirection;
      let orientation;
      let startAnchor;
      let center;

      let connectorPath;
      if (incomingTurn) {
        // El flowAfter pertenece a la ficha anterior: esta ficha cae debajo/
        // encima de la mitad abierta y conserva la orientación del recorrido.
        travelDirection = { x: 0, y: incomingTurn === 'down' ? 1 : -1 };
        const sourceWasHorizontal = Math.abs(previousTravelDirection.x) > 0;
        const sourceHalfHeight = previousOrientation === 'vertical'
          ? geometry.tileLong / 2
          : geometry.tileShort / 2;
        // Si la ficha fuente era transversal (doble), su puerto lateral queda
        // a media altura. El recorrido baja/sube por fuera de su borde antes
        // de colocar la siguiente ficha, evitando que ambas se monten.
        const turnStartY = sourceWasHorizontal
          ? previousCenter.y + travelDirection.y * (sourceHalfHeight + geometry.gap)
          : previousEnd.y + travelDirection.y * geometry.gap;
        startAnchor = { x: previousEnd.x, y: turnStartY };
        orientation = isDouble ? 'horizontal' : 'vertical';
        const incomingHalf = portHalfForDirection(orientation, travelDirection, geometry);
        center = {
          x: startAnchor.x + travelDirection.x * incomingHalf,
          y: startAnchor.y + travelDirection.y * incomingHalf
        };
        pendingTurn = null;
      } else {
        travelDirection = direction;
        if (returnRowPending) {
          // La cadena gira en escuadra: baja/sube hasta un carril libre y luego
          // vuelve en sentido contrario. Evita que un doble perpendicular se
          // superponga con la ficha vertical que acaba de cerrar el giro.
          const laneY = previousEnd.y + returnRowSign * (geometry.tileLong / 2 + geometry.gap);
          startAnchor = {
            x: previousEnd.x + travelDirection.x * geometry.gap,
            y: laneY
          };
          connectorPath = `M ${previousEnd.x} ${previousEnd.y} L ${previousEnd.x} ${laneY} L ${startAnchor.x} ${startAnchor.y}`;
          returnRowPending = false;
        } else {
          startAnchor = {
            x: previousEnd.x + travelDirection.x * geometry.gap,
            y: previousEnd.y + travelDirection.y * geometry.gap
          };
        }
        orientation = isDouble
          ? (Math.abs(travelDirection.x) > 0 ? 'vertical' : 'horizontal')
          : (Math.abs(travelDirection.x) > 0 ? 'horizontal' : 'vertical');
        const incomingHalf = portHalfForDirection(orientation, travelDirection, geometry);
        center = {
          x: startAnchor.x + travelDirection.x * incomingHalf,
          y: startAnchor.y + travelDirection.y * incomingHalf
        };
      }

      let requestedFlow = validFlow(entry.tile.flowAfter);
      // En un tramo vertical solo se puede salir por la punta hacia la que
      // avanza la cadena. Elegir el extremo opuesto haría que la siguiente
      // ficha regresara sobre la anterior y provocaría solapamientos.
      if (travelDirection.y && requestedFlow !== 'straight') {
        const forwardFlow = travelDirection.y > 0 ? 'down' : 'up';
        if (requestedFlow !== forwardFlow) requestedFlow = 'straight';
      }
      if (travelDirection.x && requestedFlow !== 'straight') {
        const requestedSign = requestedFlow === 'down' ? 1 : -1;
        if (branchVerticalSign === null) branchVerticalSign = requestedSign;
        else if (requestedSign !== branchVerticalSign) requestedFlow = branchVerticalSign > 0 ? 'down' : 'up';
      }
      let automaticTurn = false;
      if (requestedFlow === 'straight' && travelDirection.x && !incomingTurn && rowCount + 1 >= geometry.maxPerRow) {
        if (branchVerticalSign === null) branchVerticalSign = 1;
        requestedFlow = branchVerticalSign > 0 ? 'down' : 'up';
        automaticTurn = true;
      }

      let endAnchor;
      let turnDirection = 'straight';
      if (requestedFlow === 'down' || requestedFlow === 'up') {
        turnDirection = requestedFlow;
        endAnchor = turnAnchorForFlow(center, orientation, travelDirection, requestedFlow, geometry);
        pendingTurn = requestedFlow;
        if (travelDirection.x) horizontalDirection = travelDirection.x;
        rowCount = 0;
      } else {
        const outgoingHalf = portHalfForDirection(orientation, travelDirection, geometry);
        endAnchor = {
          x: center.x + travelDirection.x * outgoingHalf,
          y: center.y + travelDirection.y * outgoingHalf
        };

        if (incomingTurn) {
          // La siguiente ficha inicia una nueva fila con separación suficiente
          // para el tamaño máximo (doble vertical) y un conector en escuadra.
          horizontalDirection *= -1;
          direction = { x: horizontalDirection, y: 0 };
          returnRowPending = true;
          returnRowSign = incomingTurn === 'down' ? 1 : -1;
          rowCount = 0;
        } else {
          direction = travelDirection;
          if (travelDirection.x) rowCount += 1;
          else rowCount = 0;
        }
      }

      const axisDirection = travelDirection.x || travelDirection.y;
      const logicalDirection = sideSign * axisDirection;
      const position = {
        index: entry.index,
        id: entry.tile.id,
        x: center.x,
        y: center.y,
        orientation,
        isDouble,
        reverseHalves: logicalDirection < 0,
        logicalDirection,
        turnsAfter: turnDirection !== 'straight',
        turnDirection,
        automaticTurn,
        startX: startAnchor.x,
        startY: startAnchor.y,
        endX: endAnchor.x,
        endY: endAnchor.y
      };
      positions.push(position);
      connectors.push({
        fromIndex: previousIndex,
        toIndex: entry.index,
        from: { x: previousEnd.x, y: previousEnd.y },
        to: { x: startAnchor.x, y: startAnchor.y },
        path: connectorPath || `M ${previousEnd.x} ${previousEnd.y} L ${startAnchor.x} ${startAnchor.y}`
      });

      previousCenter = center;
      previousOrientation = orientation;
      previousTravelDirection = travelDirection;
      previousEnd = endAnchor;
      previousIndex = entry.index;
    });

    return { positions, connectors };
  }

  function buildChainLayout(chain, openingTileId, width, options = {}) {
    const safeChain = Array.isArray(chain) ? chain : [];
    const safeWidth = Math.max(280, Number(width) || 900);
    const mobile = safeWidth < 520;
    const tileLong = mobile ? 56 : 78;
    const tileShort = mobile ? 32 : 42;
    const gap = mobile ? 8 : 12;
    const paddingX = mobile ? 12 : 22;
    const paddingY = mobile ? 18 : 22;
    const centerX = safeWidth / 2;
    const maxPerRow = Math.max(2, Math.floor((centerX - tileLong / 2 - paddingX) / (tileLong + gap)) - 1);

    if (!safeChain.length) {
      return {
        width: safeWidth,
        height: Math.max(Number(options.minHeight) || 285, tileLong + paddingY * 2),
        rootIndex: -1,
        root: null,
        positions: [],
        connectors: [],
        tileLong,
        tileShort,
        maxPerRow
      };
    }

    let rootIndex = safeChain.findIndex(tile => tile.id === openingTileId);
    if (rootIndex < 0) rootIndex = Math.floor((safeChain.length - 1) / 2);

    const leftEntries = safeChain.slice(0, rootIndex)
      .map((tile, offset) => ({ tile, index: offset })).reverse();
    const rightEntries = safeChain.slice(rootIndex + 1)
      .map((tile, offset) => ({ tile, index: rootIndex + 1 + offset }));
    const geometry = { centerX, tileLong, tileShort, gap, maxPerRow };
    const openingTile = safeChain[rootIndex];
    const openingIsDouble = openingTile.a === openingTile.b;
    const rootOrientation = openingIsDouble ? 'vertical' : 'horizontal';
    const left = buildArm(leftEntries, -1, geometry, rootIndex, rootOrientation);
    const right = buildArm(rightEntries, 1, geometry, rootIndex, rootOrientation);
    const all = [...left.positions, ...right.positions];
    const minY = Math.min(0, ...all.map(item => item.y - (item.orientation === 'vertical' ? tileLong : tileShort) / 2));
    const maxY = Math.max(0, ...all.map(item => item.y + (item.orientation === 'vertical' ? tileLong : tileShort) / 2));
    const centerY = Math.max(Number(options.centerY) || 142, paddingY + tileLong / 2 - minY);
    const shiftY = centerY;
    const positions = new Array(safeChain.length);
    positions[rootIndex] = {
      index: rootIndex,
      id: openingTile.id,
      x: centerX,
      y: shiftY,
      orientation: rootOrientation,
      isDouble: openingIsDouble,
      reverseHalves: false,
      turnsAfter: false,
      turnDirection: 'straight',
      opening: true,
      startX: centerX - (rootOrientation === 'horizontal' ? tileLong : tileShort) / 2,
      startY: shiftY,
      endX: centerX + (rootOrientation === 'horizontal' ? tileLong : tileShort) / 2,
      endY: shiftY
    };

    for (const item of all) positions[item.index] = { ...item, y: item.y + shiftY, startY: item.startY + shiftY, endY: item.endY + shiftY };
    const shiftPathY = path => path.replace(/([ML])\s*(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)/g,
      (match, command, x, y) => `${command} ${x} ${Number(y) + shiftY}`);
    const connectors = [...left.connectors, ...right.connectors].map(item => ({
      ...item,
      from: { x: item.from.x, y: item.from.y + shiftY },
      to: { x: item.to.x, y: item.to.y + shiftY },
      path: shiftPathY(item.path)
    }));

    const verticalExtent = Math.max(0, ...positions.map(item => item.orientation === 'vertical' ? tileLong / 2 : tileShort / 2));
    const actualMinY = Math.min(...positions.map(item => item.y - (item.orientation === 'vertical' ? tileLong : tileShort) / 2));
    const actualMaxY = Math.max(...positions.map(item => item.y + (item.orientation === 'vertical' ? tileLong : tileShort) / 2));
    const height = Math.max(Number(options.minHeight) || 285, actualMaxY + paddingY, verticalExtent * 2 + paddingY * 2);

    return {
      width: safeWidth,
      height,
      rootIndex,
      root: positions[rootIndex],
      positions,
      connectors,
      tileLong,
      tileShort,
      maxPerRow,
      minY: actualMinY,
      maxY: actualMaxY
    };
  }

  return { buildChainLayout };
});
