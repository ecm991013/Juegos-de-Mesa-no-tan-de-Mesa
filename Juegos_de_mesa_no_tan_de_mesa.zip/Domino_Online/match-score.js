'use strict';

(function attachDominoScore(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.DominoScoreboard = api;
})(typeof window !== 'undefined' ? window : globalThis, function createDominoScoreboard() {
  function buildStandings(gameData = {}) {
    const players = Array.isArray(gameData.players) ? gameData.players : [];
    const targetValue = Number(gameData.options?.pointsTarget ?? gameData.settings?.pointsTarget ?? 100);
    const target = Number.isFinite(targetValue) && targetValue > 0 ? targetValue : 100;
    let rows;

    if (gameData.options?.teamMode) {
      const teams = new Map();
      for (const player of players) {
        const key = Number.isInteger(player.team) ? player.team : 0;
        if (!teams.has(key)) teams.set(key, []);
        teams.get(key).push(player);
      }
      rows = [...teams.entries()].map(([team, members]) => ({
        key: `team-${team}`,
        team,
        label: `Pareja ${String.fromCharCode(65 + team)}`,
        detail: members.map(member => member.name).join(' + '),
        members: members.map(member => ({ name: String(member.name || 'Jugador'), avatar: String(member.avatar || 'avatar-01') })),
        // El servidor suma la misma puntuación a los dos integrantes. No se duplica.
        score: Math.max(0, ...members.map(member => Number(member.score) || 0))
      }));
    } else {
      rows = players.map((player, index) => ({
        key: String(player.id || `player-${index}`),
        team: player.team,
        label: String(player.name || `Jugador ${index + 1}`),
        detail: player.isAI ? 'Rival IA' : player.connected === false ? 'Desconectado' : 'Jugador',
        members: [{ name: String(player.name || `Jugador ${index + 1}`), avatar: String(player.avatar || 'avatar-01') }],
        score: Math.max(0, Number(player.score) || 0)
      }));
    }

    rows.sort((a, b) => b.score - a.score || a.label.localeCompare(b.label, 'es'));
    const top = rows[0]?.score ?? 0;
    return {
      target,
      rows,
      leaders: rows.filter(row => row.score === top),
      topScore: top,
      matchOver: !!gameData.matchOver
    };
  }

  return { buildStandings };
});
