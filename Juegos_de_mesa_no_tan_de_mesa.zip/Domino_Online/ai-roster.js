'use strict';

const AVATARS = Object.freeze([
  'avatar-01', 'avatar-02', 'avatar-03', 'avatar-04',
  'avatar-05', 'avatar-06', 'avatar-07', 'avatar-08'
]);

// Nombres ficticios: no dependen del nombre del archivo ni del retrato elegido.
const AI_ROSTER = Object.freeze([
  Object.freeze({ name: 'Don Jacinto', avatar: 'avatar-01' }),
  Object.freeze({ name: 'La Chispa', avatar: 'avatar-02' }),
  Object.freeze({ name: 'El Zurdo', avatar: 'avatar-03' }),
  Object.freeze({ name: 'Doña Mula', avatar: 'avatar-04' }),
  Object.freeze({ name: 'Capitán Doble', avatar: 'avatar-05' }),
  Object.freeze({ name: 'La Centella', avatar: 'avatar-06' }),
  Object.freeze({ name: 'Tito Seis', avatar: 'avatar-07' }),
  Object.freeze({ name: 'La Estratega', avatar: 'avatar-08' })
]);

function randomIndex(length, random) {
  const raw = Number(random());
  const value = Number.isFinite(raw) ? Math.min(0.999999, Math.max(0, raw)) : 0.5;
  return Math.floor(value * length);
}

function selectAIOpponents(count, excludedAvatar, random = Math.random) {
  const pool = AI_ROSTER.filter(entry => entry.avatar !== excludedAvatar).slice();
  const selected = [];
  const wanted = Math.max(0, Math.min(AVATARS.length - 1, Number(count) || 0));
  while (pool.length && selected.length < wanted) {
    selected.push(pool.splice(randomIndex(pool.length, random), 1)[0]);
  }
  return selected;
}

function selectLocalAvatars(count, excludedAvatar) {
  return AVATARS.filter(avatar => avatar !== excludedAvatar).slice(0, Math.max(0, Number(count) || 0));
}

module.exports = { AVATARS, AI_ROSTER, selectAIOpponents, selectLocalAvatars };
