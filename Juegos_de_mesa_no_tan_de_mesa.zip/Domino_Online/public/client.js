(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const readPreference = (key, fallback) => {
    try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; }
  };
  const savePreference = (key, value) => {
    try { localStorage.setItem(key, value); } catch { /* El juego sigue funcionando sin almacenamiento local. */ }
  };
  const VALID_SKINS = ['classic', 'wood', 'obsidian', 'marble', 'gold', 'neon', 'ocean', 'caribe'];
  const VALID_TABLES = ['green', 'purple', 'blue', 'red', 'wood'];
  const AVATAR_NAMES = {
    'abuelo-rafa': 'Rafa', 'la-paisa': 'La Paisa', 'profe-lee': 'Profe Lee', 'camila': 'Camila',
    'tomas': 'Tomás', 'dona-clara': 'Doña Clara', 'santiago': 'Santiago', 'valeria': 'Valeria'
  };
  const state = {
    mode: 'ai', avatar: AVATAR_NAMES[readPreference('domino-avatar', 'abuelo-rafa')] ? readPreference('domino-avatar', 'abuelo-rafa') : 'abuelo-rafa',
    skin: VALID_SKINS.includes(readPreference('domino-skin', 'classic')) ? readPreference('domino-skin', 'classic') : 'classic',
    table: VALID_TABLES.includes(readPreference('domino-table', 'green')) ? readPreference('domino-table', 'green') : 'green',
    socket: null, playerId: null, roomCode: null, selectedTileId: null, game: null,
    sound: readPreference('domino-sound', 'on') !== 'off', audio: null, toastTimer: null
  };

  let socket = null;
  try {
    if (typeof window.io === 'function') {
      socket = window.io({ path: '/domino/socket.io', transports: ['websocket', 'polling'], reconnection: true, timeout: 10000 });
    }
  } catch (error) {
    console.error('[Dominó] No se pudo inicializar Socket.IO:', error);
  }
  state.socket = socket;

  function setConnectionStatus(status, label) {
    const badge = $('connectionStatus');
    if (!badge) return;
    badge.dataset.state = status;
    const text = badge.querySelector('span');
    if (text) text.textContent = label;
    badge.title = label;
  }

  function emitAction(eventName, payload) {
    if (!socket) {
      toast('No se cargó el sistema de conexión. Recarga Dominó Club.', 'error');
      setConnectionStatus('offline', 'Sin sistema de conexión');
      return false;
    }
    if (!socket.connected) {
      toast('Conectando con la mesa… intenta de nuevo en un momento.', 'error');
      return false;
    }
    socket.emit(eventName, payload);
    return true;
  }


  function settingsPayload() {
    return {
      name: $('playerName').value.trim() || 'Jugador', avatar: state.avatar,
      playerCount: Number($('playerCount').value), difficulty: $('difficulty').value,
      pointsTarget: Number($('pointsTarget').value), ruleMode: $('ruleMode').value,
      teamMode: $('teamMode').checked
    };
  }

  function toast(message, kind = 'info') {
    const el = $('toast');
    el.textContent = message;
    el.className = `toast visible ${kind}`;
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => { el.className = 'toast'; }, 2700);
  }

  function playSound(type = 'tap') {
    if (!state.sound) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      state.audio ||= new AudioContext();
      if (state.audio.state === 'suspended') state.audio.resume();
      const oscillator = state.audio.createOscillator();
      const gain = state.audio.createGain();
      const now = state.audio.currentTime;
      const tones = { tap: [480, .055], place: [620, .12], draw: [370, .1], pass: [260, .12], win: [740, .25], error: [170, .14] };
      const [freq, duration] = tones[type] || tones.tap;
      oscillator.type = type === 'error' ? 'triangle' : 'sine';
      oscillator.frequency.setValueAtTime(freq, now);
      if (type === 'place') oscillator.frequency.exponentialRampToValueAtTime(850, now + duration);
      gain.gain.setValueAtTime(.0001, now);
      gain.gain.exponentialRampToValueAtTime(.08, now + .012);
      gain.gain.exponentialRampToValueAtTime(.0001, now + duration);
      oscillator.connect(gain).connect(state.audio.destination);
      oscillator.start(now);
      oscillator.stop(now + duration + .02);
    } catch { /* El audio no debe bloquear una jugada. */ }
  }

  function setSound(enabled) {
    state.sound = !!enabled;
    savePreference('domino-sound', state.sound ? 'on' : 'off');
    $('soundToggle').classList.toggle('muted', !state.sound);
    $('gameSoundToggle')?.classList.toggle('muted', !state.sound);
    toast(state.sound ? 'Sonido activado' : 'Sonido silenciado');
    playSound('tap');
  }

  function setMode(mode) {
    state.mode = ['ai', 'online', 'local'].includes(mode) ? mode : 'ai';
    document.querySelectorAll('.mode-card').forEach(button => {
      const active = button.dataset.mode === state.mode;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    $('difficultyField').classList.toggle('hidden', mode !== 'ai');
    $('teamRow').classList.toggle('hidden', Number($('playerCount').value) !== 4);
    $('onlineOptions').classList.toggle('hidden', mode !== 'online');
    $('startButton').classList.toggle('hidden', mode === 'online');
  }

  document.querySelectorAll('.mode-card').forEach(button => button.addEventListener('click', () => {
    playSound('tap'); setMode(button.dataset.mode);
  }));
  $('playerCount').addEventListener('change', () => $('teamRow').classList.toggle('hidden', Number($('playerCount').value) !== 4));

  document.querySelectorAll('.avatar-choice').forEach(button => button.addEventListener('click', () => {
    state.avatar = button.dataset.avatar;
    savePreference('domino-avatar', state.avatar);
    document.querySelectorAll('.avatar-choice').forEach(item => { const selected = item === button; item.classList.toggle('selected', selected); item.setAttribute('aria-pressed', String(selected)); });
    playSound('tap');
  }));
  document.querySelectorAll('.skin-choice').forEach(button => button.addEventListener('click', () => {
    state.skin = VALID_SKINS.includes(button.dataset.skin) ? button.dataset.skin : 'classic';
    savePreference('domino-skin', state.skin);
    document.querySelectorAll('.skin-choice').forEach(item => { const selected = item === button; item.classList.toggle('selected', selected); item.setAttribute('aria-pressed', String(selected)); });
    applyGameSkin();
    playSound('tap');
  }));
  document.querySelectorAll('.table-choice').forEach(button => button.addEventListener('click', () => {
    state.table = VALID_TABLES.includes(button.dataset.table) ? button.dataset.table : 'green';
    savePreference('domino-table', state.table);
    document.querySelectorAll('.table-choice').forEach(item => { const selected = item === button; item.classList.toggle('selected', selected); item.setAttribute('aria-pressed', String(selected)); });
    $('gameTable').className = `table-surface table-${state.table}`;
    playSound('tap');
  }));

  function applyGameSkin() {
    const root = $('gameView');
    VALID_SKINS.forEach(skin => root.classList.remove(`skin-${skin}`));
    root.classList.add(`skin-${state.skin}`);
  }

  function showView(view) {
    $('homeView').classList.toggle('hidden', view !== 'home');
    $('lobbyView').classList.toggle('hidden', view !== 'lobby');
    $('gameView').classList.toggle('hidden', view !== 'game');
  }

  function showLobbyConfig() {
    $('lobbyConfigPanel').classList.remove('hidden');
    $('onlineLobbyPanel').classList.add('hidden');
    showView('lobby');
  }

  function openLobby(mode = 'ai') {
    setMode(mode);
    showLobbyConfig();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function joinPayload() {
    return { ...settingsPayload(), code: $('roomCodeInput').value.trim().toUpperCase() };
  }

  $('startButton').addEventListener('click', () => {
    const payload = settingsPayload();
    if (emitAction(state.mode === 'ai' ? 'createAI' : 'createLocal', payload)) playSound('tap');
  });

  $('createRoomButton').addEventListener('click', () => {
    if (emitAction('createOnline', settingsPayload())) playSound('tap');
  });
  $('joinRoomButton').addEventListener('click', () => {
    const code = $('roomCodeInput').value.trim().toUpperCase();
    if (code.length < 4) return toast('Escribe un código de sala válido.', 'error');
    if (emitAction('joinOnline', joinPayload())) playSound('tap');
  });
  $('roomCodeInput').addEventListener('input', event => { event.target.value = event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });
  $('copyCodeButton').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(state.roomCode || $('lobbyCode').textContent); toast('Código copiado'); }
    catch { toast(`Código: ${state.roomCode}`); }
  });
  $('startOnlineButton').addEventListener('click', () => emitAction('startOnline'));
  $('cancelLobbyButton').addEventListener('click', returnToLobbyConfig);
  $('leaveGameButton').addEventListener('click', leaveToSetup);
  $('rulesButton').addEventListener('click', () => $('rulesModal').classList.remove('hidden'));
  $('closeRules').addEventListener('click', () => $('rulesModal').classList.add('hidden'));
  $('rulesModal').addEventListener('click', event => { if (event.target === $('rulesModal')) $('rulesModal').classList.add('hidden'); });
  $('soundToggle').addEventListener('click', () => setSound(!state.sound));
  $('gameSoundToggle').addEventListener('click', () => setSound(!state.sound));

  function leaveToSetup() {
    socket?.emit('leaveRoom');
    state.playerId = null; state.roomCode = null; state.game = null; state.selectedTileId = null;
    $('onlineLobbyPanel').classList.add('hidden');
    $('lobbyConfigPanel').classList.remove('hidden');
    showView('home');
  }

  function returnToLobbyConfig() {
    socket?.emit('leaveRoom');
    state.playerId = null; state.roomCode = null; state.game = null;
    $('onlineLobbyPanel').classList.add('hidden');
    $('lobbyConfigPanel').classList.remove('hidden');
    showView('lobby');
  }

  document.querySelectorAll('[data-home-mode]').forEach(button => {
    button.addEventListener('click', () => {
      playSound('tap');
      openLobby(button.dataset.homeMode);
    });
  });
  $('homeQuickPlayButton').addEventListener('click', () => openLobby('ai'));
  $('homeCustomizeButton').addEventListener('click', () => {
    openLobby('ai');
    setTimeout(() => $('customizePanel')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 80);
  });
  $('homeRulesButton').addEventListener('click', () => $('rulesModal').classList.remove('hidden'));
  $('backHomeButton').addEventListener('click', () => {
    showView('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  function renderLobby(lobby) {
    $('lobbyConfigPanel').classList.add('hidden');
    $('onlineLobbyPanel').classList.remove('hidden');
    showView('lobby');
    state.roomCode = lobby.code;
    $('lobbyCode').textContent = lobby.code;
    const currentIsHost = state.playerId === lobby.hostId;
    $('startOnlineButton').classList.toggle('hidden', !currentIsHost);
    $('startOnlineButton').disabled = !currentIsHost || lobby.playerCount < 2;
    $('lobbyHint').textContent = currentIsHost
      ? `${lobby.playerCount} de ${lobby.maxPlayers} jugadores. Inicia cuando estén listos.`
      : `Esperando a ${lobby.hostName}, anfitrión de la sala.`;
    const players = lobby.players.map(player => `
      <div class="lobby-player"><img src="/domino/assets/avatars/${escapeHtml(player.avatar)}.webp" alt=""><div><span>${escapeHtml(player.name)}</span><small>${player.id === lobby.hostId ? 'Anfitrión' : 'Listo para jugar'}</small></div></div>`).join('');
    const slots = Array.from({ length: Math.max(0, lobby.maxPlayers - lobby.playerCount) }, () => '<div class="lobby-player empty">Esperando jugador…</div>').join('');
    $('lobbyPlayers').innerHTML = players + slots;
    showView('lobby');
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  }

  if (!socket) setConnectionStatus('offline', 'Sin conexión con el servidor');
  socket?.on('connect', () => { setConnectionStatus('online', 'Conectado a Dominó Club'); toast('Conectado a Dominó Club'); });
  socket?.on('connect_error', error => { setConnectionStatus('offline', 'Reconectando…'); console.warn('[Dominó] Error de conexión:', error?.message || error); toast('Conexión inestable. Intentando reconectar…', 'error'); });
  socket?.on('joined', data => {
    state.roomCode = data.code;
    state.playerId = data.playerId;
    if (data.mode === 'online') toast(`Sala ${data.code} creada. Comparte el código.`);
  });
  socket?.on('lobbyState', renderLobby);
  socket?.on('notice', data => { toast(data.message, data.kind); playSound(data.kind === 'error' ? 'error' : 'tap'); });
  socket?.on('gameState', data => {
    state.game = data;
    state.playerId = data.you;
    state.roomCode = data.code;
    state.selectedTileId = null;
    renderGame(data);
    showView('game');
  });
  socket?.on('disconnect', () => { setConnectionStatus('offline', 'Conexión interrumpida · reconectando'); toast('Se perdió la conexión con la mesa.', 'error'); });

  const DOTS = {
    0: [], 1: [[2, 2]], 2: [[1, 1], [3, 3]], 3: [[1, 1], [2, 2], [3, 3]],
    4: [[1, 1], [1, 3], [3, 1], [3, 3]], 5: [[1, 1], [1, 3], [2, 2], [3, 1], [3, 3]],
    6: [[1, 1], [2, 1], [3, 1], [1, 3], [2, 3], [3, 3]]
  };

  function pips(value) {
    return `<span class="pip-layout">${(DOTS[value] || []).map(([row, col]) => `<i style="grid-area:${row}/${col}"></i>`).join('')}</span>`;
  }

  function tileMarkup(tile, orientation = 'horizontal', extraClass = '') {
    return `<div class="domino-tile ${orientation} ${tile.a === tile.b ? 'double' : ''} ${extraClass}" data-tile-id="${escapeHtml(tile.id)}"><span class="tile-half">${pips(tile.a)}</span><span class="tile-half">${pips(tile.b)}</span></div>`;
  }

  function renderPlayerCards(data) {
    $('playersStrip').innerHTML = data.players.map(player => `
      <div class="player-card ${player.id === data.turnPlayerId ? 'active' : ''}">
        <img src="/domino/assets/avatars/${escapeHtml(player.avatar)}.webp" alt="Retrato de ${escapeHtml(player.name)}">
        <div class="player-meta"><b>${escapeHtml(player.name)}${player.id === data.you ? ' · Tú' : ''}</b><small>${player.isAI ? `IA · ${difficultyLabel(player.difficulty)}` : player.connected ? 'Conectado' : 'Desconectado'} · ${player.handCount} fichas</small></div>
        <span class="player-score">${player.score}</span>
      </div>`).join('');
  }

  function difficultyLabel(level) { return ({ easy: 'Fácil', normal: 'Normal', hard: 'Difícil' })[level] || 'Normal'; }

  function renderGame(data) {
    const root = $('gameView');
    root.className = `game-view skin-${state.skin}`;
    $('gameTable').className = `table-surface table-${state.table}`;
    $('gameCode').textContent = data.mode === 'online' ? `· Sala ${data.code}` : data.mode === 'local' ? '· Misma pantalla' : '· Contra IA';
    $('boneyardCount').textContent = `Pozo: ${data.boneyardCount}`;
    $('turnBanner').textContent = data.isYourTurn ? (data.localHotseat ? `Turno de ${data.players.find(p => p.id === data.you)?.name || 'Jugador'}` : 'Es tu turno') : `Turno de ${data.turnPlayerName}`;
    renderPlayerCards(data);

    const chain = $('dominoChain');
    $('chainEmpty').classList.toggle('hidden', data.chain.length > 0);
    chain.innerHTML = data.chain.map(tile => tileMarkup(tile, 'horizontal')).join('');

    const current = data.players.find(p => p.id === data.you);
    $('handTitle').textContent = data.localHotseat ? `Fichas de ${current?.name || 'jugador'}` : 'Tus fichas';
    $('handCount').textContent = `${data.hand.length} fichas`;
    const legal = data.isYourTurn ? data.legalMoves : [];
    const hand = [...data.hand].sort((a, b) => (a.a + a.b) - (b.a + b.b) || a.a - b.a);
    $('handTiles').innerHTML = hand.map(tile => {
      const selectable = legal.some(move => move.tileId === tile.id);
      return `<button type="button" class="domino-tile vertical ${tile.a === tile.b ? 'double' : ''} hand-tile ${tile.id === state.selectedTileId ? 'selected' : ''}" data-hand-id="${escapeHtml(tile.id)}" ${!data.isYourTurn || !selectable ? 'disabled' : ''} aria-label="Ficha ${tile.a} y ${tile.b}"><span class="tile-half">${pips(tile.a)}</span><span class="tile-half">${pips(tile.b)}</span></button>`;
    }).join('');

    const selected = hand.find(tile => tile.id === state.selectedTileId);
    const moves = selected ? legal.filter(move => move.tileId === selected.id) : [];
    $('moveControls').classList.toggle('hidden', !selected || !moves.length);
    $('selectedTileLabel').textContent = selected ? `${selected.a} | ${selected.b}` : 'Ficha seleccionada';
    document.querySelectorAll('.move-button').forEach(button => {
      const match = moves.some(move => move.side === button.dataset.side);
      button.classList.toggle('hidden', !match);
    });
    const hasMoves = legal.length > 0;
    $('drawButton').disabled = !data.isYourTurn || hasMoves || data.options.ruleMode !== 'draw' || data.boneyardCount === 0 || data.roundOver;
    $('drawButton').textContent = data.boneyardCount ? `Robar ficha · ${data.boneyardCount}` : 'Pozo vacío';
    $('passButton').disabled = !data.isYourTurn || hasMoves || (data.options.ruleMode === 'draw' && data.boneyardCount > 0) || data.roundOver;

    if (data.roundOver && data.result) renderResult(data.result, data);
    else $('resultPanel').classList.add('hidden');

    if (data.localHotseat) setMessage('Modo de misma pantalla: pasa el dispositivo al jugador cuyo turno aparece arriba.', 'info');
    else if (data.isYourTurn) setMessage(data.openingPending ? 'Abre la mesa con la ficha de salida indicada.' : hasMoves ? 'Selecciona una ficha y elige uno de los extremos.' : data.options.ruleMode === 'draw' && data.boneyardCount ? 'No tienes jugada. Roba del pozo hasta conseguir una ficha válida.' : 'No tienes jugada. Puedes pasar el turno.', 'info');
    else setMessage(`Esperando la jugada de ${data.turnPlayerName}.`, 'info');
  }

  function renderResult(result, data) {
    const el = $('resultPanel');
    el.classList.remove('hidden');
    const reason = result.reason === 'empty' ? 'se quedó sin fichas' : 'cerró la partida con menos puntos';
    const scores = result.scores.map(item => `<div class="score-row"><span>${escapeHtml(item.name)}</span><b>${item.score} pts</b><small>${item.remaining} en mano</small></div>`).join('');
    el.innerHTML = `<h2>${escapeHtml(result.winnerName)} ganó la ronda</h2><p>${escapeHtml(result.winnerName)} ${reason}. Sumó ${result.awarded} puntos.${result.matchOver ? ' ¡También alcanzó la meta de la partida!' : ''}</p><div class="score-list">${scores}</div><button class="primary-button" id="newRoundButton" type="button">${result.matchOver ? 'Volver a jugar' : 'Siguiente ronda'} ↗</button>`;
    $('newRoundButton').addEventListener('click', () => emitAction('newRound'));
    playSound('win');
  }

  function setMessage(message, kind) {
    $('gameMessage').textContent = message;
    $('gameMessage').className = `game-message ${kind || ''}`;
  }

  // Drag & drop táctil y con ratón: una ficha válida se puede soltar
  // directamente sobre la cadena. Si hay dos extremos posibles, el lado
  // donde se suelta determina izquierda o derecha.
  let activeTileDrag = null;
  let suppressTileClickUntil = 0;
  let dragGhost = null;

  function clearTileDragVisuals() {
    dragGhost?.remove?.();
    dragGhost = null;
    const stage = $('chainStage');
    stage?.classList.remove('drop-active', 'drop-left', 'drop-right', 'drop-center');
    const hint = $('dropGuide');
    if (hint) hint.textContent = 'Arrastra una ficha hasta la mesa';
  }

  function beginTileDrag(event) {
    const button = event.target?.closest?.('[data-hand-id]');
    if (!button || button.disabled || (event.button !== undefined && event.button !== 0)) return;
    activeTileDrag = {
      id: button.dataset.handId,
      element: button,
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      moved: false
    };
  }

  function moveTileDrag(event) {
    if (!activeTileDrag || (activeTileDrag.pointerId !== undefined && event.pointerId !== activeTileDrag.pointerId)) return;
    const dx = event.clientX - activeTileDrag.startX;
    const dy = event.clientY - activeTileDrag.startY;
    if (!activeTileDrag.moved && Math.hypot(dx, dy) < 8) return;
    activeTileDrag.moved = true;
    event.preventDefault?.();

    if (!dragGhost && activeTileDrag.element?.cloneNode) {
      dragGhost = activeTileDrag.element.cloneNode(true);
      dragGhost.removeAttribute?.('data-hand-id');
      dragGhost.disabled = true;
      dragGhost.classList.add('drag-ghost');
      document.body.appendChild(dragGhost);
    }
    if (dragGhost) {
      dragGhost.style.left = `${event.clientX}px`;
      dragGhost.style.top = `${event.clientY}px`;
    }

    const stage = $('chainStage');
    const rect = stage?.getBoundingClientRect?.();
    const overStage = !!rect && event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
    stage?.classList.toggle('drop-active', overStage);
    if (overStage) {
      const legal = (state.game?.legalMoves || []).filter(move => move.tileId === activeTileDrag.id);
      const centerMove = legal.find(move => move.side === 'center');
      const side = centerMove ? 'center' : event.clientX < rect.left + rect.width / 2 ? 'left' : 'right';
      stage.classList.toggle('drop-center', side === 'center');
      stage.classList.toggle('drop-left', side === 'left');
      stage.classList.toggle('drop-right', side === 'right');
      const hint = $('dropGuide');
      if (hint) hint.textContent = side === 'center' ? 'Suelta para abrir la mesa' : side === 'left' ? 'Suelta en el extremo izquierdo' : 'Suelta en el extremo derecho';
    } else {
      stage?.classList.remove('drop-left', 'drop-right', 'drop-center');
    }
  }

  function finishTileDrag(event) {
    if (!activeTileDrag || (activeTileDrag.pointerId !== undefined && event.pointerId !== activeTileDrag.pointerId)) return;
    const drag = activeTileDrag;
    activeTileDrag = null;
    if (!drag.moved) { clearTileDragVisuals(); return; }
    event.preventDefault?.();
    suppressTileClickUntil = Date.now() + 450;

    const stage = $('chainStage');
    const rect = stage?.getBoundingClientRect?.();
    const overStage = !!rect && event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
    if (overStage && state.game?.isYourTurn) {
      const moves = (state.game.legalMoves || []).filter(move => move.tileId === drag.id);
      const centerMove = moves.find(move => move.side === 'center');
      const preferredSide = event.clientX < rect.left + rect.width / 2 ? 'left' : 'right';
      const chosenMove = centerMove || moves.find(move => move.side === preferredSide) || moves[0];
      if (chosenMove && emitAction('playTile', { tileId: drag.id, side: chosenMove.side })) {
        state.selectedTileId = null;
        setMessage(chosenMove.side === 'center' ? 'Ficha enviada para abrir la mesa.' : `Ficha enviada al extremo ${chosenMove.side === 'left' ? 'izquierdo' : 'derecho'}.`, 'success');
        playSound('place');
      } else if (!chosenMove) {
        toast('Esa ficha no tiene una jugada válida en este momento.', 'error');
      }
    } else {
      state.selectedTileId = drag.id;
      renderGame(state.game);
    }
    clearTileDragVisuals();
  }

  $('handTiles').addEventListener('pointerdown', beginTileDrag);
  if (typeof document.addEventListener === 'function') {
    document.addEventListener('pointermove', moveTileDrag, { passive: false });
    document.addEventListener('pointerup', finishTileDrag);
    document.addEventListener('pointercancel', finishTileDrag);
  }

  $('handTiles').addEventListener('click', event => {
    if (Date.now() < suppressTileClickUntil) { event.preventDefault?.(); return; }
    const button = event.target.closest('[data-hand-id]');
    if (!button || button.disabled) return;
    state.selectedTileId = button.dataset.handId;
    playSound('tap');
    renderGame(state.game);
  });
  $('moveControls').addEventListener('click', event => {
    const button = event.target.closest('[data-side]');
    if (!button || !state.selectedTileId || !state.game?.isYourTurn) return;
    if (emitAction('playTile', { tileId: state.selectedTileId, side: button.dataset.side })) { state.selectedTileId = null; playSound('place'); }
  });
  $('drawButton').addEventListener('click', () => { if (emitAction('drawTile')) playSound('draw'); });
  $('passButton').addEventListener('click', () => { if (emitAction('passTurn')) playSound('pass'); });

  // Restore appearance preferences on load.
  document.querySelectorAll('.avatar-choice').forEach(button => {
    const selected = button.dataset.avatar === state.avatar;
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  document.querySelectorAll('.skin-choice').forEach(button => {
    const selected = button.dataset.skin === state.skin;
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  document.querySelectorAll('.table-choice').forEach(button => {
    const selected = button.dataset.table === state.table;
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  $('soundToggle').classList.toggle('muted', !state.sound);
  setMode('ai');
  if (!socket) setConnectionStatus('offline', 'Sin conexión con el servidor');
})();
