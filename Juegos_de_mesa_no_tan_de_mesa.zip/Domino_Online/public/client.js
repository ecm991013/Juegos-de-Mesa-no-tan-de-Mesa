(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const AVATAR_NAMES = {
    'abuelo-rafa': 'Rafa', 'la-paisa': 'La Paisa', 'profe-lee': 'Profe Lee', 'camila': 'Camila',
    'tomas': 'Tomás', 'dona-clara': 'Doña Clara', 'santiago': 'Santiago', 'valeria': 'Valeria'
  };
  const state = {
    mode: 'ai', avatar: localStorage.getItem('domino-avatar') || 'abuelo-rafa',
    skin: localStorage.getItem('domino-skin') || 'classic', table: localStorage.getItem('domino-table') || 'green',
    socket: null, playerId: null, roomCode: null, selectedTileId: null, game: null,
    sound: localStorage.getItem('domino-sound') !== 'off', audio: null, toastTimer: null
  };

  const socket = window.io ? io({ path: '/domino/socket.io', transports: ['websocket', 'polling'], reconnection: true }) : null;
  state.socket = socket;

  function settingsPayload() {
    return {
      name: $('playerName').value.trim() || 'Jugador', avatar: state.avatar,
      playerCount: Number($('playerCount').value), difficulty: $('difficulty').value,
      pointsTarget: Number($('pointsTarget').value), ruleMode: $('ruleMode').value,
      teamMode: $('teamMode').checked
    };
  }

  function toast(message, kind = 'info') {
    const el = $('toast');
    el.textContent = message;
    el.className = `toast visible ${kind}`;
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => { el.className = 'toast'; }, 2700);
  }

  function playSound(type = 'tap') {
    if (!state.sound) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      state.audio ||= new AudioContext();
      if (state.audio.state === 'suspended') state.audio.resume();
      const oscillator = state.audio.createOscillator();
      const gain = state.audio.createGain();
      const now = state.audio.currentTime;
      const tones = { tap: [480, .055], place: [620, .12], draw: [370, .1], pass: [260, .12], win: [740, .25], error: [170, .14] };
      const [freq, duration] = tones[type] || tones.tap;
      oscillator.type = type === 'error' ? 'triangle' : 'sine';
      oscillator.frequency.setValueAtTime(freq, now);
      if (type === 'place') oscillator.frequency.exponentialRampToValueAtTime(850, now + duration);
      gain.gain.setValueAtTime(.0001, now);
      gain.gain.exponentialRampToValueAtTime(.08, now + .012);
      gain.gain.exponentialRampToValueAtTime(.0001, now + duration);
      oscillator.connect(gain).connect(state.audio.destination);
      oscillator.start(now);
      oscillator.stop(now + duration + .02);
    } catch { /* El audio no debe bloquear una jugada. */ }
  }

  function setSound(enabled) {
    state.sound = !!enabled;
    localStorage.setItem('domino-sound', state.sound ? 'on' : 'off');
    $('soundToggle').classList.toggle('muted', !state.sound);
    $('gameSoundToggle')?.classList.toggle('muted', !state.sound);
    toast(state.sound ? 'Sonido activado' : 'Sonido silenciado');
    playSound('tap');
  }

  function setMode(mode) {
    state.mode = mode;
    document.querySelectorAll('.mode-card').forEach(button => button.classList.toggle('active', button.dataset.mode === mode));
    $('difficultyField').classList.toggle('hidden', mode !== 'ai');
    $('teamRow').classList.toggle('hidden', mode === 'online' ? Number($('playerCount').value) !== 4 : Number($('playerCount').value) !== 4);
    $('onlineOptions').classList.toggle('hidden', mode !== 'online');
    $('startButton').classList.toggle('hidden', mode === 'online');
  }

  document.querySelectorAll('.mode-card').forEach(button => button.addEventListener('click', () => {
    playSound('tap'); setMode(button.dataset.mode);
  }));
  $('playerCount').addEventListener('change', () => $('teamRow').classList.toggle('hidden', Number($('playerCount').value) !== 4));

  document.querySelectorAll('.avatar-choice').forEach(button => button.addEventListener('click', () => {
    state.avatar = button.dataset.avatar;
    localStorage.setItem('domino-avatar', state.avatar);
    document.querySelectorAll('.avatar-choice').forEach(item => item.classList.toggle('selected', item === button));
    playSound('tap');
  }));
  document.querySelectorAll('.skin-choice').forEach(button => button.addEventListener('click', () => {
    state.skin = button.dataset.skin;
    localStorage.setItem('domino-skin', state.skin);
    document.querySelectorAll('.skin-choice').forEach(item => item.classList.toggle('selected', item === button));
    $('gameView').classList.toggle(`skin-${state.skin}`, true);
    playSound('tap');
  }));
  document.querySelectorAll('.table-choice').forEach(button => button.addEventListener('click', () => {
    state.table = button.dataset.table;
    localStorage.setItem('domino-table', state.table);
    document.querySelectorAll('.table-choice').forEach(item => item.classList.toggle('selected', item === button));
    $('gameTable').className = `table-surface table-${state.table}`;
    playSound('tap');
  }));

  function showView(view) {
    $('setupView').classList.toggle('hidden', view !== 'setup');
    $('lobbyView').classList.toggle('hidden', view !== 'lobby');
    $('gameView').classList.toggle('hidden', view !== 'game');
  }

  function joinPayload() {
    return { ...settingsPayload(), code: $('roomCodeInput').value.trim().toUpperCase() };
  }

  $('startButton').addEventListener('click', () => {
    if (!socket) return toast('No se pudo conectar al servidor. Recarga la página.', 'error');
    const payload = settingsPayload();
    if (state.mode === 'ai') socket.emit('createAI', payload);
    else socket.emit('createLocal', payload);
    playSound('tap');
  });

  $('createRoomButton').addEventListener('click', () => {
    if (!socket) return toast('No se pudo conectar al servidor.', 'error');
    socket.emit('createOnline', settingsPayload());
    playSound('tap');
  });
  $('joinRoomButton').addEventListener('click', () => {
    if (!socket) return toast('No se pudo conectar al servidor.', 'error');
    const code = $('roomCodeInput').value.trim().toUpperCase();
    if (code.length < 4) return toast('Escribe un código de sala válido.', 'error');
    socket.emit('joinOnline', joinPayload());
    playSound('tap');
  });
  $('roomCodeInput').addEventListener('input', event => { event.target.value = event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });
  $('copyCodeButton').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(state.roomCode || $('lobbyCode').textContent); toast('Código copiado'); }
    catch { toast(`Código: ${state.roomCode}`); }
  });
  $('startOnlineButton').addEventListener('click', () => socket?.emit('startOnline'));
  $('cancelLobbyButton').addEventListener('click', leaveToSetup);
  $('leaveGameButton').addEventListener('click', leaveToSetup);
  $('rulesButton').addEventListener('click', () => $('rulesModal').classList.remove('hidden'));
  $('closeRules').addEventListener('click', () => $('rulesModal').classList.add('hidden'));
  $('rulesModal').addEventListener('click', event => { if (event.target === $('rulesModal')) $('rulesModal').classList.add('hidden'); });
  $('soundToggle').addEventListener('click', () => setSound(!state.sound));
  $('gameSoundToggle').addEventListener('click', () => setSound(!state.sound));

  function leaveToSetup() {
    socket?.emit('leaveRoom');
    state.playerId = null; state.roomCode = null; state.game = null; state.selectedTileId = null;
    showView('setup');
  }

  function renderLobby(lobby) {
    state.roomCode = lobby.code;
    $('lobbyCode').textContent = lobby.code;
    const currentIsHost = state.playerId === lobby.hostId;
    $('startOnlineButton').classList.toggle('hidden', !currentIsHost);
    $('lobbyHint').textContent = currentIsHost
      ? `${lobby.playerCount} de ${lobby.maxPlayers} jugadores. Inicia cuando estén listos.`
      : `Esperando a ${lobby.hostName}, anfitrión de la sala.`;
    const players = lobby.players.map(player => `
      <div class="lobby-player"><img src="/domino/assets/avatars/${escapeHtml(player.avatar)}.webp" alt=""><div><span>${escapeHtml(player.name)}</span><small>${player.id === lobby.hostId ? 'Anfitrión' : 'Listo para jugar'}</small></div></div>`).join('');
    const slots = Array.from({ length: Math.max(0, lobby.maxPlayers - lobby.playerCount) }, () => '<div class="lobby-player empty">Esperando jugador…</div>').join('');
    $('lobbyPlayers').innerHTML = players + slots;
    showView('lobby');
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  }

  socket?.on('connect', () => { toast('Conectado a Dominó Club'); });
  socket?.on('connect_error', () => toast('Conexión inestable. Intentando reconectar…', 'error'));
  socket?.on('joined', data => {
    state.roomCode = data.code;
    state.playerId = data.playerId;
    if (data.mode === 'online') toast(`Sala ${data.code} creada. Comparte el código.`);
  });
  socket?.on('lobbyState', renderLobby);
  socket?.on('notice', data => { toast(data.message, data.kind); playSound(data.kind === 'error' ? 'error' : 'tap'); });
  socket?.on('gameState', data => {
    state.game = data;
    state.playerId = data.you;
    state.roomCode = data.code;
    state.selectedTileId = null;
    renderGame(data);
    showView('game');
  });
  socket?.on('disconnect', () => toast('Se perdió la conexión con la mesa.', 'error'));

  const DOTS = {
    0: [], 1: [[2, 2]], 2: [[1, 1], [3, 3]], 3: [[1, 1], [2, 2], [3, 3]],
    4: [[1, 1], [1, 3], [3, 1], [3, 3]], 5: [[1, 1], [1, 3], [2, 2], [3, 1], [3, 3]],
    6: [[1, 1], [2, 1], [3, 1], [1, 3], [2, 3], [3, 3]]
  };

  function pips(value) {
    return `<span class="pip-layout">${(DOTS[value] || []).map(([row, col]) => `<i style="grid-area:${row}/${col}"></i>`).join('')}</span>`;
  }

  function tileMarkup(tile, orientation = 'horizontal', extraClass = '') {
    return `<div class="domino-tile ${orientation} ${tile.a === tile.b ? 'double' : ''} ${extraClass}" data-tile-id="${escapeHtml(tile.id)}"><span class="tile-half">${pips(tile.a)}</span><span class="tile-half">${pips(tile.b)}</span></div>`;
  }

  function renderPlayerCards(data) {
    $('playersStrip').innerHTML = data.players.map(player => `
      <div class="player-card ${player.id === data.turnPlayerId ? 'active' : ''}">
        <img src="/domino/assets/avatars/${escapeHtml(player.avatar)}.webp" alt="Retrato de ${escapeHtml(player.name)}">
        <div class="player-meta"><b>${escapeHtml(player.name)}${player.id === data.you ? ' · Tú' : ''}</b><small>${player.isAI ? `IA · ${difficultyLabel(player.difficulty)}` : player.connected ? 'Conectado' : 'Desconectado'} · ${player.handCount} fichas</small></div>
        <span class="player-score">${player.score}</span>
      </div>`).join('');
  }

  function difficultyLabel(level) { return ({ easy: 'Fácil', normal: 'Normal', hard: 'Difícil' })[level] || 'Normal'; }

  function renderGame(data) {
    const root = $('gameView');
    root.className = `game-view skin-${state.skin}`;
    $('gameTable').className = `table-surface table-${state.table}`;
    $('gameCode').textContent = data.mode === 'online' ? `· Sala ${data.code}` : data.mode === 'local' ? '· Misma pantalla' : '· Contra IA';
    $('boneyardCount').textContent = `Pozo: ${data.boneyardCount}`;
    $('turnBanner').textContent = data.isYourTurn ? (data.localHotseat ? `Turno de ${data.players.find(p => p.id === data.you)?.name || 'Jugador'}` : 'Es tu turno') : `Turno de ${data.turnPlayerName}`;
    renderPlayerCards(data);

    const chain = $('dominoChain');
    $('chainEmpty').classList.toggle('hidden', data.chain.length > 0);
    chain.innerHTML = data.chain.map(tile => tileMarkup(tile, 'horizontal')).join('');

    const current = data.players.find(p => p.id === data.you);
    $('handTitle').textContent = data.localHotseat ? `Fichas de ${current?.name || 'jugador'}` : 'Tus fichas';
    $('handCount').textContent = `${data.hand.length} fichas`;
    const legal = data.isYourTurn ? data.legalMoves : [];
    const hand = [...data.hand].sort((a, b) => (a.a + a.b) - (b.a + b.b) || a.a - b.a);
    $('handTiles').innerHTML = hand.map(tile => {
      const selectable = legal.some(move => move.tileId === tile.id);
      return `<button type="button" class="domino-tile vertical ${tile.a === tile.b ? 'double' : ''} hand-tile ${tile.id === state.selectedTileId ? 'selected' : ''}" data-hand-id="${escapeHtml(tile.id)}" ${!data.isYourTurn || !selectable ? 'disabled' : ''} aria-label="Ficha ${tile.a} y ${tile.b}"><span class="tile-half">${pips(tile.a)}</span><span class="tile-half">${pips(tile.b)}</span></button>`;
    }).join('');

    const selected = hand.find(tile => tile.id === state.selectedTileId);
    const moves = selected ? legal.filter(move => move.tileId === selected.id) : [];
    $('moveControls').classList.toggle('hidden', !selected || !moves.length);
    $('selectedTileLabel').textContent = selected ? `${selected.a} | ${selected.b}` : 'Ficha seleccionada';
    document.querySelectorAll('.move-button').forEach(button => {
      const match = moves.some(move => move.side === button.dataset.side);
      button.classList.toggle('hidden', !match);
    });
    const hasMoves = legal.length > 0;
    $('drawButton').disabled = !data.isYourTurn || hasMoves || data.options.ruleMode !== 'draw' || data.boneyardCount === 0 || data.roundOver;
    $('drawButton').textContent = data.boneyardCount ? `Robar ficha · ${data.boneyardCount}` : 'Pozo vacío';
    $('passButton').disabled = !data.isYourTurn || hasMoves || (data.options.ruleMode === 'draw' && data.boneyardCount > 0) || data.roundOver;

    if (data.roundOver && data.result) renderResult(data.result, data);
    else $('resultPanel').classList.add('hidden');

    if (data.localHotseat) setMessage('Modo de misma pantalla: pasa el dispositivo al jugador cuyo turno aparece arriba.', 'info');
    else if (data.isYourTurn) setMessage(data.openingPending ? 'Abre la mesa con la ficha de salida indicada.' : hasMoves ? 'Selecciona una ficha y elige uno de los extremos.' : data.options.ruleMode === 'draw' && data.boneyardCount ? 'No tienes jugada. Roba del pozo hasta conseguir una ficha válida.' : 'No tienes jugada. Puedes pasar el turno.', 'info');
    else setMessage(`Esperando la jugada de ${data.turnPlayerName}.`, 'info');
  }

  function renderResult(result, data) {
    const el = $('resultPanel');
    el.classList.remove('hidden');
    const reason = result.reason === 'empty' ? 'se quedó sin fichas' : 'cerró la partida con menos puntos';
    const scores = result.scores.map(item => `<div class="score-row"><span>${escapeHtml(item.name)}</span><b>${item.score} pts</b><small>${item.remaining} en mano</small></div>`).join('');
    el.innerHTML = `<h2>${escapeHtml(result.winnerName)} ganó la ronda</h2><p>${escapeHtml(result.winnerName)} ${reason}. Sumó ${result.awarded} puntos.${result.matchOver ? ' ¡También alcanzó la meta de la partida!' : ''}</p><div class="score-list">${scores}</div><button class="primary-button" id="newRoundButton" type="button">${result.matchOver ? 'Volver a jugar' : 'Siguiente ronda'} ↗</button>`;
    $('newRoundButton').addEventListener('click', () => socket.emit('newRound'));
    playSound('win');
  }

  function setMessage(message, kind) {
    $('gameMessage').textContent = message;
    $('gameMessage').className = `game-message ${kind || ''}`;
  }

  $('handTiles').addEventListener('click', event => {
    const button = event.target.closest('[data-hand-id]');
    if (!button || button.disabled) return;
    state.selectedTileId = button.dataset.handId;
    playSound('tap');
    renderGame(state.game);
  });
  $('moveControls').addEventListener('click', event => {
    const button = event.target.closest('[data-side]');
    if (!button || !state.selectedTileId || !state.game?.isYourTurn) return;
    socket.emit('playTile', { tileId: state.selectedTileId, side: button.dataset.side });
    state.selectedTileId = null;
    playSound('place');
  });
  $('drawButton').addEventListener('click', () => { socket.emit('drawTile'); playSound('draw'); });
  $('passButton').addEventListener('click', () => { socket.emit('passTurn'); playSound('pass'); });

  // Restore appearance preferences on load.
  document.querySelectorAll('.avatar-choice').forEach(button => button.classList.toggle('selected', button.dataset.avatar === state.avatar));
  document.querySelectorAll('.skin-choice').forEach(button => button.classList.toggle('selected', button.dataset.skin === state.skin));
  document.querySelectorAll('.table-choice').forEach(button => button.classList.toggle('selected', button.dataset.table === state.table));
  $('soundToggle').classList.toggle('muted', !state.sound);
  setMode('ai');
})();
