(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const readPreference = (key, fallback) => {
    try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; }
  };
  const savePreference = (key, value) => {
    try { localStorage.setItem(key, value); } catch { /* El juego sigue funcionando sin almacenamiento local. */ }
  };
  const VALID_SKINS = ['classic', 'wood', 'obsidian', 'marble', 'gold', 'neon', 'ocean', 'caribe'];
  const VALID_TABLES = ['green', 'purple', 'blue', 'red', 'wood'];
  const AVATAR_IDS = ['avatar-01', 'avatar-02', 'avatar-03', 'avatar-04', 'avatar-05', 'avatar-06', 'avatar-07', 'avatar-08'];
  // Migra preferencias guardadas por versiones anteriores sin mostrar nombres en el selector.
  const LEGACY_AVATAR_MAP = Object.freeze({
    'abuelo-rafa': 'avatar-01', 'la-paisa': 'avatar-02', 'profe-lee': 'avatar-03', 'camila': 'avatar-04',
    'tomas': 'avatar-05', 'dona-clara': 'avatar-06', 'santiago': 'avatar-07', 'valeria': 'avatar-08'
  });
  const storedAvatar = readPreference('domino-avatar', 'avatar-01');
  const initialAvatar = AVATAR_IDS.includes(storedAvatar) ? storedAvatar : (LEGACY_AVATAR_MAP[storedAvatar] || 'avatar-01');
  const state = {
    mode: 'ai', avatar: initialAvatar,
    skin: VALID_SKINS.includes(readPreference('domino-skin', 'classic')) ? readPreference('domino-skin', 'classic') : 'classic',
    table: VALID_TABLES.includes(readPreference('domino-table', 'green')) ? readPreference('domino-table', 'green') : 'green',
    socket: null, playerId: null, roomCode: null, selectedTileId: null, game: null,
    handOrder: [], handOwnerId: null, preferredFlow: 'straight',
    sound: readPreference('domino-sound', 'on') !== 'off', audio: null, toastTimer: null
  };

  let socket = null;
  try {
    if (typeof window.io === 'function') {
      socket = window.io({ path: '/domino/socket.io', transports: ['websocket', 'polling'], reconnection: true, timeout: 10000 });
    }
  } catch (error) {
    console.error('[Dominó] No se pudo inicializar Socket.IO:', error);
  }
  state.socket = socket;

  function setConnectionStatus(status, label) {
    const badge = $('connectionStatus');
    if (!badge) return;
    badge.dataset.state = status;
    const text = badge.querySelector('span');
    if (text) text.textContent = label;
    badge.title = label;
  }

  function emitAction(eventName, payload) {
    if (!socket) {
      toast('No se cargó el sistema de conexión. Recarga Dominó Club.', 'error');
      setConnectionStatus('offline', 'Sin sistema de conexión');
      return false;
    }
    if (!socket.connected) {
      toast('Conectando con la mesa… intenta de nuevo en un momento.', 'error');
      return false;
    }
    socket.emit(eventName, payload);
    return true;
  }


  function settingsPayload() {
    return {
      name: $('playerName').value.trim() || 'Jugador', avatar: state.avatar,
      playerCount: Number($('playerCount').value), difficulty: $('difficulty').value,
      pointsTarget: Number($('pointsTarget').value), ruleMode: $('ruleMode').value,
      teamMode: $('teamMode').checked
    };
  }

  function toast(message, kind = 'info') {
    const el = $('toast');
    el.textContent = message;
    el.className = `toast visible ${kind}`;
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => { el.className = 'toast'; }, 2700);
  }

  function playSound(type = 'tap') {
    if (!state.sound) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      state.audio ||= new AudioContext();
      if (state.audio.state === 'suspended') state.audio.resume();
      const oscillator = state.audio.createOscillator();
      const gain = state.audio.createGain();
      const now = state.audio.currentTime;
      const tones = { tap: [480, .055], place: [620, .12], draw: [370, .1], pass: [260, .12], win: [740, .25], error: [170, .14] };
      const [freq, duration] = tones[type] || tones.tap;
      oscillator.type = type === 'error' ? 'triangle' : 'sine';
      oscillator.frequency.setValueAtTime(freq, now);
      if (type === 'place') oscillator.frequency.exponentialRampToValueAtTime(850, now + duration);
      gain.gain.setValueAtTime(.0001, now);
      gain.gain.exponentialRampToValueAtTime(.08, now + .012);
      gain.gain.exponentialRampToValueAtTime(.0001, now + duration);
      oscillator.connect(gain).connect(state.audio.destination);
      oscillator.start(now);
      oscillator.stop(now + duration + .02);
    } catch { /* El audio no debe bloquear una jugada. */ }
  }

  function setSound(enabled) {
    state.sound = !!enabled;
    savePreference('domino-sound', state.sound ? 'on' : 'off');
    $('soundToggle').classList.toggle('muted', !state.sound);
    $('gameSoundToggle')?.classList.toggle('muted', !state.sound);
    toast(state.sound ? 'Sonido activado' : 'Sonido silenciado');
    playSound('tap');
  }

  function setMode(mode) {
    state.mode = ['ai', 'online', 'local'].includes(mode) ? mode : 'ai';
    document.querySelectorAll('.mode-card').forEach(button => {
      const active = button.dataset.mode === state.mode;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    $('difficultyField').classList.toggle('hidden', mode !== 'ai');
    $('teamRow').classList.toggle('hidden', Number($('playerCount').value) !== 4);
    $('onlineOptions').classList.toggle('hidden', mode !== 'online');
    $('startButton').classList.toggle('hidden', mode === 'online');
  }

  document.querySelectorAll('.mode-card').forEach(button => button.addEventListener('click', () => {
    playSound('tap'); setMode(button.dataset.mode);
  }));
  $('playerCount').addEventListener('change', () => $('teamRow').classList.toggle('hidden', Number($('playerCount').value) !== 4));

  document.querySelectorAll('.avatar-choice').forEach(button => button.addEventListener('click', () => {
    state.avatar = button.dataset.avatar;
    savePreference('domino-avatar', state.avatar);
    document.querySelectorAll('.avatar-choice').forEach(item => { const selected = item === button; item.classList.toggle('selected', selected); item.setAttribute('aria-pressed', String(selected)); });
    playSound('tap');
  }));
  document.querySelectorAll('.skin-choice').forEach(button => button.addEventListener('click', () => {
    state.skin = VALID_SKINS.includes(button.dataset.skin) ? button.dataset.skin : 'classic';
    savePreference('domino-skin', state.skin);
    document.querySelectorAll('.skin-choice').forEach(item => { const selected = item === button; item.classList.toggle('selected', selected); item.setAttribute('aria-pressed', String(selected)); });
    applyGameSkin();
    updateCustomizationPreview();
    playSound('tap');
  }));
  document.querySelectorAll('.table-choice').forEach(button => button.addEventListener('click', () => {
    state.table = VALID_TABLES.includes(button.dataset.table) ? button.dataset.table : 'green';
    savePreference('domino-table', state.table);
    document.querySelectorAll('.table-choice').forEach(item => { const selected = item === button; item.classList.toggle('selected', selected); item.setAttribute('aria-pressed', String(selected)); });
    $('gameTable').className = `table-surface table-${state.table}`;
    updateCustomizationPreview();
    playSound('tap');
  }));

  function applyGameSkin() {
    const root = $('gameView');
    VALID_SKINS.forEach(skin => root.classList.remove(`skin-${skin}`));
    root.classList.add(`skin-${state.skin}`);
  }

  function showView(view) {
    $('homeView').classList.toggle('hidden', view !== 'home');
    $('lobbyView').classList.toggle('hidden', view !== 'lobby');
    $('gameView').classList.toggle('hidden', view !== 'game');
  }

  function showLobbyConfig() {
    $('lobbyConfigPanel').classList.remove('hidden');
    $('onlineLobbyPanel').classList.add('hidden');
    showView('lobby');
  }

  function openLobby(mode = 'ai') {
    setMode(mode);
    showLobbyConfig();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function joinPayload() {
    return { ...settingsPayload(), code: $('roomCodeInput').value.trim().toUpperCase() };
  }

  $('startButton').addEventListener('click', () => {
    const payload = settingsPayload();
    if (emitAction(state.mode === 'ai' ? 'createAI' : 'createLocal', payload)) playSound('tap');
  });

  $('createRoomButton').addEventListener('click', () => {
    if (emitAction('createOnline', settingsPayload())) playSound('tap');
  });
  $('joinRoomButton').addEventListener('click', () => {
    const code = $('roomCodeInput').value.trim().toUpperCase();
    if (code.length < 4) return toast('Escribe un código de sala válido.', 'error');
    if (emitAction('joinOnline', joinPayload())) playSound('tap');
  });
  $('roomCodeInput').addEventListener('input', event => { event.target.value = event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });
  $('copyCodeButton').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(state.roomCode || $('lobbyCode').textContent); toast('Código copiado'); }
    catch { toast(`Código: ${state.roomCode}`); }
  });
  $('startOnlineButton').addEventListener('click', () => emitAction('startOnline'));
  $('cancelLobbyButton').addEventListener('click', returnToLobbyConfig);
  $('leaveGameButton').addEventListener('click', leaveToSetup);
  $('rulesButton').addEventListener('click', () => $('rulesModal').classList.remove('hidden'));
  $('closeRules').addEventListener('click', () => $('rulesModal').classList.add('hidden'));
  $('rulesModal').addEventListener('click', event => { if (event.target === $('rulesModal')) $('rulesModal').classList.add('hidden'); });
  $('soundToggle').addEventListener('click', () => setSound(!state.sound));
  $('gameSoundToggle').addEventListener('click', () => setSound(!state.sound));

  function leaveToSetup() {
    socket?.emit('leaveRoom');
    state.playerId = null; state.roomCode = null; state.game = null; state.selectedTileId = null; state.handOrder = []; state.preferredFlow = 'straight';
    $('onlineLobbyPanel').classList.add('hidden');
    $('lobbyConfigPanel').classList.remove('hidden');
    showView('home');
  }

  function returnToLobbyConfig() {
    socket?.emit('leaveRoom');
    state.playerId = null; state.roomCode = null; state.game = null; state.handOrder = []; state.preferredFlow = 'straight';
    $('onlineLobbyPanel').classList.add('hidden');
    $('lobbyConfigPanel').classList.remove('hidden');
    showView('lobby');
  }

  document.querySelectorAll('[data-home-mode]').forEach(button => {
    button.addEventListener('click', () => {
      playSound('tap');
      openLobby(button.dataset.homeMode);
    });
  });
  $('homeQuickPlayButton').addEventListener('click', () => openLobby('ai'));
  $('homeCustomizeButton').addEventListener('click', () => {
    openLobby('ai');
    setTimeout(() => $('customizePanel')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 80);
  });
  $('homeRulesButton').addEventListener('click', () => $('rulesModal').classList.remove('hidden'));
  $('backHomeButton').addEventListener('click', () => {
    showView('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  function renderLobby(lobby) {
    $('lobbyConfigPanel').classList.add('hidden');
    $('onlineLobbyPanel').classList.remove('hidden');
    showView('lobby');
    state.roomCode = lobby.code;
    $('lobbyCode').textContent = lobby.code;
    const currentIsHost = state.playerId === lobby.hostId;
    $('startOnlineButton').classList.toggle('hidden', !currentIsHost);
    $('startOnlineButton').disabled = !currentIsHost || lobby.playerCount < 2;
    $('lobbyHint').textContent = currentIsHost
      ? `${lobby.playerCount} de ${lobby.maxPlayers} jugadores. Inicia cuando estén listos.`
      : `Esperando a ${lobby.hostName}, anfitrión de la sala.`;
    const players = lobby.players.map(player => `
      <div class="lobby-player"><img src="/domino/assets/avatars/${escapeHtml(player.avatar)}.webp" alt=""><div><span>${escapeHtml(player.name)}</span><small>${player.id === lobby.hostId ? 'Anfitrión' : 'Listo para jugar'}</small></div></div>`).join('');
    const slots = Array.from({ length: Math.max(0, lobby.maxPlayers - lobby.playerCount) }, () => '<div class="lobby-player empty">Esperando jugador…</div>').join('');
    $('lobbyPlayers').innerHTML = players + slots;
    showView('lobby');
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  }

  if (!socket) setConnectionStatus('offline', 'Sin conexión con el servidor');
  socket?.on('connect', () => { setConnectionStatus('online', 'Conectado a Dominó Club'); toast('Conectado a Dominó Club'); });
  socket?.on('connect_error', error => { setConnectionStatus('offline', 'Reconectando…'); console.warn('[Dominó] Error de conexión:', error?.message || error); toast('Conexión inestable. Intentando reconectar…', 'error'); });
  socket?.on('joined', data => {
    state.roomCode = data.code;
    state.playerId = data.playerId;
    if (data.mode === 'online') toast(`Sala ${data.code} creada. Comparte el código.`);
  });
  socket?.on('lobbyState', renderLobby);
  socket?.on('notice', data => { toast(data.message, data.kind); playSound(data.kind === 'error' ? 'error' : 'tap'); });
  socket?.on('gameState', data => {
    state.game = data;
    state.playerId = data.you;
    state.roomCode = data.code;
    state.selectedTileId = null;
    // Reveal the game panel before measuring the table. If renderGame runs
    // while its parent is display:none, clientWidth is zero and the chain is
    // laid out against a fallback width, so the opening tile appears offset.
    showView('game');
    renderGame(data);
  });
  socket?.on('disconnect', () => { setConnectionStatus('offline', 'Conexión interrumpida · reconectando'); toast('Se perdió la conexión con la mesa.', 'error'); });

  const DOTS = {
    0: [], 1: [[2, 2]], 2: [[1, 1], [3, 3]], 3: [[1, 1], [2, 2], [3, 3]],
    4: [[1, 1], [1, 3], [3, 1], [3, 3]], 5: [[1, 1], [1, 3], [2, 2], [3, 1], [3, 3]],
    6: [[1, 1], [2, 1], [3, 1], [1, 3], [2, 3], [3, 3]]
  };

  function pips(value) {
    return `<span class="pip-layout">${(DOTS[value] || []).map(([row, col]) => `<i style="grid-area:${row}/${col}"></i>`).join('')}</span>`;
  }

  function tileMarkup(tile, orientation = 'horizontal', extraClass = '', chainIndex = null, inlineStyle = '') {
    const indexAttr = chainIndex === null ? '' : ` data-chain-index="${chainIndex}"`;
    const styleAttr = inlineStyle ? ` style="${inlineStyle}"` : '';
    return `<div class="domino-tile ${orientation} ${tile.a === tile.b ? 'double' : ''} ${extraClass}" data-tile-id="${escapeHtml(tile.id)}"${indexAttr}${styleAttr}><span class="tile-half">${pips(tile.a)}</span><span class="tile-half">${pips(tile.b)}</span></div>`;
  }

  // El dominó abre en el centro. Cada extremo crece hacia su propio lado;
  // las fichas marcadas con flowAfter controlan dónde la cadena dobla arriba/abajo.
  function renderDominoChain(chain, openingTileId) {
    const chainElement = $('dominoChain');
    if (!chainElement) return;
    if (!chain?.length) {
      chainElement.innerHTML = '';
      chainElement.dataset.rows = '0';
      chainElement.style.height = '0px';
      return;
    }
    const stage = $('chainStage');
    const isMobile = (window.innerWidth || 1024) < 680;
    // Use the actual positioned layer width. Subtracting an estimated padding
    // here made the SVG connector layer narrower than the tiles on some screens.
    const stageWidth = stage?.clientWidth || 900;
    const horizontalPadding = isMobile ? 8 : 44;
    const width = Math.max(280, chainElement.clientWidth || stageWidth - horizontalPadding);
    // dominoChain is placed inside the stage content box, after its padding.
    // Center relative to that content box so the opening tile is truly centered
    // in the visible table, not 30–36 px too low because of the stage padding.
    const fallbackVerticalPadding = isMobile ? 24 : 72;
    const computedStageStyle = stage && typeof window.getComputedStyle === 'function' ? window.getComputedStyle(stage) : null;
    const paddingTop = parseFloat(computedStageStyle?.paddingTop) || (isMobile ? 12 : 36);
    const paddingBottom = parseFloat(computedStageStyle?.paddingBottom) || (isMobile ? 12 : 36);
    const stageHeight = stage?.clientHeight || 285;
    const contentHeight = Math.max(180, stageHeight - paddingTop - paddingBottom || stageHeight - fallbackVerticalPadding);
    const layout = window.DominoLayout.buildChainLayout(chain, openingTileId, width, {
      minHeight: 285,
      centerY: Math.max(96, contentHeight / 2)
    });
    chainElement.dataset.rows = String(Math.max(1, Math.ceil(layout.height / 90)));
    chainElement.dataset.rootIndex = String(layout.rootIndex);
    chainElement.style.width = '100%';
    chainElement.style.height = `${layout.height}px`;

    // Cada unión conecta los puertos reales de las fichas, no sus centros.
    // Así las curvas en L quedan pegadas a los extremos cuando la cadena baja/sube.
    const connectors = (layout.connectors || []).map(link =>
      `<path d="${link.path}" class="chain-connector" data-from="${link.fromIndex}" data-to="${link.toIndex}"/>`
    );
    const tiles = layout.positions.map(position => {
      const tile = chain[position.index];
      const turnClass = position.turnDirection === 'down' ? 'turn-down' : position.turnDirection === 'up' ? 'turn-up' : position.turnsAfter ? 'turn-auto' : '';
      const reverseClass = position.reverseHalves ? 'reverse-halves' : '';
      const classes = `chain-tile chain-layout-tile ${position.opening ? 'opening-tile' : ''} ${turnClass} ${reverseClass}`;
      const style = `left:${position.x}px;top:${position.y}px`;
      return tileMarkup(tile, position.orientation, classes, position.index, style);
    }).join('');
    chainElement.innerHTML = `<svg class="chain-connectors" viewBox="0 0 ${layout.width} ${layout.height}" preserveAspectRatio="none" aria-hidden="true">${connectors.join('')}</svg>${tiles}`;
  }

  function getDropSide(clientX, clientY) {
    if (state.game?.openingPending) return 'center';
    const chainLength = state.game?.chain?.length || 0;
    if (chainLength <= 1) {
      const stageRect = $('chainStage')?.getBoundingClientRect?.();
      const midpoint = stageRect ? stageRect.left + stageRect.width / 2 : window.innerWidth / 2;
      return clientX < midpoint ? 'left' : 'right';
    }
    const first = document.querySelector(`#dominoChain [data-chain-index="0"]`);
    const lastIndex = chainLength - 1;
    const last = document.querySelector(`#dominoChain [data-chain-index="${lastIndex}"]`);
    const distanceTo = element => {
      const rect = element?.getBoundingClientRect?.();
      if (!rect) return Number.POSITIVE_INFINITY;
      return Math.hypot(clientX - (rect.left + rect.width / 2), clientY - (rect.top + rect.height / 2));
    };
    const firstDistance = distanceTo(first);
    const lastDistance = distanceTo(last);
    if (Number.isFinite(firstDistance) && Number.isFinite(lastDistance)) return firstDistance <= lastDistance ? 'left' : 'right';
    const rect = $('chainStage')?.getBoundingClientRect?.();
    return rect && clientX < rect.left + rect.width / 2 ? 'left' : 'right';
  }

  function getDropFlow(side, clientY) {
    if (!['left', 'right'].includes(side)) return 'straight';
    const chainLength = state.game?.chain?.length || 0;
    const index = side === 'left' ? 0 : Math.max(0, chainLength - 1);
    const endpoint = document.querySelector(`#dominoChain [data-chain-index="${index}"]`);
    const rect = endpoint?.getBoundingClientRect?.();
    if (rect) {
      const deltaY = clientY - (rect.top + rect.height / 2);
      const threshold = Math.max(16, rect.height * .3);
      if (deltaY > threshold) return 'down';
      if (deltaY < -threshold) return 'up';
    }
    return state.preferredFlow;
  }

  function setPreferredFlow(flow) {
    state.preferredFlow = ['down', 'up'].includes(flow) ? flow : 'straight';
    document.querySelectorAll('.flow-choice-button').forEach(button => {
      const selected = button.dataset.flowAfter === state.preferredFlow;
      button.classList.toggle('selected', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
  }

  function reorderHandTile(sourceId, targetId, clientX, targetElement) {
    if (!state.game || !Array.isArray(state.handOrder)) return false;
    const order = state.handOrder.slice();
    const sourceIndex = order.indexOf(sourceId);
    if (sourceIndex < 0) return false;
    if (targetId && targetId !== sourceId) {
      const targetRect = targetElement?.getBoundingClientRect?.();
      const insertAfter = targetRect ? clientX > targetRect.left + targetRect.width / 2 : false;
      order.splice(sourceIndex, 1);
      const targetIndex = order.indexOf(targetId);
      if (targetIndex < 0) return false;
      order.splice(targetIndex + (insertAfter ? 1 : 0), 0, sourceId);
    } else if (!targetId) {
      order.splice(sourceIndex, 1);
      const handRect = $('handTiles')?.getBoundingClientRect?.();
      const insertAtStart = handRect && clientX < handRect.left + handRect.width * .25;
      order.splice(insertAtStart ? 0 : order.length, 0, sourceId);
    } else {
      return false;
    }
    state.handOrder = order;
    renderGame(state.game);
    toast('Orden de fichas actualizado');
    return true;
  }

  const SKIN_LABELS = { classic: 'Marfil', wood: 'Madera', obsidian: 'Ónix', marble: 'Mármol', gold: 'Oro', neon: 'Neón', ocean: 'Océano', caribe: 'Caribe' };
  const TABLE_LABELS = { green: 'Verde clásico', purple: 'Violeta', blue: 'Azul noche', red: 'Borgoña', wood: 'Madera' };

  function updateCustomizationPreview() {
    const preview = $('customPreview');
    const surface = $('customPreviewTable');
    const tiles = $('customPreviewTiles');
    if (!preview || !surface || !tiles) return;
    preview.className = `custom-preview skin-${state.skin}`;
    surface.className = `custom-preview-table table-${state.table}`;
    $('previewSkinName').textContent = SKIN_LABELS[state.skin] || 'Marfil';
    $('previewTableName').textContent = TABLE_LABELS[state.table] || 'Verde clásico';
    tiles.innerHTML = [
      { id: 'preview-6-3', a: 6, b: 3 },
      { id: 'preview-4-4', a: 4, b: 4 },
      { id: 'preview-5-1', a: 5, b: 1 }
    ].map(tile => tileMarkup(tile, 'horizontal', 'preview-tile')).join('');
  }

  function renderPlayerCards(data) {
    $('playersStrip').innerHTML = data.players.map(player => `
      <div class="player-card ${player.id === data.turnPlayerId ? 'active' : ''}">
        <img src="/domino/assets/avatars/${escapeHtml(player.avatar)}.webp" alt="">
        <div class="player-meta"><b>${escapeHtml(player.name)}${player.id === data.you ? ' · Tú' : ''}</b><small>${player.isAI ? `IA · ${difficultyLabel(player.difficulty)}` : player.connected ? 'Conectado' : 'Desconectado'} · ${player.handCount} fichas</small></div>
        <span class="player-score">${player.score}</span>
      </div>`).join('');
  }

  function difficultyLabel(level) { return ({ easy: 'Fácil', normal: 'Normal', hard: 'Difícil' })[level] || 'Normal'; }

  function renderGame(data) {
    const root = $('gameView');
    root.className = `game-view skin-${state.skin}`;
    $('gameTable').className = `table-surface table-${state.table}`;
    $('gameCode').textContent = data.mode === 'online' ? `· Sala ${data.code}` : data.mode === 'local' ? '· Misma pantalla' : '· Contra IA';
    $('boneyardCount').textContent = `Pozo: ${data.boneyardCount}`;
    const thinking = !data.isYourTurn && !!data.aiThinking;
    $('turnBanner').classList.toggle('thinking', thinking);
    $('turnBanner').textContent = thinking
      ? `${data.turnPlayerName} está pensando…`
      : data.isYourTurn
        ? (data.localHotseat ? `Turno de ${data.players.find(p => p.id === data.you)?.name || 'Jugador'}` : 'Es tu turno')
        : `Turno de ${data.turnPlayerName}`;
    renderPlayerCards(data);

    const chain = $('dominoChain');
    $('chainEmpty').classList.toggle('hidden', data.chain.length > 0);
    renderDominoChain(data.chain, data.openingTileId);

    const current = data.players.find(p => p.id === data.you);
    $('handTitle').textContent = data.localHotseat ? `Fichas de ${current?.name || 'jugador'}` : 'Tus fichas';
    $('handCount').textContent = `${data.hand.length} fichas`;
    const legal = data.isYourTurn ? data.legalMoves : [];
    const incomingHand = Array.isArray(data.hand) ? data.hand : [];
    if (state.handOwnerId !== (current?.id || data.you)) {
      state.handOwnerId = current?.id || data.you;
      state.handOrder = [];
    }
    const handById = new Map(incomingHand.map(tile => [tile.id, tile]));
    const sortedHand = [...incomingHand].sort((a, b) => (a.a + a.b) - (b.a + b.b) || a.a - b.a);
    state.handOrder = state.handOrder.filter(id => handById.has(id));
    for (const tile of sortedHand) if (!state.handOrder.includes(tile.id)) state.handOrder.push(tile.id);
    const hand = state.handOrder.map(id => handById.get(id)).filter(Boolean);
    $('handTiles').innerHTML = hand.map(tile => {
      // Todas las fichas tienen el mismo tamaño; el jugador puede reordenarlas manualmente.
      return `<button type="button" class="domino-tile vertical hand-tile ${tile.id === state.selectedTileId ? 'selected' : ''}" data-hand-id="${escapeHtml(tile.id)}" ${!data.isYourTurn || data.roundOver ? 'disabled' : ''} aria-label="Ficha ${tile.a} y ${tile.b}"><span class="tile-half">${pips(tile.a)}</span><span class="tile-half">${pips(tile.b)}</span></button>`;
    }).join('');

    const selected = hand.find(tile => tile.id === state.selectedTileId);
    $('moveControls').classList.toggle('hidden', !selected || !data.isYourTurn);
    $('selectedTileLabel').textContent = selected ? `${selected.a} | ${selected.b}` : 'Ficha seleccionada';
    document.querySelectorAll('.move-button').forEach(button => {
      const show = button.dataset.side === 'center' ? !!data.openingPending : !data.openingPending;
      button.classList.toggle('hidden', !show);
    });
    $('flowChoice')?.classList.toggle('hidden', !!data.openingPending || !selected || !data.isYourTurn);
    document.querySelectorAll('.flow-choice-button').forEach(button => {
      const selectedFlow = button.dataset.flowAfter === state.preferredFlow;
      button.classList.toggle('selected', selectedFlow);
      button.setAttribute('aria-pressed', String(selectedFlow));
    });
    const hasMoves = legal.length > 0;
    $('drawButton').disabled = !data.isYourTurn || hasMoves || data.options.ruleMode !== 'draw' || data.boneyardCount === 0 || data.roundOver;
    $('drawButton').textContent = data.boneyardCount ? `Robar ficha · ${data.boneyardCount}` : 'Pozo vacío';
    $('passButton').disabled = !data.isYourTurn || hasMoves || (data.options.ruleMode === 'draw' && data.boneyardCount > 0) || data.roundOver;

    if (data.roundOver && data.result) renderResult(data.result, data);
    else $('resultPanel').classList.add('hidden');

    if (data.localHotseat) setMessage('Modo de misma pantalla: pasa el dispositivo al jugador cuyo turno aparece arriba.', 'info');
    else if (data.isYourTurn) setMessage(data.openingPending ? 'Abre la mesa con la ficha de salida indicada.' : hasMoves ? 'Selecciona una ficha y colócala en cualquiera de los extremos. La cadena irá doblando su recorrido al completar cada fila.' : data.options.ruleMode === 'draw' && data.boneyardCount ? 'No tienes jugada. Roba del pozo hasta conseguir una ficha válida.' : 'No tienes jugada. Puedes pasar el turno.', 'info');
    else if (thinking) setMessage(`${data.turnPlayerName} está analizando sus fichas y las opciones de la mesa.`, 'thinking');
    else setMessage(`Esperando la jugada de ${data.turnPlayerName}.`, 'info');
  }

  function renderResult(result, data) {
    const el = $('resultPanel');
    el.classList.remove('hidden');
    const reason = result.reason === 'empty' ? 'se quedó sin fichas' : 'cerró la partida con menos puntos';
    const scores = result.scores.map(item => `<div class="score-row"><span>${escapeHtml(item.name)}</span><b>${item.score} pts</b><small>${item.remaining} en mano</small></div>`).join('');
    el.innerHTML = `<h2>${escapeHtml(result.winnerName)} ganó la ronda</h2><p>${escapeHtml(result.winnerName)} ${reason}. Sumó ${result.awarded} puntos.${result.matchOver ? ' ¡También alcanzó la meta de la partida!' : ''}</p><div class="score-list">${scores}</div><button class="primary-button" id="newRoundButton" type="button">${result.matchOver ? 'Volver a jugar' : 'Siguiente ronda'} ↗</button>`;
    $('newRoundButton').addEventListener('click', () => emitAction('newRound'));
    playSound('win');
  }

  function setMessage(message, kind) {
    $('gameMessage').textContent = message;
    $('gameMessage').className = `game-message ${kind || ''}`;
  }

  // Drag & drop táctil y con ratón: una ficha válida se puede soltar
  // directamente sobre la cadena. Si hay dos extremos posibles, el lado
  // donde se suelta determina izquierda o derecha.
  let activeTileDrag = null;
  let suppressTileClickUntil = 0;
  let dragGhost = null;

  function clearTileDragVisuals() {
    dragGhost?.remove?.();
    dragGhost = null;
    const stage = $('chainStage');
    stage?.classList.remove('drop-active', 'drop-left', 'drop-right', 'drop-center', 'drop-turn-down', 'drop-turn-up');
    document.querySelectorAll('#dominoChain .drop-end-target').forEach(element => element.classList.remove('drop-end-target', 'drop-turn-down', 'drop-turn-up'));
    document.querySelectorAll('#handTiles .reorder-over').forEach(element => element.classList.remove('reorder-over'));
    const hint = $('dropGuide');
    if (hint) hint.textContent = 'Suelta cerca de un extremo. Más abajo: dobla hacia abajo; más arriba: dobla hacia arriba.';
  }

  function markDropEndpoint(side, flow = 'straight') {
    document.querySelectorAll('#dominoChain .drop-end-target').forEach(element => element.classList.remove('drop-end-target', 'drop-turn-down', 'drop-turn-up'));
    if (!['left', 'right'].includes(side)) return;
    const lastIndex = Math.max(0, (state.game?.chain?.length || 1) - 1);
    const index = side === 'left' ? 0 : lastIndex;
    const endpoint = document.querySelector(`#dominoChain [data-chain-index="${index}"]`);
    endpoint?.classList.add('drop-end-target');
    if (flow === 'down') endpoint?.classList.add('drop-turn-down');
    if (flow === 'up') endpoint?.classList.add('drop-turn-up');
  }

  function beginTileDrag(event) {
    const button = event.target?.closest?.('[data-hand-id]');
    if (!button || button.disabled || (event.button !== undefined && event.button !== 0)) return;
    activeTileDrag = {
      id: button.dataset.handId,
      element: button,
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      moved: false
    };
  }

  function moveTileDrag(event) {
    if (!activeTileDrag || (activeTileDrag.pointerId !== undefined && event.pointerId !== activeTileDrag.pointerId)) return;
    const dx = event.clientX - activeTileDrag.startX;
    const dy = event.clientY - activeTileDrag.startY;
    if (!activeTileDrag.moved && Math.hypot(dx, dy) < 8) return;
    activeTileDrag.moved = true;
    event.preventDefault?.();

    if (!dragGhost && activeTileDrag.element?.cloneNode) {
      dragGhost = activeTileDrag.element.cloneNode(true);
      dragGhost.removeAttribute?.('data-hand-id');
      dragGhost.disabled = true;
      dragGhost.classList.add('drag-ghost');
      document.body.appendChild(dragGhost);
    }
    if (dragGhost) {
      dragGhost.style.left = `${event.clientX}px`;
      dragGhost.style.top = `${event.clientY}px`;
    }

    const pointTarget = document.elementFromPoint?.(event.clientX, event.clientY);
    const overHandTile = pointTarget?.closest?.('[data-hand-id]');
    const handRect = $('handTiles')?.getBoundingClientRect?.();
    const overHand = !!handRect && event.clientX >= handRect.left && event.clientX <= handRect.right && event.clientY >= handRect.top && event.clientY <= handRect.bottom;
    document.querySelectorAll('#handTiles .reorder-over').forEach(element => element.classList.remove('reorder-over'));
    if (overHand) {
      if (overHandTile && overHandTile.dataset.handId !== activeTileDrag.id) overHandTile.classList.add('reorder-over');
      $('dropGuide').textContent = 'Suelta sobre otra ficha para cambiar el orden de tu mano';
      $('chainStage')?.classList.remove('drop-active', 'drop-left', 'drop-right', 'drop-center', 'drop-turn-down', 'drop-turn-up');
      markDropEndpoint(null);
      return;
    }

    const stage = $('chainStage');
    const rect = stage?.getBoundingClientRect?.();
    const overStage = !!rect && event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
    stage?.classList.toggle('drop-active', overStage);
    if (overStage) {
      const side = getDropSide(event.clientX, event.clientY);
      const flow = side === 'center' ? 'straight' : getDropFlow(side, event.clientY);
      markDropEndpoint(side, flow);
      stage.classList.toggle('drop-center', side === 'center');
      stage.classList.toggle('drop-left', side === 'left');
      stage.classList.toggle('drop-right', side === 'right');
      stage.classList.toggle('drop-turn-down', flow === 'down');
      stage.classList.toggle('drop-turn-up', flow === 'up');
      const hint = $('dropGuide');
      if (hint) hint.textContent = side === 'center'
        ? 'Suelta para colocar la ficha inicial en el centro'
        : flow === 'down' ? `Suelta en ${side === 'left' ? 'el extremo izquierdo' : 'el extremo derecho'} para doblar hacia abajo ↓`
        : flow === 'up' ? `Suelta en ${side === 'left' ? 'el extremo izquierdo' : 'el extremo derecho'} para doblar hacia arriba ↑`
        : `Suelta en ${side === 'left' ? 'el extremo izquierdo' : 'el extremo derecho'} para continuar recto`;
    } else {
      stage?.classList.remove('drop-left', 'drop-right', 'drop-center', 'drop-turn-down', 'drop-turn-up');
      markDropEndpoint(null);
    }
  }

  function finishTileDrag(event) {
    if (!activeTileDrag || (activeTileDrag.pointerId !== undefined && event.pointerId !== activeTileDrag.pointerId)) return;
    const drag = activeTileDrag;
    activeTileDrag = null;
    if (!drag.moved) { clearTileDragVisuals(); return; }
    event.preventDefault?.();
    suppressTileClickUntil = Date.now() + 450;

    const stage = $('chainStage');
    const rect = stage?.getBoundingClientRect?.();
    const overStage = !!rect && event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
    const pointTarget = document.elementFromPoint?.(event.clientX, event.clientY);
    const handRect = $('handTiles')?.getBoundingClientRect?.();
    const overHand = !!handRect && event.clientX >= handRect.left && event.clientX <= handRect.right && event.clientY >= handRect.top && event.clientY <= handRect.bottom;

    if (overStage && state.game?.isYourTurn) {
      const side = getDropSide(event.clientX, event.clientY);
      const flowAfter = side === 'center' ? 'straight' : getDropFlow(side, event.clientY);
      if (emitAction('playTile', { tileId: drag.id, side, flowAfter })) {
        state.selectedTileId = null;
        state.preferredFlow = 'straight';
        setPreferredFlow('straight');
        const message = flowAfter === 'down' ? 'Ficha colocada: el siguiente tramo bajará.' : flowAfter === 'up' ? 'Ficha colocada: el siguiente tramo subirá.' : 'Ficha enviada a la cadena.';
        setMessage(message, 'success');
        playSound('place');
      }
    } else if (overHand) {
      const targetTile = pointTarget?.closest?.('[data-hand-id]');
      reorderHandTile(drag.id, targetTile?.dataset.handId || null, event.clientX, targetTile);
    } else {
      state.selectedTileId = drag.id;
      renderGame(state.game);
    }
    clearTileDragVisuals();
  }

  $('handTiles').addEventListener('pointerdown', beginTileDrag);
  if (typeof document.addEventListener === 'function') {
    document.addEventListener('pointermove', moveTileDrag, { passive: false });
    document.addEventListener('pointerup', finishTileDrag);
    document.addEventListener('pointercancel', finishTileDrag);
  }

  $('handTiles').addEventListener('click', event => {
    if (Date.now() < suppressTileClickUntil) { event.preventDefault?.(); return; }
    const button = event.target.closest('[data-hand-id]');
    if (!button || button.disabled) return;
    state.selectedTileId = button.dataset.handId;
    playSound('tap');
    renderGame(state.game);
  });
  $('moveControls').addEventListener('click', event => {
    const flowButton = event.target.closest('[data-flow-after]');
    if (flowButton) {
      setPreferredFlow(flowButton.dataset.flowAfter);
      playSound('tap');
      const label = state.preferredFlow === 'down' ? 'La siguiente ficha doblará hacia abajo.' : state.preferredFlow === 'up' ? 'La siguiente ficha doblará hacia arriba.' : 'La cadena continuará recta.';
      setMessage(label, 'info');
      return;
    }
    const button = event.target.closest('[data-side]');
    if (!button || !state.selectedTileId || !state.game?.isYourTurn) return;
    const flowAfter = button.dataset.side === 'center' ? 'straight' : state.preferredFlow;
    if (emitAction('playTile', { tileId: state.selectedTileId, side: button.dataset.side, flowAfter })) {
      state.selectedTileId = null;
      state.preferredFlow = 'straight';
      setPreferredFlow('straight');
      playSound('place');
    }
  });
  $('drawButton').addEventListener('click', () => { if (emitAction('drawTile')) playSound('draw'); });
  $('passButton').addEventListener('click', () => { if (emitAction('passTurn')) playSound('pass'); });

  // Restore appearance preferences on load.
  document.querySelectorAll('.avatar-choice').forEach(button => {
    const selected = button.dataset.avatar === state.avatar;
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  document.querySelectorAll('.skin-choice').forEach(button => {
    const selected = button.dataset.skin === state.skin;
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  document.querySelectorAll('.table-choice').forEach(button => {
    const selected = button.dataset.table === state.table;
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  updateCustomizationPreview();
  if (typeof window.addEventListener === 'function') {
    window.addEventListener('resize', () => { if (state.game) renderDominoChain(state.game.chain, state.game.openingTileId); });
  }
  $('soundToggle').classList.toggle('muted', !state.sound);
  setMode('ai');
  if (!socket) setConnectionStatus('offline', 'Sin conexión con el servidor');
})();
