'use strict';

const MAX_PIP = 6;
const TILE_COUNT = 28;

function createSet(idFactory = (() => { let n = 0; return () => `d${++n}`; })()) {
  const tiles = [];
  for (let a = 0; a <= MAX_PIP; a++) {
    for (let b = a; b <= MAX_PIP; b++) tiles.push({ id: idFactory(), a, b });
  }
  return tiles;
}

function shuffle(items, random = Math.random) {
  const result = items.slice();
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

function normalizeSettings(settings = {}) {
  const playerCount = Math.max(2, Math.min(4, Number.parseInt(settings.playerCount, 10) || 4));
  const pointsTarget = [50, 100, 150, 200].includes(Number(settings.pointsTarget)) ? Number(settings.pointsTarget) : 100;
  return {
    playerCount,
    ruleMode: settings.ruleMode === 'block' ? 'block' : 'draw',
    pointsTarget,
    teamMode: playerCount === 4 && settings.teamMode === true,
    scoringMode: settings.scoringMode === 'remaining' ? 'remaining' : 'sum',
    variant: 'double-six'
  };
}

function pipCount(tile) { return tile.a + tile.b; }
function handPoints(hand) { return hand.reduce((sum, tile) => sum + pipCount(tile), 0); }
function getEnds(chain) {
  if (!chain.length) return null;
  return { left: chain[0].a, right: chain[chain.length - 1].b };
}

function legalMoves(game, playerId) {
  if (game.roundOver) return [];
  const player = game.players.find(p => p.id === playerId);
  if (!player || game.players[game.turnIndex]?.id !== playerId) return [];
  if (game.openingPending) {
    const first = player.hand.find(t => t.id === game.openingTileId);
    return first ? [{ tileId: first.id, side: 'center', a: first.a, b: first.b }] : [];
  }
  const ends = getEnds(game.chain);
  if (!ends) return player.hand.map(t => ({ tileId: t.id, side: 'center', a: t.a, b: t.b }));
  const moves = [];
  for (const tile of player.hand) {
    if (tile.a === ends.left || tile.b === ends.left) moves.push({ tileId: tile.id, side: 'left' });
    if (tile.a === ends.right || tile.b === ends.right) moves.push({ tileId: tile.id, side: 'right' });
  }
  return moves;
}

function createGame(playerDefinitions, settings = {}, random = Math.random, idFactory) {
  const options = normalizeSettings({ ...settings, playerCount: playerDefinitions.length });
  const tiles = shuffle(createSet(idFactory), random);
  const players = playerDefinitions.map((definition, index) => ({
    id: String(definition.id),
    socketId: definition.socketId || null,
    name: String(definition.name || `Jugador ${index + 1}`).slice(0, 20),
    avatar: String(definition.avatar || 'avatar-01'),
    isAI: !!definition.isAI,
    difficulty: ['easy', 'normal', 'hard'].includes(definition.difficulty) ? definition.difficulty : 'normal',
    team: options.teamMode ? index % 2 : index,
    hand: tiles.splice(0, 7),
    score: 0,
    connected: definition.connected !== false
  }));
  let opener = null;
  for (const player of players) {
    for (const tile of player.hand) {
      if (tile.a === tile.b && (!opener || tile.a > opener.tile.a)) opener = { playerId: player.id, tile };
    }
  }
  if (!opener) {
    for (const player of players) {
      for (const tile of player.hand) {
        if (!opener || pipCount(tile) > pipCount(opener.tile) || (pipCount(tile) === pipCount(opener.tile) && tile.a > opener.tile.a)) opener = { playerId: player.id, tile };
      }
    }
  }
  const turnIndex = Math.max(0, players.findIndex(p => p.id === opener?.playerId));
  return {
    options,
    players,
    boneyard: tiles,
    chain: [],
    turnIndex,
    openingPending: true,
    openingTileId: opener?.tile.id || null,
    consecutivePasses: 0,
    turnNumber: 1,
    roundNumber: 1,
    roundOver: false,
    matchOver: false,
    result: null
  };
}

function teamPlayers(game, team) { return game.players.filter(p => p.team === team); }
function teamPips(game, team) { return teamPlayers(game, team).reduce((sum, p) => sum + handPoints(p.hand), 0); }

function finishRound(game, winnerId = null, reason = 'empty') {
  if (game.roundOver) return game.result;
  let winner = winnerId ? game.players.find(p => p.id === winnerId) : null;
  if (!winner) {
    if (game.options.teamMode) {
      const totals = [...new Set(game.players.map(p => p.team))].map(team => ({ team, points: teamPips(game, team) })).sort((a, b) => a.points - b.points);
      winner = game.players.find(p => p.team === totals[0]?.team) || null;
    } else {
      winner = game.players.slice().sort((a, b) => handPoints(a.hand) - handPoints(b.hand))[0] || null;
    }
  }
  let awarded = 0;
  if (winner) {
    if (game.options.teamMode) {
      for (const player of game.players) if (player.team !== winner.team) awarded += handPoints(player.hand);
      if (reason === 'blocked') awarded = Math.max(0, awarded - teamPips(game, winner.team));
      for (const player of teamPlayers(game, winner.team)) player.score += awarded;
    } else {
      for (const player of game.players) if (player.id !== winner.id) awarded += handPoints(player.hand);
      if (reason === 'blocked') awarded = Math.max(0, awarded - handPoints(winner.hand));
      winner.score += awarded;
    }
  }
  const topScore = Math.max(0, ...game.players.map(p => p.score));
  const matchOver = topScore >= game.options.pointsTarget;
  game.roundOver = true;
  game.matchOver = matchOver;
  game.result = {
    winnerId: winner?.id || null,
    winnerName: winner?.name || 'Empate',
    winnerTeam: winner?.team ?? null,
    reason,
    awarded,
    matchOver,
    scores: game.players.map(p => ({ id: p.id, name: p.name, score: p.score, remaining: handPoints(p.hand) }))
  };
  return game.result;
}

function advance(game) {
  game.turnIndex = (game.turnIndex + 1) % game.players.length;
  game.turnNumber++;
}

function playTile(game, playerId, tileId, side, orientation = 'horizontal', flowAfter = 'straight') {
  if (game.roundOver) return { ok: false, error: 'La ronda ya terminó.' };
  const player = game.players[game.turnIndex];
  if (!player || player.id !== playerId) return { ok: false, error: 'No es tu turno.' };
  const tileIndex = player.hand.findIndex(t => t.id === tileId);
  if (tileIndex < 0) return { ok: false, error: 'Esa ficha no está en tu mano.' };
  const tile = player.hand[tileIndex];
  const displayOrientation = orientation === 'vertical' ? 'vertical' : 'horizontal';
  const displayFlow = flowAfter === 'down' || flowAfter === 'up' ? flowAfter : 'straight';
  let orientedTile;
  if (game.openingPending) {
    if (tile.id !== game.openingTileId || side !== 'center') return { ok: false, error: 'Debes iniciar con la ficha de salida indicada.' };
    orientedTile = { ...tile, orientation: displayOrientation, flowAfter: 'straight' };
    game.chain = [orientedTile];
    game.openingPending = false;
  } else {
    const ends = getEnds(game.chain);
    if (!['left', 'right'].includes(side)) return { ok: false, error: 'Elige un extremo válido.' };
    const target = ends[side];
    if (tile.a !== target && tile.b !== target) return { ok: false, error: 'La ficha no coincide con ese extremo.' };
    if (side === 'left') {
      orientedTile = tile.b === target
        ? { ...tile, a: tile.a, b: tile.b, orientation: displayOrientation, flowAfter: displayFlow }
        : { ...tile, a: tile.b, b: tile.a, orientation: displayOrientation, flowAfter: displayFlow };
      game.chain.unshift(orientedTile);
    } else {
      orientedTile = tile.a === target
        ? { ...tile, a: tile.a, b: tile.b, orientation: displayOrientation, flowAfter: displayFlow }
        : { ...tile, a: tile.b, b: tile.a, orientation: displayOrientation, flowAfter: displayFlow };
      game.chain.push(orientedTile);
    }
  }
  player.hand.splice(tileIndex, 1);
  game.consecutivePasses = 0;
  // Broadcast the server-normalized order, not the order in the player's rack.
  const played = { id: orientedTile.id, a: orientedTile.a, b: orientedTile.b, playerId, side, orientation: displayOrientation, flowAfter: orientedTile.flowAfter || displayFlow };
  if (player.hand.length === 0) finishRound(game, playerId, 'empty');
  else advance(game);
  return { ok: true, played, result: game.result };
}

function drawTile(game, playerId) {
  if (game.roundOver) return { ok: false, error: 'La ronda ya terminó.' };
  const player = game.players[game.turnIndex];
  if (!player || player.id !== playerId) return { ok: false, error: 'No es tu turno.' };
  if (game.options.ruleMode !== 'draw') return { ok: false, error: 'Esta modalidad no permite robar: debes pasar si no puedes jugar.' };
  if (legalMoves(game, playerId).length) return { ok: false, error: 'Tienes una ficha que puedes jugar.' };
  if (!game.boneyard.length) return { ok: false, error: 'El pozo está vacío. Debes pasar.' };
  const tile = game.boneyard.pop();
  player.hand.push(tile);
  return { ok: true, tile: { id: tile.id, a: tile.a, b: tile.b }, canPlay: legalMoves(game, playerId).length > 0, remaining: game.boneyard.length };
}

function passTurn(game, playerId) {
  if (game.roundOver) return { ok: false, error: 'La ronda ya terminó.' };
  const player = game.players[game.turnIndex];
  if (!player || player.id !== playerId) return { ok: false, error: 'No es tu turno.' };
  if (legalMoves(game, playerId).length) return { ok: false, error: 'Tienes una ficha que puedes jugar.' };
  if (game.options.ruleMode === 'draw' && game.boneyard.length) return { ok: false, error: 'Debes robar una ficha antes de pasar.' };
  game.consecutivePasses++;
  const passed = player.name;
  if (game.consecutivePasses >= game.players.length) finishRound(game, null, 'blocked');
  else advance(game);
  return { ok: true, passed, result: game.result };
}

function chooseAIMove(game, player) {
  const moves = legalMoves(game, player.id);
  if (!moves.length) return null;
  const scoring = moves.map(move => {
    const tile = player.hand.find(t => t.id === move.tileId);
    const pips = pipCount(tile);
    const doubleBonus = tile.a === tile.b ? 1.8 : 0;
    const rareBonus = (tile.a === 0 || tile.b === 0) ? 0.25 : 0;
    const futureOptions = player.hand.filter(other => other.id !== tile.id && (other.a === tile.a || other.b === tile.a || other.a === tile.b || other.b === tile.b)).length;
    let score = pips + doubleBonus + rareBonus;
    if (player.difficulty === 'normal') score += futureOptions * 1.2;
    if (player.difficulty === 'hard') score += futureOptions * 2 + (tile.a === tile.b ? 2.5 : 0);
    return { move, score: player.difficulty === 'easy' ? Math.random() : score };
  });
  scoring.sort((a, b) => b.score - a.score);
  return scoring[0].move;
}

function nextRound(game, random = Math.random, idFactory) {
  if (!game.roundOver) return { ok: false, error: 'La ronda actual todavía no ha terminado.' };
  const restartMatch = game.matchOver;
  const scores = game.players.map(p => restartMatch ? 0 : p.score);
  const definitions = game.players.map(p => ({ ...p, connected: p.connected }));
  const fresh = createGame(definitions, game.options, random, idFactory);
  fresh.players.forEach((p, index) => { p.score = scores[index]; });
  fresh.roundNumber = restartMatch ? 1 : game.roundNumber + 1;
  fresh.matchOver = false;
  fresh.result = null;
  Object.assign(game, fresh);
  return { ok: true };
}

module.exports = {
  MAX_PIP, TILE_COUNT, createSet, shuffle, normalizeSettings, pipCount, handPoints,
  getEnds, legalMoves, createGame, playTile, drawTile, passTurn, finishRound,
  chooseAIMove, nextRound
};
