'use strict';

// Pausas deliberadas para que las jugadas de la IA se lean como decisiones,
// no como una secuencia instantánea. Los niveles más altos piensan un poco más.
const THINKING_RANGES = Object.freeze({
  easy: Object.freeze([3600, 4400]),
  normal: Object.freeze([4200, 5000]),
  hard: Object.freeze([4800, 5600])
});

function getAIThinkingDelay(difficulty = 'normal', random = Math.random) {
  const range = THINKING_RANGES[difficulty] || THINKING_RANGES.normal;
  const value = Number(random());
  const fraction = Number.isFinite(value) ? Math.min(0.999999, Math.max(0, value)) : 0.5;
  return Math.round(range[0] + (range[1] - range[0]) * fraction);
}

module.exports = { THINKING_RANGES, getAIThinkingDelay };
