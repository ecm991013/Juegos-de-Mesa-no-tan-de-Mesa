# Dominó Club

Juego web de dominó doble-seis integrado en el portal principal.

## Modos

- Contra IA: 2–4 plazas, nombres y retratos propios, dificultad Fácil/Normal/Difícil.
- Misma pantalla: 2–4 participantes comparten el dispositivo por turnos.
- En línea: sala privada con código; el anfitrión inicia cuando se conectan al menos dos participantes.

## Personalización

- Avatares ilustrados exclusivos del juego.
- Ocho acabados visuales de fichas: Marfil, Madera, Ónix, Mármol, Oro, Neón, Océano y Caribe.
- Cinco paños de mesa: Verde, Violeta, Azul noche, Borgoña y Madera.
- Meta de 50, 100, 150 o 200 puntos.
- Juego individual o por parejas opuestas si participan cuatro jugadores.
- Modalidad Robar o Pasar cuando no se puede jugar.

## Reglas de esta versión

- Set doble-seis de 28 fichas.
- Siete fichas para cada participante; el resto queda en el pozo.
- Abre la mula de seis si está disponible. Si no, la mula más alta; si no hay dobles, la ficha con mayor suma.
- La ficha debe coincidir con uno de los extremos abiertos.
- En modalidad Robar, se roban fichas hasta conseguir una jugable o agotar el pozo. En modalidad Pasar, se pasa directamente.
- La ronda termina al quedarse sin fichas o tras una vuelta completa de pases con el pozo vacío.
- En cierre gana quien conserve menos puntos. La puntuación de ronda se agrega al marcador hasta alcanzar la meta.

La implementación es una modalidad doble-seis común. Algunas regiones aplican otras reglas de salida, robo, cierre y puntuación.

## Ejecución integrada

El servidor `server.js` se inicia como proceso secundario desde el servidor principal, en el puerto interno 3103. Utiliza Express y Socket.IO del `package.json` raíz. La ruta pública es `/domino/` y el socket público es `/domino/socket.io`.
