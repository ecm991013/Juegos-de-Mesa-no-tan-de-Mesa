## Dominó Club 1.8.13 — dirección intuitiva desde puntas verticales

- Al arrastrar debajo de una punta vertical, la siguiente ficha continúa alineada debajo/encima de la punta.
- Al arrastrar a izquierda o derecha de una punta vertical, se respeta ese sentido sin invertir la fila por defecto.
- La detección lateral usa una zona más sensible para que un arrastre corto también registre la dirección elegida.
- Se actualizaron las referencias de CSS/JS para evitar caché de versiones anteriores.

## Actualización 1.8.11 — giro hacia la mitad abierta

Al elegir bajar/subir, la siguiente ficha aparece bajo/encima de la mitad abierta de la ficha colocada. Cuando el giro se completa, el recorrido retoma la fila de retorno en sentido contrario. La ficha fuente no se rota por haber marcado el giro.

# Dominó Club

Juego web de dominó doble-seis integrado en el portal principal.

## Modos

- Contra IA: 2–4 plazas, nombres y retratos propios, dificultad Fácil/Normal/Difícil.
- Misma pantalla: 2–4 participantes comparten el dispositivo por turnos.
- En línea: sala privada con código; el anfitrión inicia cuando se conectan al menos dos participantes.

## Personalización

- Avatares ilustrados exclusivos del juego.
- Ocho acabados visuales de fichas: Marfil, Madera, Ónix, Mármol, Oro, Neón, Océano y Caribe.
- Cinco paños de mesa: Verde, Violeta, Azul noche, Borgoña y Madera.
- Meta de 50, 100, 150 o 200 puntos.
- Juego individual o por parejas opuestas si participan cuatro jugadores.
- Modalidad Robar o Pasar cuando no se puede jugar.

## Reglas de esta versión

- Set doble-seis de 28 fichas.
- Siete fichas para cada participante; el resto queda en el pozo.
- Abre la mula de seis si está disponible. Si no, la mula más alta; si no hay dobles, la ficha con mayor suma.
- La ficha debe coincidir con uno de los extremos abiertos.
- En modalidad Robar, se roban fichas hasta conseguir una jugable o agotar el pozo. En modalidad Pasar, se pasa directamente.
- La ronda termina al quedarse sin fichas o tras una vuelta completa de pases con el pozo vacío.
- En cierre gana quien conserve menos puntos. La puntuación de ronda se agrega al marcador hasta alcanzar la meta.

La implementación es una modalidad doble-seis común. Algunas regiones aplican otras reglas de salida, robo, cierre y puntuación.

## Ejecución integrada

El servidor `server.js` se inicia como proceso secundario desde el servidor principal, en el puerto interno 3103. Utiliza Express y Socket.IO del `package.json` raíz. La ruta pública es `/domino/` y el socket público es `/domino/socket.io`.


## Flujo de pantallas

Dominó Club está organizado en tres etapas visuales:

1. **Inicio:** presentación del juego y selección del modo (IA, online o misma pantalla).
2. **Lobby:** configuración de participantes, avatar, dificultad, reglas y personalización. En modo online, el lobby cambia a la sala de espera con código y participantes conectados.
3. **Partida:** mesa de juego, fichas, turnos, acciones y puntuación.

La sala de espera online es un estado interno de la pantalla Lobby; no crea una cuarta sección de navegación.


## Revisión funcional y visual 1.4.0

- La hoja de estilos del juego se solicita desde `/domino/styles.css`; no debe usar `/styles.css`, que pertenece al portal.
- El cliente y Socket.IO conservan el prefijo público `/domino` para que el proxy principal reenvíe recursos y conexiones al proceso interno.
- El encabezado informa si la conexión está activa, reconectando o no disponible.
- Las acciones que dependen del servidor muestran un aviso cuando la conexión no está establecida.
- Las preferencias usan lectura/escritura protegida para que una restricción de `localStorage` no impida iniciar los eventos de la interfaz.
- El lobby online desactiva el inicio hasta que haya al menos dos participantes.
- Se revisó el comportamiento de navegación, el selector de modo, los avatares, los acabados, las mesas, el inicio de partidas IA/local y la colocación de fichas con un socket simulado.


## Actualización visual 1.5.0

- Retratos de avatar renovados con ilustración tipo caricatura.
- Las fichas de la mano se pueden arrastrar con mouse o pantalla táctil a la zona central; el lado donde se sueltan decide izquierda/derecha y la apertura usa el centro.
- La guía de arrastre se ilumina cuando la ficha está sobre la mesa.

## Recorrido de la cadena

La mesa distribuye las fichas en filas serpenteantes. Una fila avanza de izquierda a derecha; la siguiente vuelve de derecha a izquierda, unidas por un conector de giro. El número de fichas por fila depende del ancho disponible (más filas y menos fichas por fila en celular). Al arrastrar, el lado de la jugada se calcula por la cercanía al inicio o al final visible de la cadena. La orientación individual de cada ficha no se configura: las curvas pertenecen al recorrido completo de la mesa.


## Revisión 1.8.3 — avatares, IA y marcador
- El selector muestra ocho retratos de tamaño uniforme sin etiquetas con nombres. Los archivos usan identificadores neutrales `avatar-01.webp` a `avatar-08.webp`.
- La IA tiene nombres ficticios independientes de los identificadores de imagen: Don Jacinto, La Chispa, El Zurdo, Doña Mula, Capitán Doble, La Centella, Tito Seis y La Estratega.
- Los rivales IA reciben retratos únicos y no reutilizan el retrato del jugador humano. Los participantes de la misma pantalla tampoco repiten retrato.
- El servidor agenda una sola espera por turno de IA.
- En cierres bloqueados por parejas, el puntaje de ronda se calcula como la diferencia de puntos entre los equipos.


## Revisión funcional 1.8.4 — avatares y rivales
- El selector de avatar muestra ocho imágenes uniformes, sin nombre debajo de cada retrato.
- Los archivos usan identificadores neutrales `avatar-01` a `avatar-08`.
- Los nombres de IA se asignan por un roster independiente: Don Jacinto, La Chispa, El Zurdo, Doña Mula, Capitán Doble, La Centella, Tito Seis y La Estratega.
- Se evitan retratos repetidos entre el jugador y los rivales IA o participantes locales.
- Las preferencias antiguas de avatar se migran a los nuevos IDs.
- Corregidos el doble agendamiento de IA al crear partida y la puntuación por bloqueo en parejas.


## Corrección 1.8.6 — renderizado de fichas
- `layout.js` debe existir también dentro de `public/`, porque Express sirve esa carpeta como raíz estática.
- El HTML carga `/domino/layout.js?v=1.8.6`; el archivo público se mantiene idéntico al módulo fuente de la carpeta `Domino_Online/`.
- La prueba de cliente ejecuta el recurso que realmente descarga el navegador y verifica que una cadena no vacía se representa con una ficha por posición y conectores.


## Dominó Club 1.8.6 — orientación visual de la cadena
- La secuencia lógica del servidor conserva siempre el orden `a → b`; al colocar una ficha a la izquierda, sus valores se normalizan para que el extremo coincidente quede en el lado de unión.
- El módulo de disposición calcula la dirección física de cada tramo. En las filas que regresan hacia la izquierda (o suben en vertical), el cliente añade `reverse-halves` y el CSS intercambia las mitades, sin alterar los valores guardados.
- Se corrigió el caso reportado de una ficha `5-4` colocada contra un extremo `5`: en la fila de retorno el 5 se muestra junto a la ficha previa y el 4 queda hacia el extremo abierto.
- La respuesta `played` del servidor ahora también comunica los valores ya normalizados, no el orden original de la mano.
- Recursos CSS, `layout.js` y cliente usan el query string `v=1.8.6` para evitar reutilizar versiones anteriores.
- Verificación: 109 pruebas aprobadas; `npm run check` correcto.


## Dominó Club 1.8.9 — marcador de partida y dobles cruzados

- Se añadió un botón de marcador en la barra superior de la mesa. El desplegable muestra la puntuación acumulada, la meta, quién lidera, miembros de cada pareja y puntos restantes para llegar al objetivo.
- Al terminar una ronda aparece un panel con quién ganó, por qué terminó la ronda, cuántos puntos ganó el vencedor y el resumen de puntos que quedaron en las manos. El marcador se abre automáticamente al cambiar el resultado.
- El marcador por parejas utiliza la puntuación compartida sin duplicarla: ambos integrantes reciben el mismo valor en el servidor y la vista agrupa el equipo en una sola fila.
- Los dobles ahora se orientan perpendicularmente a la dirección por la que llega la cadena: en un tramo horizontal quedan verticales; en un tramo vertical quedan horizontales. Esto mantiene el doble atravesado y centrado incluso cuando la cadena gira.
- La posición de cada ficha se calcula desde el puerto real de entrada según la dirección entrante y desde el puerto real de salida según la dirección siguiente. Los conectores llegan a los bordes correctos, no a puntos aproximados ni al centro de la pieza.
- Se sincronizó `Domino_Online/layout.js` con `Domino_Online/public/layout.js`, que es el archivo que realmente descarga el navegador.
- Se versionaron CSS, cliente y layout a `1.8.9` para evitar recursos mezclados en caché.
- Verificación: `npm run check` correcto; `npm test` 124/124 aprobadas. Se añadieron aserciones geométricas para la entrada superior de un doble horizontal sobre tramo vertical y su salida por el extremo lateral.
- BioDefensa y Rummikub permanecen intactos.


## Versión 1.8.12 — distribución y cámara adaptable
- Ajuste del carril de retorno tras giros verticales, con conectores en escuadra y espacio suficiente para dobles.
- La dirección vertical de un brazo no se invierte sobre una fila ocupada.
- Tamaños CSS de fichas alineados con las dimensiones usadas por el motor de posiciones.
- Cámara del tablero con zoom progresivo en móviles; el zoom no afecta a la mano ni a los controles.
