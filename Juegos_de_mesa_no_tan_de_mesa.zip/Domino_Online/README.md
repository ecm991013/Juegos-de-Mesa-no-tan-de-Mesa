# Dominó Club

Juego web de dominó doble-seis integrado en el portal principal.

## Modos

- Contra IA: 2–4 plazas, nombres y retratos propios, dificultad Fácil/Normal/Difícil.
- Misma pantalla: 2–4 participantes comparten el dispositivo por turnos.
- En línea: sala privada con código; el anfitrión inicia cuando se conectan al menos dos participantes.

## Personalización

- Avatares ilustrados exclusivos del juego.
- Ocho acabados visuales de fichas: Marfil, Madera, Ónix, Mármol, Oro, Neón, Océano y Caribe.
- Cinco paños de mesa: Verde, Violeta, Azul noche, Borgoña y Madera.
- Meta de 50, 100, 150 o 200 puntos.
- Juego individual o por parejas opuestas si participan cuatro jugadores.
- Modalidad Robar o Pasar cuando no se puede jugar.

## Reglas de esta versión

- Set doble-seis de 28 fichas.
- Siete fichas para cada participante; el resto queda en el pozo.
- Abre la mula de seis si está disponible. Si no, la mula más alta; si no hay dobles, la ficha con mayor suma.
- La ficha debe coincidir con uno de los extremos abiertos.
- En modalidad Robar, se roban fichas hasta conseguir una jugable o agotar el pozo. En modalidad Pasar, se pasa directamente.
- La ronda termina al quedarse sin fichas o tras una vuelta completa de pases con el pozo vacío.
- En cierre gana quien conserve menos puntos. La puntuación de ronda se agrega al marcador hasta alcanzar la meta.

La implementación es una modalidad doble-seis común. Algunas regiones aplican otras reglas de salida, robo, cierre y puntuación.

## Ejecución integrada

El servidor `server.js` se inicia como proceso secundario desde el servidor principal, en el puerto interno 3103. Utiliza Express y Socket.IO del `package.json` raíz. La ruta pública es `/domino/` y el socket público es `/domino/socket.io`.


## Flujo de pantallas

Dominó Club está organizado en tres etapas visuales:

1. **Inicio:** presentación del juego y selección del modo (IA, online o misma pantalla).
2. **Lobby:** configuración de participantes, avatar, dificultad, reglas y personalización. En modo online, el lobby cambia a la sala de espera con código y participantes conectados.
3. **Partida:** mesa de juego, fichas, turnos, acciones y puntuación.

La sala de espera online es un estado interno de la pantalla Lobby; no crea una cuarta sección de navegación.


## Revisión funcional y visual 1.4.0

- La hoja de estilos del juego se solicita desde `/domino/styles.css`; no debe usar `/styles.css`, que pertenece al portal.
- El cliente y Socket.IO conservan el prefijo público `/domino` para que el proxy principal reenvíe recursos y conexiones al proceso interno.
- El encabezado informa si la conexión está activa, reconectando o no disponible.
- Las acciones que dependen del servidor muestran un aviso cuando la conexión no está establecida.
- Las preferencias usan lectura/escritura protegida para que una restricción de `localStorage` no impida iniciar los eventos de la interfaz.
- El lobby online desactiva el inicio hasta que haya al menos dos participantes.
- Se revisó el comportamiento de navegación, el selector de modo, los avatares, los acabados, las mesas, el inicio de partidas IA/local y la colocación de fichas con un socket simulado.


## Actualización visual 1.5.0

- Retratos de avatar renovados con ilustración tipo caricatura.
- Las fichas de la mano se pueden arrastrar con mouse o pantalla táctil a la zona central; el lado donde se sueltan decide izquierda/derecha y la apertura usa el centro.
- La guía de arrastre se ilumina cuando la ficha está sobre la mesa.

## Recorrido de la cadena

La mesa distribuye las fichas en filas serpenteantes. Una fila avanza de izquierda a derecha; la siguiente vuelve de derecha a izquierda, unidas por un conector de giro. El número de fichas por fila depende del ancho disponible (más filas y menos fichas por fila en celular). Al arrastrar, el lado de la jugada se calcula por la cercanía al inicio o al final visible de la cadena. La orientación individual de cada ficha no se configura: las curvas pertenecen al recorrido completo de la mesa.
