@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo No se encontro Node.js. Instala Node.js 20 o superior.
  pause
  exit /b 1
)
echo Preparando las dependencias de Rummikub...
call npm install --prefix Rummikub_Online --omit=dev
if errorlevel 1 (
  echo No se pudieron instalar las dependencias. Revisa tu conexion a internet.
  pause
  exit /b 1
)
echo.
echo Iniciando Juegos de mesa no tan de mesa...
echo Abre http://localhost:3000 en tu navegador.
echo.
node server.js
pause
