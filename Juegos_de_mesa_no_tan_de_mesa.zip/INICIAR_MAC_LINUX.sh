#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
node --version
npm install --prefix Rummikub_Online --omit=dev
node server.js
