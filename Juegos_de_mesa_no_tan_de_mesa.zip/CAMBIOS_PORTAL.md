# Cambios del paquete integrado 1.0.0

- Se creó el catálogo principal responsive con buscador, filtros por tipo de juego y tarjetas de acceso.
- Se integró BioDefensa bajo `/biodefensa/` y Rummikub bajo `/rummikub/`.
- Se conservan los servidores internos de cada juego; el portal no mezcla reglas, turnos ni datos de partidas.
- El servidor principal reenvía peticiones HTTP y el canal WebSocket de Socket.IO de Rummikub.
- Se actualizaron las rutas de imágenes, estilos, scripts y API para funcionar desde sus subrutas.
- Se añadió navegación de regreso al catálogo desde las cabeceras de ambos juegos.
- Se actualizó el enlace de invitación de BioDefensa para compartir la ruta correcta del juego.
- Se eliminó una comprobación duplicada de conexión del cliente de Rummikub.
- Se añadió `/health` como comprobación de estado para Render.


### Corrección Rummikub: validación de primera apertura
- Corregido un error de referencia a `normalizedFlat` no definido al puntuar una apertura con comodín.
- Centralizado el cálculo de puntos de apertura en `Rummikub_Online/rules.js`, usando los grupos ya normalizados por el servidor.
- Añadida protección ante excepciones inesperadas durante `playTurn`, con aviso visible en vez de dejar la acción sin respuesta.
- Añadidas pruebas para aperturas de 40+ puntos, comodines y exclusión de fichas que ya estaban en mesa.
