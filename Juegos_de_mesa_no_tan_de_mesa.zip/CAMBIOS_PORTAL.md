# Cambios de la plataforma

## Versión 1.5.1
- Se corrigió la tarjeta de Dominó en el catálogo: se eliminó el texto grande que se recortaba en la ilustración y se reemplazó por una etiqueta breve.
- La portada muestra toda la ilustración panorámica y se adapta a escritorio y celular.
- Se revisaron tipografías, etiquetas, márgenes y proporciones en la tarjeta.
- La IA tiene pausas más largas entre turnos: Fácil 3,6–4,4 s; Normal 4,2–5,0 s; Difícil 4,8–5,6 s.
- El jugador ve cuándo la IA está pensando mediante el banner de turno.
