# Cambios del portal · Versión 1.5.3

- Corregida la tarjeta de Dominó: la imagen ya no se recorta ni se amplía dentro de un marco de altura fija.
- El contenedor deja que la altura se calcule proporcionalmente desde la imagen.
- La portada usa `domino-cover-v3.png` (2400 × 1000), una URL nueva que evita reutilizar la portada anterior.
- CSS y JavaScript del portal tienen rutas versionadas.
- El servidor revalida HTML, CSS, JavaScript y SVG con `Cache-Control: no-cache`.
- No se modificaron las reglas ni los servidores de los tres juegos.
