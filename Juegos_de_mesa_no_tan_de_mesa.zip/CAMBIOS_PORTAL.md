# Cambios del portal · Versión 1.5.3

- Corregida la tarjeta de Dominó: la imagen ya no se recorta ni se amplía dentro de un marco de altura fija.
- El contenedor deja que la altura se calcule proporcionalmente desde la imagen.
- La portada usa `domino-cover-v3.png` (2400 × 1000), una URL nueva que evita reutilizar la portada anterior.
- CSS y JavaScript del portal tienen rutas versionadas.
- El servidor revalida HTML, CSS, JavaScript y SVG con `Cache-Control: no-cache`.
- No se modificaron las reglas ni los servidores de los tres juegos.


## Dominó Club 1.6.0
- Se añadió una vista previa dinámica para la combinación de acabado y paño seleccionados.
- Se retiraron las pistas visuales que marcaban cuáles fichas eran jugables. Todas las fichas de la mano permanecen seleccionables en el turno; el servidor conserva la validación.
- Se incorporó la preferencia de orientación horizontal/vertical y se almacena en cada ficha colocada.


## Dominó 1.7.0 — cadena serpenteante
- Se sustituyó la línea horizontal con salto de línea por filas alternas en zigzag.
- Las filas pares avanzan a la derecha y las impares regresan hacia la izquierda, unidas por conectores visuales.
- La cantidad de fichas por fila se calcula con el ancho del tablero y se recalcula al cambiar el tamaño de pantalla.
- El arrastre selecciona el extremo real más cercano, no la mitad de la mesa.
- Se retiró la selección de orientación individual: el recorrido de la cadena hace las curvas automáticamente.
