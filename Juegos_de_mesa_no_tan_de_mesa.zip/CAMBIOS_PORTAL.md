# Cambios del paquete integrado 1.0.0

- Se creó el catálogo principal responsive con buscador, filtros por tipo de juego y tarjetas de acceso.
- Se integró BioDefensa bajo `/biodefensa/` y Rummikub bajo `/rummikub/`.
- Se conservan los servidores internos de cada juego; el portal no mezcla reglas, turnos ni datos de partidas.
- El servidor principal reenvía peticiones HTTP y el canal WebSocket de Socket.IO de Rummikub.
- Se actualizaron las rutas de imágenes, estilos, scripts y API para funcionar desde sus subrutas.
- Se añadió navegación de regreso al catálogo desde las cabeceras de ambos juegos.
- Se actualizó el enlace de invitación de BioDefensa para compartir la ruta correcta del juego.
- Se eliminó una comprobación duplicada de conexión del cliente de Rummikub.
- Se añadió `/health` como comprobación de estado para Render.


### Corrección Rummikub: validación de primera apertura
- Corregido un error de referencia a `normalizedFlat` no definido al puntuar una apertura con comodín.
- Centralizado el cálculo de puntos de apertura en `Rummikub_Online/rules.js`, usando los grupos ya normalizados por el servidor.
- Añadida protección ante excepciones inesperadas durante `playTurn`, con aviso visible en vez de dejar la acción sin respuesta.
- Añadidas pruebas para aperturas de 40+ puntos, comodines y exclusión de fichas que ya estaban en mesa.


## Actualización 1.0.2 / Rummikub Online Club 1.4.0
- Las escaleras válidas ahora admiten de 3 a 13 fichas; el límite de 4 queda únicamente para conjuntos del mismo número y cuatro colores distintos, de acuerdo con las reglas del juego.
- Se añadieron pruebas de escaleras largas, límite 1–13, conjuntos y comodines.
- Se incorporó un control de efectos de sonido con persistencia local y sonidos generados por Web Audio para selección, movimiento, robo, confirmación y errores.
- Se añadieron cinco acabados de fichas: Océano, Cristal, Bosque, Cobre y Atardecer.
- Se aumentaron tamaños mínimos de texto y controles en pantallas pequeñas y se afinó la distribución de grupos largos en el tapete.


## Actualización Rummikub 1.0.3
- Rediseño adaptable del modal de personalización: tarjetas más compactas, mejor lectura, scroll interno y pie fijo en móviles.
- Reforzado el contraste de los números de las fichas en los 12 acabados.
- Sustituidos los retratos fotográficos por avatares vectoriales planos dibujados para el juego.
- Rivales IA con nombres propios: Sofía, Mateo y Valentina.
- Añadida selección de dificultad Fácil, Normal y Difícil; la dificultad modifica la toma de decisiones y el ritmo de respuesta.


## Actualización 1.0.4 — avatares con retratos

- Las ocho opciones del selector de avatar ahora cargan las imágenes WebP de retratos (`person1.webp` a `person8.webp`) en lugar de ilustraciones SVG planas.
- Los avatares de los jugadores y las IA usan las mismas imágenes rasterizadas, por lo que el retrato se mantiene igual en el selector, la sala y la partida.
- Se añadieron textos alternativos accesibles para identificar los retratos.
- No se modificaron las reglas, la dificultad ni la lógica de las partidas.


## Versión 1.1.0 – incorporación de Parqués Club
- Nuevo juego independiente en `Parques_Online/`, integrado en el catálogo y en el proxy principal.
- Modos de tablero de cuatro y seis puestos, cuatro fichas por jugador y dos dados.
- Partidas contra IA con nombres y dificultades Fácil, Normal y Difícil.
- Salas online por código, lista de salas abiertas y turnos sincronizados mediante Socket.IO.
- Cuatro estilos de tablero: Clásico, Esmeralda, Caribe y Real.
- Reglas implementadas: salida con 5, pares con turno extra, casillas seguras, capturas, barreras y llegada exacta; penalización por tres pares configurable.
- Se amplió el proxy de WebSocket y el catálogo principal para `/parques/`.
