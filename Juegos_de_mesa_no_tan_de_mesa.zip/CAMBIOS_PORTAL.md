## Dominó Club 1.8.13 — dirección intuitiva desde puntas verticales

- Al arrastrar debajo de una punta vertical, la siguiente ficha continúa alineada debajo/encima de la punta.
- Al arrastrar a izquierda o derecha de una punta vertical, se respeta ese sentido sin invertir la fila por defecto.
- La detección lateral usa una zona más sensible para que un arrastre corto también registre la dirección elegida.
- Se actualizaron las referencias de CSS/JS para evitar caché de versiones anteriores.

# Cambios de la plataforma

## Dominó Club 1.8.11 — giro desde la mitad abierta

- `flowAfter` se aplica a la siguiente ficha; la ficha que marca el giro permanece en su fila.
- Al elegir bajar desde una ficha horizontal, la siguiente ficha vertical se alinea con el centro de su mitad abierta: mitad derecha en la rama derecha, mitad izquierda en la rama izquierda.
- Al elegir subir, se usa el borde superior de esa mitad.
- Si la ficha fuente ya está vertical, la siguiente queda justo debajo de su punta inferior o encima de la superior.
- Después de la ficha vertical de giro, el recorrido vuelve por la fila inferior/superior en sentido contrario, a menos que el jugador vuelva a indicar otro giro.
- El giro automático por espacio usa el mismo criterio.
- Se sincronizaron `Domino_Online/layout.js` y `Domino_Online/public/layout.js`; recursos versionados a 1.8.11.
- Verificación: 120/120 pruebas automatizadas aprobadas y `npm run check` correcto.

## Alcance
BioDefensa y Rummikub permanecen sin cambios.
