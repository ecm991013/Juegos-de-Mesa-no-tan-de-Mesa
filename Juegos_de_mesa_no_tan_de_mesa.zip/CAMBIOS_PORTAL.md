# Cambios del portal – Versión 1.3.0

- Se añadió Dominó Club como tercer juego, con identidad visual propia de paño, madera, berenjena y oro.
- Se creó `/domino/` como servicio independiente con servidor y módulo de reglas propios.
- El portal reenvía HTTP y WebSocket de Socket.IO para Dominó, igual que para Rummikub.
- Se añadió una tarjeta al catálogo con portada SVG original, descripción y categorías.
- Se actualizó el contador automático de juegos a tres y se agregó el filtro «Clásicos».
- Dominó incorpora doble-seis, 2–4 jugadores, modo robar/pasar, juego individual/parejas, meta de puntos configurable, IA con tres dificultades, modo local y salas online por código.
- Se añadieron ocho avatares ilustrados exclusivos, ocho acabados de fichas y cinco colores de mesa.
- Se añadieron las reglas del juego en una ventana accesible desde el lobby.
- Se añadieron 10 pruebas automatizadas de reglas de Dominó y se extendió `npm run check` para verificar sus scripts.
- BioDefensa y Rummikub se mantienen sin cambios funcionales.


## Dominó Club · flujo de pantallas
- Inicio independiente con accesos a IA, online y misma pantalla.
- Lobby independiente para preparar participantes y personalización.
- Sala privada online integrada como estado del lobby.
- Pantalla de partida separada.
- Diseño responsive para móvil y escritorio.


## 1.4.0 · Auditoría de Dominó Club

- Corregida la referencia de CSS: ahora carga `/domino/styles.css` y deja de heredar por error los estilos del portal.
- Añadido indicador de conexión Socket.IO y mensajes claros de reconexión/falta de conexión.
- Unificadas las emisiones del cliente a través de `emitAction`, con comprobación de conexión y aviso al usuario.
- Protegidas las preferencias frente a restricciones del almacenamiento local.
- Corregida la actualización de los temas de fichas para no acumular clases de skins anteriores.
- El botón de iniciar sala online solo se habilita cuando el anfitrión tiene al menos otro participante.
- Renovada la identidad gráfica: tablero de paño y madera, fichas táctiles con relieve, tarjetas de jugadores, controles de mesa, estados activos y diseño móvil.
- Añadidas pruebas de ejecución del cliente con DOM/socket simulados, además de pruebas de enlaces, recursos, manejadores y rutas proxy.

- La batería final se amplió a 68 pruebas; incluye un caso de cliente desconectado que comprueba que no hay fallos silenciosos.


## Versión 1.5.0
- Portada de Dominó rediseñada en formato panorámico; el título queda como texto HTML adaptable y ya no se recorta dentro de la ilustración.
- Avatares propios de Dominó sustituidos por retratos caricaturescos ilustrados.
- Arrastre con mouse y táctil desde la mano hasta la mesa; la zona de caída indica el extremo izquierdo/derecho o la apertura central.
- Diseño responsive afinado para tamaños de fichas, retratos y tarjetas.
