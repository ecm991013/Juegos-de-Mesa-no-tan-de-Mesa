# Juegos de mesa no tan de mesa

Plataforma con tres juegos web independientes: BioDefensa, Rummikub Online Club y Dominó Club.

## Despliegue
Sube el ZIP `Juegos_de_mesa_no_tan_de_mesa.zip` junto con `render.yaml` a GitHub. Render extrae el ZIP durante el build, instala las dependencias raíz e inicia el portal con `npm start`.

## Última actualización · 1.8.5
- La tarjeta de Dominó utiliza la portada `domino-cover-v3.png` (2400 × 1000).
- La imagen se escala con anchura completa y altura proporcional; el marco completo queda visible y no se recorta.
- El enlace de la imagen cambia de versión para que el navegador no reutilice el recurso anterior.
- HTML, CSS, JavaScript y SVG usan `Cache-Control: no-cache`; además, las hojas CSS y scripts utilizan URLs versionadas.
- BioDefensa y Rummikub conservan sus reglas y archivos.


## Dominó Club 1.6.0
- Previsualización en vivo del acabado de fichas y color del paño.
- Las fichas de la mano no se resaltan ni deshabilitan individualmente según su jugada; el jugador decide y el servidor valida.
- Recorrido serpenteante: las filas alternan derecha e izquierda y se conectan con curvas visuales.


### Dominó Club 1.7.0

La cadena se distribuye en varias filas conectadas, no en una sola línea horizontal. Cada fila alterna su sentido: avanza a la derecha, gira al siguiente tramo y vuelve a la izquierda. El número de fichas por fila se calcula según el ancho del tablero y se vuelve a calcular al cambiar el tamaño de pantalla. Al arrastrar una ficha, el extremo de destino se decide por proximidad al primer o último elemento visible de la cadena.


## Dominó Club 1.8.2 — mano y recorrido
- La ficha de apertura queda centrada respecto al área útil visible de la mesa, descontando el padding superior e inferior del escenario.
- La cadena crece desde la ficha inicial hacia los extremos izquierdo y derecho.
- El usuario puede ordenar manualmente su mano arrastrando fichas sobre otras.
- Al soltar una ficha por debajo o por encima del extremo, puede indicar que el próximo tramo doble hacia abajo o arriba; también puede escogerlo con los controles de dirección.
- Las fichas dobles y normales conservan dimensiones idénticas en horizontal y vertical, también en móvil.
- Se amplían las pruebas de arrastre, orden manual, apertura centrada y giros en ambos lados.


## Versión 1.8.2 — distribución del tablero de Dominó
- Se ajustó el centro vertical de la ficha inicial para calcularse dentro del área de contenido de `chainStage`, descontando el padding real del escenario. Esto evita que la ficha quede visualmente desplazada hacia abajo.
- Se mantuvo el punto de apertura centrado y las ramas izquierda/derecha.
- La mano admite reordenación libre por arrastre entre fichas.
- El usuario puede marcar el siguiente giro de una rama soltando por encima/debajo del extremo o usando los controles «Seguir recto», «Doblar arriba» y «Doblar abajo».
- Se añadieron pruebas de giro en la rama izquierda y de dimensiones físicas uniformes para fichas dobles y normales.


## Dominó Club 1.8.3 — revisión de avatares y rivales
- Se corrigió la programación duplicada del temporizador de IA al crear una partida: cada turno de IA ahora se agenda una sola vez.
- Los ocho retratos del selector usan identificadores neutros (`avatar-01` a `avatar-08`), se muestran en una cuadrícula uniforme y ya no tienen nombres debajo.
- Los rivales IA ahora tienen nombres ficticios propios: Don Jacinto, La Chispa, El Zurdo, Doña Mula, Capitán Doble, La Centella, Tito Seis y La Estratega.
- La selección de rivales evita repetir el retrato elegido por el jugador y evita duplicar retratos entre IA; en la modalidad local también asigna retratos distintos.
- Se corrigió la puntuación por cierre bloqueado en parejas: el equipo ganador recibe la diferencia entre los puntos restantes del equipo rival y los suyos.
- Nueva cobertura de pruebas para roster, avatares, programación de IA y puntuación por parejas.
- BioDefensa y Rummikub permanecen sin cambios en sus reglas ni en sus archivos.


## Dominó Club 1.8.4 — revisión funcional y avatares
- Eliminado el segundo agendamiento consecutivo del temporizador de IA al crear partidas.
- Corregida la puntuación de una ronda bloqueada en modo parejas para otorgar la diferencia de puntos restantes entre equipos.
- Se organizó el selector de retratos en una cuadrícula uniforme de ocho imágenes sin etiquetas nominales.
- Se normalizaron los nombres de archivo de los retratos a `avatar-01.webp` … `avatar-08.webp`.
- Se incorporó un roster independiente de nombres ficticios para la IA: Don Jacinto, La Chispa, El Zurdo, Doña Mula, Capitán Doble, La Centella, Tito Seis y La Estratega.
- Se evita que el jugador y los rivales de IA/local compartan retratos en la misma partida.
- Se añadió migración de las preferencias guardadas con identificadores antiguos a los nuevos IDs neutrales.
- Verificación: 100/100 pruebas y `npm run check` aprobados.


## Dominó Club 1.8.5 — corrección de la cadena invisible

- **Causa raíz:** `Domino_Online/public/index.html` solicita `/domino/layout.js`, pero Express solo publica archivos que están dentro de `Domino_Online/public`. El módulo `layout.js` existía únicamente en la raíz del juego. Mientras la cadena estaba vacía, el cliente podía mostrar la mano; al recibir la primera ficha y tratar de dibujar una cadena no vacía, `window.DominoLayout` no existía y el render se interrumpía. Esto explica la mesa vacía de la captura.
- Se añadió `Domino_Online/public/layout.js`, copia exacta del módulo fuente `Domino_Online/layout.js`, para que Express lo pueda servir mediante la misma ruta solicitada por el HTML.
- Se versionaron las referencias de `layout.js`, `client.js` y `styles.css` a `1.8.5` para evitar mezclar recursos de versiones anteriores.
- El test del cliente ahora ejecuta el `layout.js` público real en el DOM simulado en vez de inyectar únicamente el módulo Node. Se añadió una regresión que entrega un `gameState` con tres fichas y comprueba que el HTML del tablero contiene todas las fichas, la apertura y los conectores.
- Se añadió una verificación de que el archivo público existe y coincide byte por byte con el módulo fuente.
- Verificación: `npm run check` correcto; `npm test` con 102 pruebas aprobadas, 0 fallidas.
- BioDefensa y Rummikub no se modificaron.


## Corrección de orientación de fichas · v1.8.6

Al volver una fila en el recorrido serpenteante, se invierten únicamente las mitades visuales (a/b) para que el número coincidente quede junto a la ficha anterior. La secuencia lógica del servidor permanece en orden a→b. Se añadieron pruebas para ramas izquierda/derecha y giros arriba/abajo.


## Dominó Club 1.8.6 — orientación 5-4 en la cadena serpenteante
- Se detectó que las fichas de las filas de retorno se mostraban con las mitades al revés: el modelo lógico seguía `a → b`, pero el diseño visual no reflejaba que la cadena ahora avanzaba de derecha a izquierda.
- `layout.js` ahora entrega `reverseHalves` según el sentido físico del tramo, tanto en la rama izquierda como derecha y para giros arriba/abajo.
- El renderer añade la clase `reverse-halves`; CSS intercambia la posición de las mitades dentro de la cuadrícula horizontal o vertical.
- `rules.playTile` mantiene la conexión del valor coincidente y la respuesta `played` devuelve el orden normalizado del servidor. Para el caso reportado, `5-4` conectado al `5` se muestra con el 5 en el lado de unión durante el retorno.
- Las referencias CSS, layout y cliente se versionaron a `1.8.6`.
- Verificación: `npm test` 109/109 aprobadas y `npm run check` correcto.


## Dominó Club 1.8.7 — recorrido serpenteante conectado

- Se sustituyó la distribución por centros por una geometría basada en puertos de entrada y salida de cada ficha.
- Los conectores ahora siguen un recorrido ortogonal en codo: salen del extremo real de la ficha anterior, recorren un pequeño tramo, giran 90 grados y llegan al extremo real de la ficha siguiente.
- Las fichas verticales marcan los giros hacia arriba/abajo; el siguiente tramo horizontal invierte el sentido y continúa debajo/encima, como una cadena serpenteante continua.
- La lógica es simétrica para el brazo izquierdo y derecho, conserva el orden lógico a→b y mantiene la apertura en el centro horizontal de la mesa.
- Se corrigió el cálculo del ancho: se usa el `clientWidth` real de `dominoChain`, evitando que el SVG se escale distinto a las fichas.
- Se corrigió el orden al entrar a una partida: primero se muestra la vista de juego y después se mide/renderiza el tablero. Antes la medición se hacía con el panel oculto (`display:none`) y podía usar un ancho de respaldo incorrecto.
- La detección de giro arriba/abajo ahora requiere menos recorrido del puntero para facilitar el gesto táctil.
- Se añadieron pruebas para giros abajo/arriba en ambos brazos, codos conectados a los puertos de ficha, fila de retorno, apertura centrada en móvil y visibilidad antes de medir.
- Verificación: `npm test` 115/115 aprobadas; `npm run check` correcto.
- BioDefensa y Rummikub permanecen sin cambios.


## Dominó Club 1.8.9 — marcador de partida y dobles cruzados

- Se añadió un botón de marcador en la barra superior de la mesa. El desplegable muestra la puntuación acumulada, la meta, quién lidera, miembros de cada pareja y puntos restantes para llegar al objetivo.
- Al terminar una ronda aparece un panel con quién ganó, por qué terminó la ronda, cuántos puntos ganó el vencedor y el resumen de puntos que quedaron en las manos. El marcador se abre automáticamente al cambiar el resultado.
- El marcador por parejas utiliza la puntuación compartida sin duplicarla: ambos integrantes reciben el mismo valor en el servidor y la vista agrupa el equipo en una sola fila.
- Los dobles ahora se orientan perpendicularmente a la dirección por la que llega la cadena: en un tramo horizontal quedan verticales; en un tramo vertical quedan horizontales. Esto mantiene el doble atravesado y centrado incluso cuando la cadena gira.
- La posición de cada ficha se calcula desde el puerto real de entrada según la dirección entrante y desde el puerto real de salida según la dirección siguiente. Los conectores llegan a los bordes correctos, no a puntos aproximados ni al centro de la pieza.
- Se sincronizó `Domino_Online/layout.js` con `Domino_Online/public/layout.js`, que es el archivo que realmente descarga el navegador.
- Se versionaron CSS, cliente y layout a `1.8.9` para evitar recursos mezclados en caché.
- Verificación: `npm run check` correcto; `npm test` 124/124 aprobadas. Se añadieron aserciones geométricas para la entrada superior de un doble horizontal sobre tramo vertical y su salida por el extremo lateral.
- BioDefensa y Rummikub permanecen intactos.


## Versión 1.8.10
- Corregido el trazado de los giros de 90 grados: la primera ficha de la fila inferior/superior queda alineada con la punta de la ficha de giro.
- Conservado el codo de dos tramos solo para giros de 180 grados.
- Actualizada la copia pública de `layout.js` y añadidas pruebas de alineación exacta hacia arriba y abajo.
