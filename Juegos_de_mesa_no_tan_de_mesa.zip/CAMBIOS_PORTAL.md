# Cambios del portal · Versión 1.5.2

- Corregida la persistencia de la portada antigua en navegador: el recurso ahora se llama `domino-cover-v2.svg` y la referencia HTML apunta a esa URL nueva.
- La nueva ilustración muestra exclusivamente la mesa de dominó y sus fichas. El nombre del juego queda fuera del arte, como texto HTML independiente en la tarjeta.
- Se ajustó la proporción a 12:5 en todos los breakpoints, con `object-fit: cover` sobre un arte diseñado a la misma relación.
- El servidor entrega HTML y SVG con `Cache-Control: no-cache`; las imágenes rasterizadas siguen usando caché de 24 horas.
